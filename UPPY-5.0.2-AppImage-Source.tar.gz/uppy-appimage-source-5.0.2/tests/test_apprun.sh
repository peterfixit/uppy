#!/usr/bin/env bash

set -Eeuo pipefail

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
HELPER_SOURCE="${1:-}"
TEMP_DIR="$(mktemp -d)"
APPDIR="$TEMP_DIR/App Dir"
RUNTIME_DIR="$TEMP_DIR/runtime"
REJECTED_RUNTIME_DIR="$TEMP_DIR/rejected-runtime"
RESULT_FILE="$TEMP_DIR/result"
trap 'rm -rf -- "$TEMP_DIR"' EXIT

install -d "$APPDIR/usr/bin" "$APPDIR/usr/lib/uppy" "$RUNTIME_DIR" \
    "$REJECTED_RUNTIME_DIR"
install -m 0755 "$ROOT_DIR/packaging/AppRun" "$APPDIR/AppRun"
install -m 0755 "$ROOT_DIR/src/uppy-backend.sh" \
    "$APPDIR/usr/lib/uppy/uppy-backend.sh"

if [[ -n "$HELPER_SOURCE" ]]; then
    [[ -x "$HELPER_SOURCE" ]] || {
        printf '[ERROR] AppRun test helper is not executable: %s\n' \
            "$HELPER_SOURCE" >&2
        exit 2
    }
    install -m 0755 "$HELPER_SOURCE" \
        "$APPDIR/usr/lib/uppy/uppy-privileged"
else
    cat > "$APPDIR/usr/lib/uppy/uppy-privileged" <<'EOF'
#!/bin/sh
if [ "${1:-}" = "--stage-probe" ]; then
    [ "${UPPY_TEST_REJECT_ALL_STAGES:-0}" != "1" ] || exit 126
    if [ -n "${UPPY_TEST_REJECT_STAGE_PREFIX:-}" ]; then
        case "$0" in
            "$UPPY_TEST_REJECT_STAGE_PREFIX"*) exit 126 ;;
        esac
    fi
    exit 0
fi
exit 2
EOF
    chmod 0755 "$APPDIR/usr/lib/uppy/uppy-privileged"
fi

cat > "$APPDIR/usr/bin/uppy-gui" <<'EOF'
#!/bin/sh
set -eu

if [ "${UPPY_APPRUN_EXPECT_READ_ONLY:-0}" = "1" ]; then
    [ -n "${UPPY_PRIVILEGE_STAGE_ERROR:-}" ] || exit 30
    case "$UPPY_BACKEND:$UPPY_PRIVILEGED_RUNNER" in
        "$APPDIR"/*) ;;
        *) exit 31 ;;
    esac
    printf '%s\n' "read-only-fallback" > "$UPPY_APPRUN_RESULT"
    exit 0
fi

case "$UPPY_BACKEND:$UPPY_PRIVILEGED_RUNNER" in
    "$APPDIR"/*) exit 20 ;;
esac
[ "$(dirname -- "$UPPY_BACKEND")" = \
  "$(dirname -- "$UPPY_PRIVILEGED_RUNNER")" ] || exit 21
[ -r "$UPPY_BACKEND" ] && [ -x "$UPPY_BACKEND" ] || exit 22
[ -r "$UPPY_PRIVILEGED_RUNNER" ] && [ -x "$UPPY_PRIVILEGED_RUNNER" ] || exit 23
[ "$(stat -c '%a' -- "$(dirname -- "$UPPY_BACKEND")")" = "700" ] || exit 24
[ "$(stat -c '%a' -- "$UPPY_BACKEND")" = "700" ] || exit 25
[ "$(stat -c '%a' -- "$UPPY_PRIVILEGED_RUNNER")" = "700" ] || exit 26
printf '%s\n' "$(dirname -- "$UPPY_BACKEND")" > "$UPPY_APPRUN_RESULT"
exit "${UPPY_FAKE_STATUS:-0}"
EOF
chmod 0755 "$APPDIR/usr/bin/uppy-gui"

XDG_RUNTIME_DIR="$RUNTIME_DIR" UPPY_APPRUN_RESULT="$RESULT_FILE" \
    "$APPDIR/AppRun"
STAGED_DIR="$(cat "$RESULT_FILE")"
[[ "$STAGED_DIR" == "$RUNTIME_DIR"/uppy-runtime.* ]]
[[ ! -e "$STAGED_DIR" ]]

set +e
XDG_RUNTIME_DIR="$RUNTIME_DIR" UPPY_APPRUN_RESULT="$RESULT_FILE" \
    UPPY_FAKE_STATUS=37 "$APPDIR/AppRun"
status=$?
set -e
[[ $status -eq 37 ]] || {
    printf '[ERROR] AppRun returned %s instead of the GUI status 37.\n' \
        "$status" >&2
    exit 1
}
STAGED_DIR="$(cat "$RESULT_FILE")"
[[ ! -e "$STAGED_DIR" ]]

# Simulate a noexec XDG runtime. AppRun must reject that stage and select an
# executable fallback instead of allowing PolicyKit to fail later.
cat > "$APPDIR/usr/lib/uppy/uppy-privileged" <<'EOF'
#!/bin/sh
if [ "${1:-}" = "--stage-probe" ]; then
    [ "${UPPY_TEST_REJECT_ALL_STAGES:-0}" != "1" ] || exit 126
    if [ -n "${UPPY_TEST_REJECT_STAGE_PREFIX:-}" ]; then
        case "$0" in
            "$UPPY_TEST_REJECT_STAGE_PREFIX"*) exit 126 ;;
        esac
    fi
    exit 0
fi
exit 2
EOF
chmod 0755 "$APPDIR/usr/lib/uppy/uppy-privileged"
XDG_RUNTIME_DIR="$REJECTED_RUNTIME_DIR" \
    UPPY_TEST_REJECT_STAGE_PREFIX="$REJECTED_RUNTIME_DIR/" \
    UPPY_APPRUN_RESULT="$RESULT_FILE" "$APPDIR/AppRun"
STAGED_DIR="$(cat "$RESULT_FILE")"
[[ "$STAGED_DIR" != "$REJECTED_RUNTIME_DIR"/* ]]
[[ ! -e "$STAGED_DIR" ]]

# If every candidate is noexec, Uppy must still launch in read-only mode and
# expose a precise administrator-access error instead of silently failing.
UPPY_TEST_REJECT_ALL_STAGES=1 UPPY_APPRUN_EXPECT_READ_ONLY=1 \
    XDG_RUNTIME_DIR="$REJECTED_RUNTIME_DIR" \
    XDG_CACHE_HOME="$TEMP_DIR/rejected-cache" \
    UPPY_APPRUN_RESULT="$RESULT_FILE" "$APPDIR/AppRun"
grep -Fxq 'read-only-fallback' "$RESULT_FILE"

printf 'test_apprun: all tests passed\n'

#!/usr/bin/env bash

set -Eeuo pipefail

[[ $# -eq 1 && -x "$1" ]] || {
    printf 'Usage: %s /path/to/test-uppy-privileged\n' "$0" >&2
    exit 2
}

HELPER_SOURCE="$1"
TEMP_DIR="$(mktemp -d)"
CALLER_UID="$(id -u)"
CANCEL_DIR="/tmp/uppy-${CALLER_UID}"
CANCEL_FILE="$CANCEL_DIR/cancel-$$-deadbeef"
EARLY_CANCEL_FILE="$CANCEL_DIR/cancel-$$-cafebabe"
AUTHORIZE_CANCEL_FILE="$CANCEL_DIR/cancel-$$-0badf00d"
SIGNAL_CANCEL_FILE="$CANCEL_DIR/cancel-$$-1234abcd"
UNSAFE_CANCEL_FILE="$CANCEL_DIR/cancel-$$-feedface"
HELPER_PID=""
trap '[[ -n "$HELPER_PID" ]] && kill "$HELPER_PID" 2>/dev/null || true; rm -rf -- "$TEMP_DIR"; rm -f -- "$CANCEL_FILE" "$EARLY_CANCEL_FILE" "$AUTHORIZE_CANCEL_FILE" "$SIGNAL_CANCEL_FILE" "$UNSAFE_CANCEL_FILE"' EXIT

install -m 0700 "$HELPER_SOURCE" "$TEMP_DIR/uppy-privileged"
cat > "$TEMP_DIR/uppy-backend.sh" <<'EOF'
#!/usr/bin/env bash
trap 'exit 130' TERM INT HUP
printf 'fake backend started\n'
while true; do sleep 0.1; done
EOF
chmod 0600 "$TEMP_DIR/uppy-backend.sh"

mkdir -p "$CANCEL_DIR"
chmod 0700 "$CANCEL_DIR"
rm -f -- "$CANCEL_FILE" "$EARLY_CANCEL_FILE" "$AUTHORIZE_CANCEL_FILE" \
    "$SIGNAL_CANCEL_FILE" "$UNSAFE_CANCEL_FILE"

"$TEMP_DIR/uppy-privileged" --stage-probe

PKEXEC_UID="$CALLER_UID" "$TEMP_DIR/uppy-privileged" \
    --cancel-file "$AUTHORIZE_CANCEL_FILE" -- --authorize \
    > "$TEMP_DIR/authorize-output" 2>&1
grep -Fq 'Administrator access granted' "$TEMP_DIR/authorize-output"
[[ ! -e "$AUTHORIZE_CANCEL_FILE" ]]

if PKEXEC_UID="$CALLER_UID" "$TEMP_DIR/uppy-privileged" \
    --cancel-file "$AUTHORIZE_CANCEL_FILE" -- --authorize extra \
    >/dev/null 2>&1; then
    printf '[ERROR] Authorization-only mode accepted extra arguments.\n' >&2
    exit 1
fi

set +e
PKEXEC_UID="$CALLER_UID" "$TEMP_DIR/uppy-privileged" \
    --cancel-file "$CANCEL_FILE" -- --test > "$TEMP_DIR/output" 2>&1 &
HELPER_PID=$!
set -e
sleep 0.3
install -m 0600 /dev/null "$CANCEL_FILE"
set +e
wait "$HELPER_PID"
status=$?
set -e
HELPER_PID=""
[[ $status -eq 130 ]] || {
    printf '[ERROR] Cancellation returned %s instead of 130.\n' "$status" >&2
    cat "$TEMP_DIR/output" >&2
    exit 1
}
grep -Fq 'Cancellation requested' "$TEMP_DIR/output"
[[ ! -e "$CANCEL_FILE" ]]

# A cancellation request can beat PolicyKit/helper startup.
install -m 0600 /dev/null "$EARLY_CANCEL_FILE"
set +e
PKEXEC_UID="$CALLER_UID" "$TEMP_DIR/uppy-privileged" \
    --cancel-file "$EARLY_CANCEL_FILE" -- --test \
    > "$TEMP_DIR/early-output" 2>&1
early_status=$?
set -e
[[ $early_status -eq 130 ]] || {
    printf '[ERROR] Early cancellation returned %s instead of 130.\n' \
        "$early_status" >&2
    cat "$TEMP_DIR/early-output" >&2
    exit 1
}
grep -Fq 'Cancellation requested before the task started' \
    "$TEMP_DIR/early-output"
[[ ! -e "$EARLY_CANCEL_FILE" ]]

if PKEXEC_UID="$CALLER_UID" "$TEMP_DIR/uppy-privileged" \
    --cancel-file "/tmp/cancel-$$-deadbeef" -- --test >/dev/null 2>&1; then
    printf '[ERROR] An outside cancellation path was accepted.\n' >&2
    exit 1
fi

ln -s /etc/passwd "$UNSAFE_CANCEL_FILE"
if PKEXEC_UID="$CALLER_UID" "$TEMP_DIR/uppy-privileged" \
    --cancel-file "$UNSAFE_CANCEL_FILE" -- --test >/dev/null 2>&1; then
    printf '[ERROR] A symlink cancellation token was accepted.\n' >&2
    exit 1
fi
[[ -f /etc/passwd ]]
rm -f -- "$UNSAFE_CANCEL_FILE"

chmod 0720 "$TEMP_DIR/uppy-backend.sh"
if PKEXEC_UID="$CALLER_UID" "$TEMP_DIR/uppy-privileged" \
    --cancel-file "$AUTHORIZE_CANCEL_FILE" -- --authorize \
    >/dev/null 2>&1; then
    printf '[ERROR] A group-writable privileged backend was accepted.\n' >&2
    exit 1
fi
chmod 0600 "$TEMP_DIR/uppy-backend.sh"

set +e
PKEXEC_UID="$CALLER_UID" "$TEMP_DIR/uppy-privileged" \
    --cancel-file "$SIGNAL_CANCEL_FILE" -- --test \
    > "$TEMP_DIR/signal-output" 2>&1 &
HELPER_PID=$!
set -e
sleep 0.3
kill -TERM "$HELPER_PID"
set +e
wait "$HELPER_PID"
signal_status=$?
set -e
HELPER_PID=""
[[ $signal_status -eq 143 ]] || {
    printf '[ERROR] Signal shutdown returned %s instead of 143.\n' \
        "$signal_status" >&2
    cat "$TEMP_DIR/signal-output" >&2
    exit 1
}
grep -Fq 'Privileged task interrupted' "$TEMP_DIR/signal-output"
[[ ! -e "$SIGNAL_CANCEL_FILE" ]]

printf 'test_privileged: all tests passed\n'

#!/usr/bin/env bash

set -Eeuo pipefail

[[ $# -eq 2 && -x "$1" && -x "$2" ]] || {
    printf 'Usage: %s /path/to/uppy-gui /path/to/test-uppy-privileged\n' \
        "$0" >&2
    exit 2
}

GUI_SOURCE="$1"
HELPER_SOURCE="$2"
ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
TEMP_DIR="$(mktemp -d)"
STAGE_DIR="$TEMP_DIR/stage"
BIN_DIR="$TEMP_DIR/bin"
trap 'rm -rf -- "$TEMP_DIR"' EXIT

install -d "$STAGE_DIR" "$BIN_DIR" "$TEMP_DIR/state"
install -m 0700 "$HELPER_SOURCE" "$STAGE_DIR/uppy-privileged"
install -m 0700 "$ROOT_DIR/src/uppy-backend.sh" \
    "$STAGE_DIR/uppy-backend.sh"
install -m 0700 "$GUI_SOURCE" "$TEMP_DIR/uppy-gui"

cat > "$BIN_DIR/pkexec" <<'EOF'
#!/usr/bin/env bash
set -Eeuo pipefail
[[ "${1:-}" == */uppy-privileged ]] || {
    printf '[ERROR] GUI passed pkexec an unexpected program: %s\n' \
        "${1:-<missing>}" >&2
    exit 91
}
if [[ "${UPPY_MOCK_PKEXEC_STATUS:-0}" == "126" ||
      "${UPPY_MOCK_PKEXEC_STATUS:-0}" == "127" ]]; then
    exit "$UPPY_MOCK_PKEXEC_STATUS"
fi
export PKEXEC_UID
PKEXEC_UID="$(id -u)"
exec "$@"
EOF
chmod 0700 "$BIN_DIR/pkexec"

env -u XDG_RUNTIME_DIR \
    PATH="$BIN_DIR:/usr/bin:/bin" \
    XDG_STATE_HOME="$TEMP_DIR/state" \
    UPPY_BACKEND="$STAGE_DIR/uppy-backend.sh" \
    UPPY_PRIVILEGED_RUNNER="$STAGE_DIR/uppy-privileged" \
    UPPY_PRIVILEGE_CHAIN_TEST=1 \
    "$TEMP_DIR/uppy-gui" --test-privileged-launch \
    > "$TEMP_DIR/output" 2>&1

grep -Fq 'UPPY privilege-chain test passed' "$TEMP_DIR/output"
grep -Fq 'Administrator access granted to Uppy' "$TEMP_DIR/state/uppy/gui.log"
if grep -Fq '/usr/bin/bash --cancel-file' "$TEMP_DIR/state/uppy/gui.log"; then
    printf '[ERROR] GUI attempted to use Bash as the PolicyKit program.\n' >&2
    exit 1
fi

install -d -m 0700 "$TEMP_DIR/custom-runtime"
XDG_RUNTIME_DIR="$TEMP_DIR/custom-runtime" \
    PATH="$BIN_DIR:/usr/bin:/bin" \
    XDG_STATE_HOME="$TEMP_DIR/state" \
    UPPY_BACKEND="$STAGE_DIR/uppy-backend.sh" \
    UPPY_PRIVILEGED_RUNNER="$STAGE_DIR/uppy-privileged" \
    UPPY_PRIVILEGE_CHAIN_TEST=1 \
    "$TEMP_DIR/uppy-gui" --test-privileged-launch \
    > "$TEMP_DIR/custom-runtime-output" 2>&1
grep -Fq 'UPPY privilege-chain test passed' \
    "$TEMP_DIR/custom-runtime-output"

for expected_status in 126 127; do
    env -u XDG_RUNTIME_DIR \
        PATH="$BIN_DIR:/usr/bin:/bin" \
        XDG_STATE_HOME="$TEMP_DIR/state" \
        UPPY_BACKEND="$STAGE_DIR/uppy-backend.sh" \
        UPPY_PRIVILEGED_RUNNER="$STAGE_DIR/uppy-privileged" \
        UPPY_PRIVILEGE_CHAIN_TEST=1 \
        UPPY_TEST_EXPECT_PKEXEC_STATUS="$expected_status" \
        UPPY_MOCK_PKEXEC_STATUS="$expected_status" \
        "$TEMP_DIR/uppy-gui" --test-privileged-launch \
        > "$TEMP_DIR/output-$expected_status" 2>&1
done
grep -Fq 'cancellation handling passed' "$TEMP_DIR/output-126"
grep -Fq 'failure handling passed' "$TEMP_DIR/output-127"

printf 'test_privilege_chain: all tests passed\n'

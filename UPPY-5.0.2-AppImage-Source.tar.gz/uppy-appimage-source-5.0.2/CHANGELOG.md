# Changelog

## 5.0.2 — 2026-07-29

- Fixed compilation on Arch/CachyOS systems whose C library headers do not
  expose `realpath()` with Uppy's strict feature-test configuration.
- Removed the GUI's `realpath()` dependency and replaced it with an exact
  runtime-path comparison plus a non-following ownership/type check.
- Added a release regression gate that prevents the non-portable GUI
  dependency from being reintroduced.

## 5.0.1 — 2026-07-29

- Fixed PolicyKit failing before the password prompt because root could not
  traverse the temporary FUSE-mounted AppImage.
- Staged the privileged helper and backend in a private runtime directory and
  removed the staged files automatically when Uppy exits.
- Replaced the shell privilege boundary with a dedicated native helper, so
  PolicyKit authenticates the Uppy helper rather than a general-purpose shell.
- Added executable-directory probing and automatic fallback when the preferred
  runtime directory is mounted `noexec`.
- Kept previews and reports available with a precise in-app diagnostic if no
  executable staging directory exists.
- Added a dedicated **Sudo access** button that requests PolicyKit
  authentication without changing packages.
- Preserved a current package-removal preview when the authorization-only
  button is used.
- Added AppRun staging, cleanup, fallback and exit-code tests, plus a simulated
  GUI → PolicyKit → native helper → backend release gate.

## 5.0.0 source revision 2

- Added automatic build-dependency detection and optional installation.
- Added clear Arch/CachyOS, Fedora/Nobara, and Debian/Ubuntu install plans.
- Added `--check-deps`, `--install-deps`, `--yes`, and `--no-install-deps`
  controls to the AppImage builder.
- Made `run-from-source.sh` repair a missing compiler/dependency set instead of
  stopping at an unexplained `cc` error.
- Added compiler/linker probing and dependency-flow regression tests.

## 5.0.0 — 2026-07-21

- Replaced PySide6, Python and PyInstaller with a native C/Cairo interface.
- Added a strict AppImage limit below 25,000,000 bytes.
- Bundled the small X11/Cairo runtime-library closure for portability.
- Preserved Overview, Setup, Apps, Output and About pages.
- Added headless rendering so every page can be visually checked during builds.
- Added secure root-side cancellation for authenticated operations, including
  protection against orphaning the root process when `pkexec` is cancelled.
- Added clipboard paste to the name-only list editor.
- Added atomic settings writes, malformed-file protection and 1 MB config cap.
- Added 2 MB caps and rotation for GUI output/logs.
- Replaced obsolete Nobara updater invocation with `nobara-sync cli`.
- Rejected immutable Fedora variants that do not support direct host `dnf` use.
- Made dry-runs avoid backend log creation.
- Removed automatic script installation and script self-update code.
- Made Flatpak update/cleanup failures visible instead of silently succeeding.
- Added collision-resistant backup directories.
- Added strict unit, distro, privilege, rendering, AppDir and AppImage tests.
- Locked package removal until a successful preview of the exact current
  selection, with list-change and 10-minute expiry protection.
- Retained complete removal of NFS, CIFS/SMB and iSCSI features.

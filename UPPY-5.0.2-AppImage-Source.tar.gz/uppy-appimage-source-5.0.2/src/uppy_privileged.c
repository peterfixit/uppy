#define _GNU_SOURCE

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <signal.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/prctl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#ifndef PATH_MAX
#define PATH_MAX 4096
#endif

static volatile sig_atomic_t stop_signal = 0;

static void handle_signal(int signal_number) {
    stop_signal = signal_number;
}

static void print_errno(const char *message) {
    fprintf(stderr, "[ERROR] %s: %s\n", message, strerror(errno));
}

static bool parse_caller_uid(uid_t *caller_uid) {
    const char *text = getenv("PKEXEC_UID");
    char *end = NULL;
    unsigned long value;
    if (text == NULL || text[0] == '\0') {
        fputs("[ERROR] PolicyKit did not provide the caller UID.\n", stderr);
        return false;
    }
    errno = 0;
    value = strtoul(text, &end, 10);
    if (errno != 0 || end == text || *end != '\0' ||
        (unsigned long)(uid_t)value != value) {
        fputs("[ERROR] PolicyKit provided an invalid caller UID.\n", stderr);
        return false;
    }
    *caller_uid = (uid_t)value;
    return true;
}

static bool cancel_name_valid(const char *name) {
    const char *cursor;
    int hex_count = 0;
    if (strncmp(name, "cancel-", 7) != 0) return false;
    cursor = name + 7;
    if (!isdigit((unsigned char)*cursor)) return false;
    while (isdigit((unsigned char)*cursor)) ++cursor;
    if (*cursor++ != '-') return false;
    while (isxdigit((unsigned char)*cursor)) {
        ++hex_count;
        ++cursor;
    }
    return hex_count == 8 && *cursor == '\0';
}

static int token_state(int directory_fd, const char *name, uid_t caller_uid) {
    struct stat details;
    if (fstatat(directory_fd, name, &details, AT_SYMLINK_NOFOLLOW) != 0) {
        if (errno == ENOENT) return 0;
        return -1;
    }
    if (!S_ISREG(details.st_mode) || details.st_uid != caller_uid ||
        (details.st_mode & 0777) != 0600) {
        errno = EPERM;
        return -1;
    }
    return 1;
}

static bool prepare_cancel_path(const char *path, uid_t caller_uid,
                                int *directory_fd, char *token_name,
                                size_t token_name_size) {
    char parent[PATH_MAX];
    char resolved[PATH_MAX];
    char expected_runtime[PATH_MAX];
    char expected_tmp[PATH_MAX];
    const char *slash;
    const char *name;
    size_t parent_length;
    struct stat details;
    int descriptor;

    if (path == NULL || path[0] != '/') {
        fputs("[ERROR] The cancellation path is not absolute.\n", stderr);
        return false;
    }
    slash = strrchr(path, '/');
    if (slash == NULL || slash[1] == '\0') {
        fputs("[ERROR] The cancellation path has no valid token name.\n", stderr);
        return false;
    }
    name = slash + 1;
    if (!cancel_name_valid(name) || strlen(name) >= token_name_size) {
        fputs("[ERROR] The cancellation token name is invalid.\n", stderr);
        return false;
    }
    parent_length = slash == path ? 1U : (size_t)(slash - path);
    if (parent_length >= sizeof(parent)) {
        fputs("[ERROR] The cancellation directory path is too long.\n", stderr);
        return false;
    }
    memcpy(parent, path, parent_length);
    parent[parent_length] = '\0';
    if (realpath(parent, resolved) == NULL) {
        print_errno("Could not resolve the cancellation directory");
        return false;
    }
    if (snprintf(expected_runtime, sizeof(expected_runtime),
                 "/run/user/%lu/uppy", (unsigned long)caller_uid) >=
            (int)sizeof(expected_runtime) ||
        snprintf(expected_tmp, sizeof(expected_tmp),
                 "/tmp/uppy-%lu", (unsigned long)caller_uid) >=
            (int)sizeof(expected_tmp)) {
        fputs("[ERROR] The expected cancellation path is too long.\n", stderr);
        return false;
    }
    if (strcmp(resolved, expected_runtime) != 0 &&
        strcmp(resolved, expected_tmp) != 0) {
        fputs("[ERROR] The cancellation directory is outside Uppy's allowed locations.\n",
              stderr);
        return false;
    }
    if (lstat(resolved, &details) != 0 || !S_ISDIR(details.st_mode) ||
        S_ISLNK(details.st_mode) || details.st_uid != caller_uid ||
        (details.st_mode & 0777) != 0700) {
        fputs("[ERROR] The cancellation directory has unsafe ownership or permissions.\n",
              stderr);
        return false;
    }
    descriptor = open(resolved, O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
    if (descriptor < 0) {
        print_errno("Could not open the cancellation directory");
        return false;
    }
    if (fstat(descriptor, &details) != 0 || !S_ISDIR(details.st_mode) ||
        details.st_uid != caller_uid || (details.st_mode & 0777) != 0700) {
        close(descriptor);
        fputs("[ERROR] The opened cancellation directory is unsafe.\n", stderr);
        return false;
    }
    memcpy(token_name, name, strlen(name) + 1);
    *directory_fd = descriptor;
    return true;
}

static bool resolve_backend(const char *argv0, uid_t caller_uid,
                            char *backend, size_t backend_size) {
    char executable[PATH_MAX];
    char *slash;
    ssize_t length;
    struct stat details;
    length = readlink("/proc/self/exe", executable, sizeof(executable) - 1);
    if (length < 0) {
        if (realpath(argv0, executable) == NULL) {
            print_errno("Could not resolve the privileged helper");
            return false;
        }
    } else {
        executable[length] = '\0';
    }
    slash = strrchr(executable, '/');
    if (slash == NULL) {
        fputs("[ERROR] The privileged helper path is invalid.\n", stderr);
        return false;
    }
    *slash = '\0';
    if (snprintf(backend, backend_size, "%s/uppy-backend.sh", executable) >=
        (int)backend_size) {
        fputs("[ERROR] The Uppy backend path is too long.\n", stderr);
        return false;
    }
    if (lstat(backend, &details) != 0 || !S_ISREG(details.st_mode) ||
        details.st_uid != caller_uid || (details.st_mode & 0022) != 0 ||
        (details.st_mode & S_IRUSR) == 0) {
        fputs("[ERROR] The staged Uppy backend has unsafe ownership or permissions.\n",
              stderr);
        return false;
    }
    return true;
}

static const char *find_bash(void) {
    static const char *candidates[] = {"/usr/bin/bash", "/bin/bash"};
    size_t index;
    for (index = 0; index < sizeof(candidates) / sizeof(candidates[0]); ++index)
        if (access(candidates[index], X_OK) == 0) return candidates[index];
    return NULL;
}

static void sanitize_environment(void) {
    static const char *names[] = {
        "BASH_ENV", "CDPATH", "ENV", "GLOBIGNORE", "IFS", "LD_AUDIT",
        "LD_LIBRARY_PATH", "LD_PRELOAD", "PYTHONPATH", "UPPY_OS_RELEASE_FILE",
        "UPPY_TESTING"
    };
    size_t index;
    for (index = 0; index < sizeof(names) / sizeof(names[0]); ++index)
        unsetenv(names[index]);
    setenv("APPIMAGE", "UPPY-AppImage", 1);
    setenv("LC_ALL", "C", 1);
    setenv("NO_COLOR", "1", 1);
    setenv("PATH", "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin", 1);
}

static void sleep_100ms(void) {
    struct timespec delay = {0, 100000000L};
    while (nanosleep(&delay, &delay) != 0 && errno == EINTR) {
    }
}

static bool wait_for_child(pid_t child, int *status, int attempts) {
    int index;
    for (index = 0; index < attempts; ++index) {
        pid_t result = waitpid(child, status, WNOHANG);
        if (result == child) return true;
        if (result < 0 && errno != EINTR) return true;
        sleep_100ms();
    }
    return false;
}

static void stop_child(pid_t child, int *status) {
    (void)kill(-child, SIGTERM);
    (void)kill(child, SIGTERM);
    if (wait_for_child(child, status, 50)) return;
    (void)kill(-child, SIGKILL);
    (void)kill(child, SIGKILL);
    while (waitpid(child, status, 0) < 0 && errno == EINTR) {
    }
}

static int status_code(int status) {
    if (WIFEXITED(status)) return WEXITSTATUS(status);
    if (WIFSIGNALED(status)) return 128 + WTERMSIG(status);
    return 1;
}

static int supervise_backend(const char *bash, const char *backend,
                             int backend_argc, char **backend_args,
                             int cancel_directory_fd, const char *cancel_name,
                             uid_t caller_uid) {
    struct sigaction action;
    pid_t child;
    int status = 0;
    char **arguments;
    int index;

    arguments = calloc((size_t)backend_argc + 3U, sizeof(*arguments));
    if (arguments == NULL) {
        fputs("[ERROR] Not enough memory to start the Uppy backend.\n", stderr);
        return 1;
    }
    arguments[0] = (char *)bash;
    arguments[1] = (char *)backend;
    for (index = 0; index < backend_argc; ++index)
        arguments[index + 2] = backend_args[index];

    memset(&action, 0, sizeof(action));
    action.sa_handler = handle_signal;
    sigemptyset(&action.sa_mask);
    sigaction(SIGTERM, &action, NULL);
    sigaction(SIGINT, &action, NULL);
    sigaction(SIGHUP, &action, NULL);
    (void)prctl(PR_SET_PDEATHSIG, SIGTERM);
    if (getppid() == 1) stop_signal = SIGTERM;

    child = fork();
    if (child < 0) {
        free(arguments);
        print_errno("Could not start the Uppy backend");
        return 1;
    }
    if (child == 0) {
        struct sigaction child_action;
        memset(&child_action, 0, sizeof(child_action));
        child_action.sa_handler = SIG_DFL;
        sigemptyset(&child_action.sa_mask);
        sigaction(SIGTERM, &child_action, NULL);
        sigaction(SIGINT, &child_action, NULL);
        sigaction(SIGHUP, &child_action, NULL);
        (void)prctl(PR_SET_PDEATHSIG, SIGTERM);
        if (setsid() < 0) {
            print_errno("Could not create the backend process group");
            _exit(1);
        }
        execv(bash, arguments);
        print_errno("Could not execute the Uppy backend");
        _exit(127);
    }
    free(arguments);

    for (;;) {
        pid_t result = waitpid(child, &status, WNOHANG);
        int cancellation;
        if (result == child) return status_code(status);
        if (result < 0 && errno != EINTR) {
            print_errno("Could not monitor the Uppy backend");
            stop_child(child, &status);
            return 1;
        }
        if (stop_signal != 0) {
            int signal_number = stop_signal;
            fputs("[INFO] Privileged task interrupted; stopping Uppy.\n", stdout);
            stop_child(child, &status);
            return 128 + signal_number;
        }
        cancellation = token_state(cancel_directory_fd, cancel_name, caller_uid);
        if (cancellation == 1) {
            fputs("[INFO] Cancellation requested; stopping Uppy.\n", stdout);
            stop_child(child, &status);
            return 130;
        }
        if (cancellation < 0) {
            fputs("[WARN] Ignoring an unsafe cancellation token.\n", stderr);
            (void)unlinkat(cancel_directory_fd, cancel_name, 0);
        }
        sleep_100ms();
    }
}

int main(int argc, char **argv) {
    uid_t caller_uid;
    int cancel_directory_fd = -1;
    char cancel_name[128];
    char backend[PATH_MAX];
    const char *bash;
    int cancellation;
    int result;

    if (argc == 2 && strcmp(argv[1], "--stage-probe") == 0) return 0;
#ifndef UPPY_HELPER_ALLOW_UNPRIVILEGED_TESTS
    if (geteuid() != 0) {
        fputs("[ERROR] Uppy privileged operations must be started through PolicyKit.\n",
              stderr);
        return 126;
    }
#endif
    if (argc < 5 || strcmp(argv[1], "--cancel-file") != 0 ||
        strcmp(argv[3], "--") != 0) {
        fputs("[ERROR] Invalid privileged-helper arguments.\n", stderr);
        return 2;
    }
    if (!parse_caller_uid(&caller_uid) ||
        !prepare_cancel_path(argv[2], caller_uid, &cancel_directory_fd,
                             cancel_name, sizeof(cancel_name)) ||
        !resolve_backend(argv[0], caller_uid, backend, sizeof(backend))) {
        if (cancel_directory_fd >= 0) close(cancel_directory_fd);
        return 1;
    }
    bash = find_bash();
    if (bash == NULL) {
        fputs("[ERROR] Bash is required to run the Uppy backend.\n", stderr);
        close(cancel_directory_fd);
        return 1;
    }
    sanitize_environment();
    cancellation = token_state(cancel_directory_fd, cancel_name, caller_uid);
    if (cancellation == 1) {
        fputs("[INFO] Cancellation requested before the task started.\n", stdout);
        (void)unlinkat(cancel_directory_fd, cancel_name, 0);
        close(cancel_directory_fd);
        return 130;
    }
    if (cancellation < 0) {
        fputs("[ERROR] The existing cancellation token is unsafe.\n", stderr);
        (void)unlinkat(cancel_directory_fd, cancel_name, 0);
        close(cancel_directory_fd);
        return 1;
    }
    if (strcmp(argv[4], "--authorize") == 0) {
        if (argc != 5) {
            fputs("[ERROR] The authorization check does not accept extra arguments.\n",
                  stderr);
            close(cancel_directory_fd);
            return 2;
        }
        fputs("[OK] Administrator access granted to Uppy.\n", stdout);
        close(cancel_directory_fd);
        return 0;
    }
    result = supervise_backend(bash, backend, argc - 4, &argv[4],
                               cancel_directory_fd, cancel_name, caller_uid);
    (void)unlinkat(cancel_directory_fd, cancel_name, 0);
    close(cancel_directory_fd);
    return result;
}

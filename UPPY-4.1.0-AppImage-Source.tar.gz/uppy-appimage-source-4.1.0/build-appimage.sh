#!/usr/bin/env bash

set -Eeuo pipefail

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
VERSION="4.1.0"
PYTHON="${PYTHON:-python3}"
BUILD_DIR="${UPPY_BUILD_DIR:-$ROOT_DIR/.build}"
OUTPUT_DIR="${UPPY_OUTPUT_DIR:-$ROOT_DIR/dist-appimage}"
VENV_DIR="$BUILD_DIR/venv"
APPDIR="$BUILD_DIR/UPPY.AppDir"

case "$(uname -m)" in
    x86_64)
        APPIMAGE_ARCH="x86_64"
        TOOL_ASSET="appimagetool-x86_64.AppImage"
        ;;
    aarch64|arm64)
        APPIMAGE_ARCH="aarch64"
        TOOL_ASSET="appimagetool-aarch64.AppImage"
        ;;
    *)
        printf '[ERROR] Unsupported build architecture: %s\n' "$(uname -m)" >&2
        exit 1
        ;;
esac

if ! command -v "$PYTHON" >/dev/null 2>&1; then
    printf '[ERROR] Required Python interpreter not found: %s\n' "$PYTHON" >&2
    exit 1
fi

"$ROOT_DIR/scripts/check-source.sh"

printf '\n[1/5] Preparing isolated build environment\n'
install -d "$BUILD_DIR" "$OUTPUT_DIR"
if [[ ! -x "$VENV_DIR/bin/python" ]]; then
    "$PYTHON" -m venv "$VENV_DIR"
fi
"$VENV_DIR/bin/python" -m pip install --upgrade pip wheel
"$VENV_DIR/bin/python" -m pip install -r "$ROOT_DIR/requirements-build.txt"

printf '\n[2/5] Freezing the Qt interface\n'
"$VENV_DIR/bin/pyinstaller" \
    --noconfirm \
    --clean \
    --windowed \
    --name uppy-gui \
    --paths "$ROOT_DIR/src" \
    --distpath "$BUILD_DIR/pyinstaller-dist" \
    --workpath "$BUILD_DIR/pyinstaller-work" \
    --specpath "$BUILD_DIR" \
    "$ROOT_DIR/src/main.py"

printf '\n[3/5] Assembling AppDir\n'
if [[ -d "$APPDIR" ]]; then
    rm -rf -- "$APPDIR"
fi
install -d \
    "$APPDIR/usr/lib/uppy" \
    "$APPDIR/usr/bin" \
    "$APPDIR/usr/share/applications" \
    "$APPDIR/usr/share/icons/hicolor/scalable/apps" \
    "$APPDIR/usr/share/doc/uppy"

cp -a "$BUILD_DIR/pyinstaller-dist/uppy-gui" "$APPDIR/usr/lib/uppy/gui"
ln -s "../lib/uppy/gui/uppy-gui" "$APPDIR/usr/bin/uppy-gui"
install -m 0755 "$ROOT_DIR/src/uppy-backend.sh" "$APPDIR/usr/lib/uppy/uppy-backend.sh"
install -m 0755 "$ROOT_DIR/scripts/uppy-privileged" "$APPDIR/usr/lib/uppy/uppy-privileged"
install -m 0755 "$ROOT_DIR/packaging/AppRun" "$APPDIR/AppRun"
install -m 0644 "$ROOT_DIR/packaging/io.pmhs.uppy.desktop" "$APPDIR/usr/share/applications/io.pmhs.uppy.desktop"
install -m 0644 "$ROOT_DIR/packaging/io.pmhs.uppy.svg" "$APPDIR/usr/share/icons/hicolor/scalable/apps/io.pmhs.uppy.svg"
install -m 0644 "$ROOT_DIR/LICENSE" "$APPDIR/usr/share/doc/uppy/LICENSE"
install -m 0644 "$ROOT_DIR/README.md" "$APPDIR/usr/share/doc/uppy/README.md"
install -m 0644 "$ROOT_DIR/THIRD_PARTY_NOTICES.md" "$APPDIR/usr/share/doc/uppy/THIRD_PARTY_NOTICES.md"
ln -s "usr/share/applications/io.pmhs.uppy.desktop" "$APPDIR/io.pmhs.uppy.desktop"
ln -s "usr/share/icons/hicolor/scalable/apps/io.pmhs.uppy.svg" "$APPDIR/io.pmhs.uppy.svg"
ln -s "io.pmhs.uppy.svg" "$APPDIR/.DirIcon"

printf '\n[4/5] Preparing appimagetool\n'
if [[ -n "${APPIMAGETOOL:-}" ]]; then
    TOOL="$APPIMAGETOOL"
elif command -v appimagetool >/dev/null 2>&1; then
    TOOL="$(command -v appimagetool)"
else
    TOOL="$BUILD_DIR/tools/$TOOL_ASSET"
    if [[ ! -x "$TOOL" ]]; then
        if [[ "${NO_DOWNLOAD:-0}" == "1" ]]; then
            printf '[ERROR] appimagetool is unavailable and NO_DOWNLOAD=1.\n' >&2
            exit 1
        fi
        install -d "$(dirname -- "$TOOL")"
        TOOL_URL="https://github.com/AppImage/AppImageKit/releases/download/continuous/$TOOL_ASSET"
        if command -v curl >/dev/null 2>&1; then
            curl --fail --location --show-error "$TOOL_URL" --output "$TOOL"
        elif command -v wget >/dev/null 2>&1; then
            wget --output-document="$TOOL" "$TOOL_URL"
        else
            printf '[ERROR] curl or wget is required to download appimagetool.\n' >&2
            exit 1
        fi
        chmod 0755 "$TOOL"
    fi
fi

if [[ ! -x "$TOOL" ]]; then
    printf '[ERROR] appimagetool is not executable: %s\n' "$TOOL" >&2
    exit 1
fi

printf '\n[5/5] Building AppImage\n'
OUTPUT="$OUTPUT_DIR/UPPY-$VERSION-$APPIMAGE_ARCH.AppImage"
TOOL_ARGS=()
if [[ ! -e /dev/fuse ]] || ! command -v fusermount >/dev/null 2>&1; then
    TOOL_ARGS+=(--appimage-extract-and-run)
fi
ARCH="$APPIMAGE_ARCH" "$TOOL" "${TOOL_ARGS[@]}" "$APPDIR" "$OUTPUT"
chmod 0755 "$OUTPUT"

printf '\nBuild complete:\n  %s\n' "$OUTPUT"
sha256sum "$OUTPUT"

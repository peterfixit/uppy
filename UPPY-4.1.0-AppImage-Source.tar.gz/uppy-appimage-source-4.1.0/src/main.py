#!/usr/bin/env python3
"""Polished Qt front end for the UPPY 4.1.0 shell backend."""

from __future__ import annotations

import html
import os
import platform
import shutil
import sys
from datetime import datetime
from pathlib import Path

from PySide6.QtCore import QProcess, QProcessEnvironment, Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QCloseEvent, QDesktopServices, QFont, QIcon, QPixmap, QTextCursor
from PySide6.QtWidgets import (
    QApplication,
    QButtonGroup,
    QCheckBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from uppy_core import (
    APP_VERSION,
    ConfigError,
    app_arguments,
    config_path,
    default_config,
    display_command,
    execution_arguments,
    load_config,
    normalize_config,
    save_config,
    setup_arguments,
    state_log_path,
    text_to_entries,
    update_arguments,
)


APP_ID = "io.pmhs.uppy"
PROJECT_ROOT = Path(__file__).resolve().parent.parent


def appdir() -> Path | None:
    value = os.environ.get("APPDIR")
    return Path(value).resolve() if value else None


def resource_path() -> Path:
    root = appdir()
    if root:
        return root / "usr/share/icons/hicolor/scalable/apps/io.pmhs.uppy.svg"
    return PROJECT_ROOT / "packaging/io.pmhs.uppy.svg"


def backend_path() -> Path:
    override = os.environ.get("UPPY_BACKEND")
    if override:
        return Path(override).resolve()
    root = appdir()
    if root:
        return root / "usr/lib/uppy/uppy-backend.sh"
    return PROJECT_ROOT / "src/uppy-backend.sh"


def privileged_runner_path() -> Path:
    override = os.environ.get("UPPY_PRIVILEGED_RUNNER")
    if override:
        return Path(override).resolve()
    root = appdir()
    if root:
        return root / "usr/lib/uppy/uppy-privileged"
    return PROJECT_ROOT / "scripts/uppy-privileged"


def os_name() -> str:
    try:
        values: dict[str, str] = {}
        for line in Path("/etc/os-release").read_text(encoding="utf-8").splitlines():
            if "=" in line:
                key, value = line.split("=", 1)
                values[key] = value.strip().strip('"')
        return values.get("PRETTY_NAME", platform.system())
    except OSError:
        return platform.system()


def page_shell(title: str, subtitle: str) -> tuple[QScrollArea, QVBoxLayout]:
    scroll = QScrollArea()
    scroll.setWidgetResizable(True)
    scroll.setFrameShape(QFrame.Shape.NoFrame)
    body = QWidget()
    layout = QVBoxLayout(body)
    layout.setContentsMargins(32, 28, 32, 32)
    layout.setSpacing(18)

    heading = QLabel(title)
    heading.setObjectName("pageTitle")
    description = QLabel(subtitle)
    description.setObjectName("pageSubtitle")
    description.setWordWrap(True)
    layout.addWidget(heading)
    layout.addWidget(description)
    scroll.setWidget(body)
    return scroll, layout


def card(title: str, description: str = "") -> tuple[QFrame, QVBoxLayout]:
    frame = QFrame()
    frame.setObjectName("card")
    layout = QVBoxLayout(frame)
    layout.setContentsMargins(20, 18, 20, 18)
    layout.setSpacing(12)
    label = QLabel(title)
    label.setObjectName("cardTitle")
    layout.addWidget(label)
    if description:
        detail = QLabel(description)
        detail.setObjectName("muted")
        detail.setWordWrap(True)
        layout.addWidget(detail)
    return frame, layout


def banner(text: str, kind: str = "info") -> QFrame:
    frame = QFrame()
    frame.setProperty("kind", kind)
    frame.setObjectName("banner")
    layout = QHBoxLayout(frame)
    layout.setContentsMargins(16, 12, 16, 12)
    label = QLabel(text)
    label.setWordWrap(True)
    layout.addWidget(label)
    return frame


def action_button(text: str, *, primary: bool = False, danger: bool = False) -> QPushButton:
    button = QPushButton(text)
    if primary:
        button.setProperty("role", "primary")
    elif danger:
        button.setProperty("role", "danger")
    return button


class ConfirmationDialog(QDialog):
    def __init__(self, title: str, summary: str, command: str, danger: str = "", parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumWidth(640)
        self.setModal(True)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 22, 24, 22)
        layout.setSpacing(14)

        heading = QLabel(title)
        heading.setObjectName("dialogTitle")
        layout.addWidget(heading)

        detail = QLabel(summary)
        detail.setWordWrap(True)
        layout.addWidget(detail)

        if danger:
            layout.addWidget(banner(danger, "warning"))

        command_label = QLabel("Command that will be sent to the UPPY backend")
        command_label.setObjectName("muted")
        layout.addWidget(command_label)
        command_box = QPlainTextEdit(command)
        command_box.setReadOnly(True)
        command_box.setMaximumHeight(92)
        command_box.setObjectName("commandPreview")
        layout.addWidget(command_box)

        self.reviewed = QCheckBox("I have reviewed the selected changes and want to continue.")
        layout.addWidget(self.reviewed)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Cancel)
        self.run_button = buttons.addButton("Run changes", QDialogButtonBox.ButtonRole.AcceptRole)
        self.run_button.setProperty("role", "primary")
        self.run_button.setEnabled(False)
        buttons.rejected.connect(self.reject)
        self.run_button.clicked.connect(self.accept)
        self.reviewed.toggled.connect(self.run_button.setEnabled)
        layout.addWidget(buttons)


class BackendProcess(QProcess):
    text_available = Signal(str)
    launch_failed = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setProcessChannelMode(QProcess.ProcessChannelMode.MergedChannels)
        self.readyReadStandardOutput.connect(self._read_output)
        self.errorOccurred.connect(self._on_error)

    def _read_output(self) -> None:
        data = bytes(self.readAllStandardOutput()).decode("utf-8", errors="replace")
        if data:
            self.text_available.emit(data)

    def _on_error(self, error: QProcess.ProcessError) -> None:
        if error == QProcess.ProcessError.FailedToStart:
            self.launch_failed.emit(self.errorString())

    def launch(self, arguments: list[str], *, privileged: bool) -> tuple[str, list[str]]:
        backend = backend_path()
        helper = privileged_runner_path()
        if not backend.is_file():
            raise RuntimeError(f"UPPY backend was not found: {backend}")

        if privileged:
            pkexec = shutil.which("pkexec")
            if not pkexec:
                raise RuntimeError(
                    "pkexec was not found. Install your distribution's PolicyKit package to run system changes."
                )
            if not helper.is_file():
                raise RuntimeError(f"Privileged runner was not found: {helper}")
            program = pkexec
            process_args = [str(helper), *arguments]
        else:
            program = str(backend)
            process_args = arguments

        environment = QProcessEnvironment.systemEnvironment()
        environment.insert("APPIMAGE", os.environ.get("APPIMAGE", "UPPY-AppImage"))
        environment.insert("LC_ALL", "C")
        self.setProcessEnvironment(environment)
        self.setProgram(program)
        self.setArguments(process_args)
        self.start()
        return program, process_args


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"UPPY {APP_VERSION}")
        self.setWindowIcon(QIcon(str(resource_path())))
        self.resize(1120, 760)
        self.setMinimumSize(940, 660)

        try:
            self.config = load_config()
            self.config_message = f"Settings: {config_path()}"
        except ConfigError as exc:
            self.config = default_config()
            self.config_message = "Configuration could not be loaded; safe defaults are active."
            message = str(exc)
            QTimer.singleShot(0, lambda: self.show_error("Configuration error", message))

        self.process = BackendProcess(self)
        self.process.text_available.connect(self.append_output)
        self.process.finished.connect(self.process_finished)
        self.process.launch_failed.connect(self.process_launch_failed)
        self.current_label = ""
        self.action_buttons: list[QPushButton] = []
        self.loading_widgets = True
        self.app_lists_dirty = False

        self.stack = QStackedWidget()
        root = QWidget()
        root_layout = QHBoxLayout(root)
        root_layout.setContentsMargins(0, 0, 0, 0)
        root_layout.setSpacing(0)
        root_layout.addWidget(self.build_sidebar())
        root_layout.addWidget(self.stack, 1)
        self.setCentralWidget(root)

        pages = [
            self.build_dashboard_page(),
            self.build_setup_page(),
            self.build_apps_page(),
            self.build_output_page(),
            self.build_about_page(),
        ]
        for page in pages:
            self.stack.addWidget(page)
        self.populate_config_widgets()
        self.loading_widgets = False
        self.update_app_list_status(saved=True)
        self.nav_buttons[0].setChecked(True)

    def build_sidebar(self) -> QFrame:
        sidebar = QFrame()
        sidebar.setObjectName("sidebar")
        sidebar.setFixedWidth(224)
        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(18, 24, 18, 18)
        layout.setSpacing(8)

        brand_row = QHBoxLayout()
        icon = QLabel()
        pixmap = QPixmap(str(resource_path()))
        icon.setPixmap(pixmap.scaled(46, 46, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        brand_row.addWidget(icon)
        text_box = QVBoxLayout()
        name = QLabel("UPPY")
        name.setObjectName("brand")
        version = QLabel(f"Version {APP_VERSION}")
        version.setObjectName("sidebarMuted")
        text_box.addWidget(name)
        text_box.addWidget(version)
        brand_row.addLayout(text_box)
        layout.addLayout(brand_row)
        layout.addSpacing(20)

        self.nav_group = QButtonGroup(self)
        self.nav_group.setExclusive(True)
        self.nav_buttons: list[QPushButton] = []
        for index, label in enumerate(("Overview", "Setup", "Apps", "Output", "About")):
            button = QPushButton(label)
            button.setCheckable(True)
            button.setObjectName("navButton")
            button.clicked.connect(lambda checked=False, page=index: self.stack.setCurrentIndex(page))
            self.nav_group.addButton(button)
            self.nav_buttons.append(button)
            layout.addWidget(button)

        layout.addStretch(1)
        self.sidebar_status = QLabel("READY")
        self.sidebar_status.setObjectName("statusReady")
        self.sidebar_status.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.sidebar_status)
        config_label = QLabel(self.config_message)
        config_label.setObjectName("sidebarMuted")
        config_label.setWordWrap(True)
        layout.addWidget(config_label)
        return sidebar

    def build_dashboard_page(self) -> QWidget:
        page, layout = page_shell(
            "System overview",
            "Update and maintain the operating system with a preview-first workflow.",
        )
        system_card, system_layout = card("This system")
        info_grid = QGridLayout()
        info_grid.addWidget(QLabel("Operating system"), 0, 0)
        os_value = QLabel(os_name())
        os_value.setObjectName("value")
        info_grid.addWidget(os_value, 0, 1)
        info_grid.addWidget(QLabel("Architecture"), 1, 0)
        arch_value = QLabel(platform.machine())
        arch_value.setObjectName("value")
        info_grid.addWidget(arch_value, 1, 1)
        info_grid.addWidget(QLabel("Backend"), 2, 0)
        backend_value = QLabel(f"UPPY {APP_VERSION}")
        backend_value.setObjectName("value")
        info_grid.addWidget(backend_value, 2, 1)
        info_grid.addWidget(QLabel("Saved custom entries"), 3, 0)
        self.saved_app_count = QLabel("0")
        self.saved_app_count.setObjectName("value")
        info_grid.addWidget(self.saved_app_count, 3, 1)
        info_grid.setColumnStretch(1, 1)
        system_layout.addLayout(info_grid)
        layout.addWidget(system_card)

        update_card, update_layout = card(
            "Routine update",
            "Updates native system packages and system-wide Flatpaks. Optional maintenance removes orphan packages and cleans caches.",
        )
        self.update_maintenance = QCheckBox("Include optional package and cache maintenance")
        self.update_reboot = QCheckBox("Reboot after the update")
        self.update_reboot.toggled.connect(
            lambda enabled: self.update_maintenance.setEnabled(not enabled)
        )
        update_layout.addWidget(self.update_maintenance)
        update_layout.addWidget(self.update_reboot)
        update_buttons = QHBoxLayout()
        preview = action_button("Preview update")
        run = action_button("Run update", primary=True)
        preview.clicked.connect(lambda: self.run_update(preview=True))
        run.clicked.connect(lambda: self.run_update(preview=False))
        self.register_actions(preview, run)
        update_buttons.addStretch(1)
        update_buttons.addWidget(preview)
        update_buttons.addWidget(run)
        update_layout.addLayout(update_buttons)
        layout.addWidget(update_card)

        maintenance_card, maintenance_layout = card(
            "Maintenance tools",
            "Reports and backups run without administrator access. Cleanup requests authentication only when applied.",
        )
        buttons = QGridLayout()
        check = action_button("System check")
        managed = action_button("List managed software")
        backup = action_button("Create backup")
        preview_clean = action_button("Preview cleanup")
        run_clean = action_button("Run cleanup", danger=True)
        check.clicked.connect(lambda: self.run_simple("System check", ["--check"], False))
        managed.clicked.connect(lambda: self.run_simple("Managed software", ["--list-software"], False))
        backup.clicked.connect(lambda: self.run_simple("Configuration backup", ["--backup"], False))
        preview_clean.clicked.connect(lambda: self.run_simple("Cleanup preview", execution_arguments(["--clean"], preview=True), False))
        run_clean.clicked.connect(self.run_cleanup)
        self.register_actions(check, managed, backup, preview_clean, run_clean)
        for index, button in enumerate((check, managed, backup, preview_clean, run_clean)):
            buttons.addWidget(button, index // 3, index % 3)
        maintenance_layout.addLayout(buttons)
        layout.addWidget(maintenance_card)
        layout.addStretch(1)
        return page

    def build_setup_page(self) -> QWidget:
        page, layout = page_shell(
            "System setup",
            "Choose exactly what to install or remove. Preview the package plan before applying it.",
        )
        layout.addWidget(
            banner(
                "Administrator access is requested once when changes start. Preview mode does not change the system.",
                "info",
            )
        )
        selection_card, selection_layout = card("Setup sections")
        grid = QGridLayout()
        self.setup_checks: dict[str, QCheckBox] = {}
        setup_items = (
            ("core", "Core packages", "Flatpak and the configured essential native tools."),
            ("workstation", "Workstation apps", "Configured system-wide Flatpak applications."),
            ("gaming", "Gaming apps", "Gaming Flatpaks and CachyOS gaming package."),
            ("additional_apps", "Additional apps", "Package names entered on the Apps page."),
            ("remove_software", "Remove bloat", "Configured distro list plus names on the Apps page."),
        )
        for index, (key, title, detail) in enumerate(setup_items):
            box = QFrame()
            box.setObjectName("choiceBox")
            box_layout = QVBoxLayout(box)
            checkbox = QCheckBox(title)
            checkbox.setObjectName("choiceTitle")
            detail_label = QLabel(detail)
            detail_label.setObjectName("muted")
            detail_label.setWordWrap(True)
            box_layout.addWidget(checkbox)
            box_layout.addWidget(detail_label)
            self.setup_checks[key] = checkbox
            grid.addWidget(box, index // 2, index % 2)
        selection_layout.addLayout(grid)

        select_row = QHBoxLayout()
        select_all = QPushButton("Select all")
        clear = QPushButton("Clear selection")
        select_all.clicked.connect(lambda: [box.setChecked(True) for box in self.setup_checks.values()])
        clear.clicked.connect(lambda: [box.setChecked(False) for box in self.setup_checks.values()])
        select_row.addWidget(select_all)
        select_row.addWidget(clear)
        select_row.addStretch(1)
        selection_layout.addLayout(select_row)
        layout.addWidget(selection_card)

        layout.addWidget(
            banner(
                "Package removals are shown in the preview and again in the confirmation dialog. UPPY never accepts free-form shell commands.",
                "warning",
            )
        )

        run_row = QHBoxLayout()
        preview = action_button("Preview selected setup")
        run = action_button("Run selected setup", primary=True)
        preview.clicked.connect(lambda: self.run_setup(preview=True))
        run.clicked.connect(lambda: self.run_setup(preview=False))
        self.register_actions(preview, run)
        run_row.addStretch(1)
        run_row.addWidget(preview)
        run_row.addWidget(run)
        layout.addLayout(run_row)
        layout.addStretch(1)
        return page

    def make_list_editor(self, title: str, placeholder: str) -> tuple[QFrame, QPlainTextEdit]:
        frame, layout = card(title, "One exact package name or application ID per line. No descriptions.")
        editor = QPlainTextEdit()
        editor.setPlaceholderText(placeholder)
        editor.setMinimumHeight(145)
        editor.setObjectName("listEditor")
        layout.addWidget(editor)
        return frame, editor

    def build_apps_page(self) -> QWidget:
        page, layout = page_shell(
            "Apps and bloat removal",
            "Maintain simple name-only lists for extra system packages, Flatpaks, Snaps, and removal targets.",
        )
        layout.addWidget(
            banner(
                "These lists are editable. UPPY changes nothing merely because a name is saved here; you must select and confirm an install or removal action.",
                "info",
            )
        )
        grid = QGridLayout()
        system_card, self.system_editor = self.make_list_editor("System packages to add", "htop\npackage-name")
        flatpak_card, self.flatpak_editor = self.make_list_editor("Flatpaks to add", "org.example.Application")
        snap_card, self.snap_editor = self.make_list_editor("Snaps to add", "snap-name")
        remove_card, self.remove_editor = self.make_list_editor("System packages to remove", "package-name")
        remove_card.setProperty("dangerCard", True)
        grid.addWidget(system_card, 0, 0)
        grid.addWidget(flatpak_card, 0, 1)
        grid.addWidget(snap_card, 1, 0)
        grid.addWidget(remove_card, 1, 1)
        layout.addLayout(grid)

        for editor in (
            self.system_editor,
            self.flatpak_editor,
            self.snap_editor,
            self.remove_editor,
        ):
            editor.textChanged.connect(self.mark_app_lists_dirty)

        self.app_list_status = QLabel()
        self.app_list_status.setObjectName("editorStatus")
        layout.addWidget(self.app_list_status)

        controls = QHBoxLayout()
        save = action_button("Save lists")
        reset = action_button("Discard unsaved edits")
        preview_add = action_button("Preview app installs")
        install = action_button("Install listed apps", primary=True)
        preview_remove = action_button("Preview removals")
        remove = action_button("Remove listed bloat", danger=True)
        save.clicked.connect(self.save_current_config)
        reset.clicked.connect(self.discard_app_edits)
        preview_add.clicked.connect(lambda: self.run_apps(True, False, True))
        install.clicked.connect(lambda: self.run_apps(True, False, False))
        preview_remove.clicked.connect(lambda: self.run_apps(False, True, True))
        remove.clicked.connect(lambda: self.run_apps(False, True, False))
        self.register_actions(save, reset, preview_add, install, preview_remove, remove)
        controls.addWidget(save)
        controls.addWidget(reset)
        controls.addStretch(1)
        controls.addWidget(preview_add)
        controls.addWidget(install)
        controls.addWidget(preview_remove)
        controls.addWidget(remove)
        layout.addLayout(controls)
        return page

    def build_output_page(self) -> QWidget:
        page, layout = page_shell(
            "Output",
            "Live output from the UPPY backend. Full output is also appended to the per-user GUI log.",
        )
        status_row = QHBoxLayout()
        self.run_status = QLabel("Ready")
        self.run_status.setObjectName("runStatus")
        status_row.addWidget(self.run_status)
        status_row.addStretch(1)
        self.cancel_button = action_button("Cancel running task", danger=True)
        self.cancel_button.setEnabled(False)
        self.cancel_button.clicked.connect(self.cancel_process)
        status_row.addWidget(self.cancel_button)
        layout.addLayout(status_row)

        self.output = QPlainTextEdit()
        self.output.setReadOnly(True)
        self.output.setObjectName("output")
        self.output.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
        font = QFont("monospace")
        font.setStyleHint(QFont.StyleHint.Monospace)
        self.output.setFont(font)
        layout.addWidget(self.output, 1)

        buttons = QHBoxLayout()
        copy_button = QPushButton("Copy output")
        save_button = QPushButton("Save output as…")
        clear_button = QPushButton("Clear")
        copy_button.clicked.connect(lambda: QApplication.clipboard().setText(self.output.toPlainText()))
        save_button.clicked.connect(self.save_output_as)
        clear_button.clicked.connect(self.output.clear)
        buttons.addWidget(copy_button)
        buttons.addWidget(save_button)
        buttons.addWidget(clear_button)
        buttons.addStretch(1)
        log_label = QLabel(str(state_log_path()))
        log_label.setObjectName("muted")
        buttons.addWidget(log_label)
        layout.addLayout(buttons)
        return page

    def build_about_page(self) -> QWidget:
        page, layout = page_shell(
            "About UPPY",
            "A combined Linux updater, maintenance and system setup utility.",
        )
        about_card, about_layout = card("")
        row = QHBoxLayout()
        icon = QLabel()
        icon.setPixmap(QPixmap(str(resource_path())).scaled(112, 112, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        row.addWidget(icon)
        text = QLabel(
            f"<h1>UPPY {APP_VERSION}</h1>"
            "<p>Graphical AppImage front end with the original Bash backend.</p>"
            "<p>Copyright © 2026 Peter Haworth<br>UPPY is released under the MIT License.<br>"
            "Bundled components retain their own licenses.</p>"
        )
        text.setTextFormat(Qt.TextFormat.RichText)
        row.addWidget(text, 1)
        about_layout.addLayout(row)
        layout.addWidget(about_card)

        safety_card, safety_layout = card("Safety boundaries")
        safety = QLabel(
            "• Preview mode runs without administrator access.\n"
            "• Package removals are displayed before execution.\n"
            "• Flatpaks are installed system-wide.\n"
            "• Package and application names are validated before use.\n"
            "• Values are passed as separate process arguments, never as shell code.\n"
            "• Administrator access is requested only for system changes."
        )
        safety.setWordWrap(True)
        safety_layout.addWidget(safety)
        layout.addWidget(safety_card)

        support_card, support_layout = card(
            "Supported Linux families",
            "Arch Linux and CachyOS; Fedora and Nobara; Debian, Ubuntu and compatible Debian-based systems.",
        )
        paths = QLabel(
            f"Settings: {html.escape(str(config_path()))}<br>"
            f"GUI log: {html.escape(str(state_log_path()))}"
        )
        paths.setTextFormat(Qt.TextFormat.RichText)
        paths.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        support_layout.addWidget(paths)
        open_config = QPushButton("Open settings folder")
        open_config.clicked.connect(self.open_config_folder)
        support_layout.addWidget(open_config, alignment=Qt.AlignmentFlag.AlignLeft)
        layout.addWidget(support_card)
        layout.addStretch(1)
        return page

    def register_actions(self, *buttons: QPushButton) -> None:
        self.action_buttons.extend(buttons)

    def set_busy(self, busy: bool) -> None:
        for button in self.action_buttons:
            button.setEnabled(not busy)
        self.cancel_button.setEnabled(busy)
        self.sidebar_status.setText("RUNNING" if busy else "READY")
        self.sidebar_status.setObjectName("statusRunning" if busy else "statusReady")
        self.sidebar_status.style().unpolish(self.sidebar_status)
        self.sidebar_status.style().polish(self.sidebar_status)

    def populate_config_widgets(self) -> None:
        apps = self.config["apps"]
        self.system_editor.setPlainText("\n".join(apps["system"]))
        self.flatpak_editor.setPlainText("\n".join(apps["flatpak"]))
        self.snap_editor.setPlainText("\n".join(apps["snap"]))
        self.remove_editor.setPlainText("\n".join(apps["remove"]))

    def collect_config(self) -> dict:
        raw = default_config()
        raw["apps"] = {
            "system": text_to_entries(self.system_editor.toPlainText()),
            "flatpak": text_to_entries(self.flatpak_editor.toPlainText()),
            "snap": text_to_entries(self.snap_editor.toPlainText()),
            "remove": text_to_entries(self.remove_editor.toPlainText()),
        }
        return normalize_config(raw)

    def app_entry_count(self) -> int:
        return sum(
            len(text_to_entries(editor.toPlainText()))
            for editor in (
                self.system_editor,
                self.flatpak_editor,
                self.snap_editor,
                self.remove_editor,
            )
        )

    def update_app_list_status(self, *, saved: bool) -> None:
        self.app_lists_dirty = not saved
        count = self.app_entry_count()
        noun = "entry" if count == 1 else "entries"
        self.app_list_status.setText(
            f"{count} custom {noun} • {'Saved' if saved else 'Unsaved changes'}"
        )
        self.app_list_status.setProperty("dirty", not saved)
        self.app_list_status.style().unpolish(self.app_list_status)
        self.app_list_status.style().polish(self.app_list_status)
        self.saved_app_count.setText(str(count if saved else sum(len(items) for items in self.config["apps"].values())))

    def mark_app_lists_dirty(self) -> None:
        if not self.loading_widgets:
            self.update_app_list_status(saved=False)

    def discard_app_edits(self) -> None:
        self.loading_widgets = True
        self.populate_config_widgets()
        self.loading_widgets = False
        self.update_app_list_status(saved=True)
        self.statusBar().showMessage("Unsaved app-list changes discarded.", 4000)

    def save_current_config(self) -> bool:
        try:
            self.config = self.collect_config()
            path = save_config(self.config)
        except ConfigError as exc:
            self.show_error("Invalid settings", str(exc))
            return False
        except OSError as exc:
            self.show_error("Could not save settings", str(exc))
            return False
        self.loading_widgets = True
        self.populate_config_widgets()
        self.loading_widgets = False
        self.update_app_list_status(saved=True)
        self.statusBar().showMessage(f"Settings saved to {path}", 5000)
        return True

    def run_update(self, *, preview: bool) -> None:
        args = update_arguments(
            maintenance=self.update_maintenance.isChecked(),
            reboot=self.update_reboot.isChecked(),
        )
        args = execution_arguments(args, preview=preview)
        danger = "The computer will reboot automatically after a successful update." if self.update_reboot.isChecked() else ""
        self.run_command("Routine update", args, preview=preview, danger=danger)

    def run_cleanup(self) -> None:
        args = execution_arguments(["--clean"], preview=False)
        self.run_command(
            "System cleanup",
            args,
            preview=False,
            danger="This removes orphan packages, unused Flatpak runtimes and downloaded package caches.",
        )

    def run_setup(self, *, preview: bool) -> None:
        if not self.save_current_config():
            return
        selected = {name: checkbox.isChecked() for name, checkbox in self.setup_checks.items()}
        try:
            args = setup_arguments(self.config, selected)
        except ConfigError as exc:
            self.show_error("Setup selection", str(exc))
            return
        args = execution_arguments(args, preview=preview)
        danger = ""
        if selected.get("remove_software"):
            danger = "The installed packages shown in UPPY's removal list will be uninstalled."
        self.run_command("Selected system setup", args, preview=preview, danger=danger)

    def run_apps(self, install: bool, remove: bool, preview: bool) -> None:
        if not self.save_current_config():
            return
        args = app_arguments(self.config, install=install, remove=remove)
        args = execution_arguments(args, preview=preview)
        label = "App installation" if install else "Bloat removal"
        danger = ""
        if remove:
            removals = self.config["apps"]["remove"]
            listed = ", ".join(removals) if removals else "the configured distro removal list"
            danger = f"Installed removal targets will be uninstalled: {listed}."
        self.run_command(label, args, preview=preview, danger=danger)

    def run_simple(self, label: str, args: list[str], privileged: bool) -> None:
        self.run_command(label, args, preview=not privileged, privileged_override=privileged)

    def run_command(
        self,
        label: str,
        args: list[str],
        *,
        preview: bool,
        danger: str = "",
        privileged_override: bool | None = None,
    ) -> None:
        if self.process.state() != QProcess.ProcessState.NotRunning:
            self.show_error("UPPY is busy", "Wait for the current task to finish or cancel it first.")
            return

        privileged = (not preview) if privileged_override is None else privileged_override
        visible_program = "uppy"
        command = display_command(visible_program, args)
        if privileged:
            dialog = ConfirmationDialog(
                label,
                "UPPY will request administrator authentication and then run the selected operation.",
                command,
                danger,
                self,
            )
            if dialog.exec() != QDialog.DialogCode.Accepted:
                return

        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.append_output(f"\n{'=' * 78}\n{timestamp} — {label}\n$ {command}\n{'=' * 78}\n\n")
        self.stack.setCurrentIndex(3)
        self.nav_buttons[3].setChecked(True)
        self.current_label = label
        self.run_status.setText(f"Running: {label}")
        self.set_busy(True)
        try:
            self.process.launch(args, privileged=privileged)
        except RuntimeError as exc:
            self.set_busy(False)
            self.run_status.setText("Ready")
            self.show_error("Could not start UPPY", str(exc))

    def append_output(self, text: str) -> None:
        self.output.moveCursor(QTextCursor.MoveOperation.End)
        self.output.insertPlainText(text)
        self.output.moveCursor(QTextCursor.MoveOperation.End)
        try:
            log_path = state_log_path()
            log_path.parent.mkdir(parents=True, exist_ok=True)
            if log_path.exists() and log_path.stat().st_size > 2_000_000:
                previous = log_path.with_suffix(".log.old")
                if previous.exists():
                    previous.unlink()
                log_path.replace(previous)
            with log_path.open("a", encoding="utf-8") as handle:
                handle.write(text)
        except OSError:
            pass

    def process_finished(self, exit_code: int, _status: QProcess.ExitStatus) -> None:
        self.set_busy(False)
        if exit_code == 0:
            self.run_status.setText(f"Completed: {self.current_label}")
            self.sidebar_status.setText("DONE")
            self.sidebar_status.setObjectName("statusDone")
        else:
            self.run_status.setText(f"Failed with exit code {exit_code}: {self.current_label}")
            self.sidebar_status.setText("FAILED")
            self.sidebar_status.setObjectName("statusFailed")
        self.sidebar_status.style().unpolish(self.sidebar_status)
        self.sidebar_status.style().polish(self.sidebar_status)
        self.append_output(f"\n[GUI] Process finished with exit code {exit_code}.\n")

    def process_launch_failed(self, message: str) -> None:
        self.set_busy(False)
        self.run_status.setText("Could not start UPPY")
        self.show_error("Could not start UPPY", message)

    def cancel_process(self) -> None:
        if self.process.state() == QProcess.ProcessState.NotRunning:
            return
        answer = QMessageBox.question(
            self,
            "Cancel running task?",
            "Stopping a package manager mid-operation can leave it unfinished. Cancel only if the task is genuinely stuck.",
            QMessageBox.StandardButton.Cancel | QMessageBox.StandardButton.Yes,
            QMessageBox.StandardButton.Cancel,
        )
        if answer == QMessageBox.StandardButton.Yes:
            self.process.terminate()
            QTimer.singleShot(5000, self._kill_if_running)

    def _kill_if_running(self) -> None:
        if self.process.state() != QProcess.ProcessState.NotRunning:
            self.process.kill()

    def save_output_as(self) -> None:
        filename, _ = QFileDialog.getSaveFileName(
            self,
            "Save UPPY output",
            str(Path.home() / "uppy-output.txt"),
            "Text files (*.txt);;All files (*)",
        )
        if not filename:
            return
        try:
            Path(filename).write_text(self.output.toPlainText(), encoding="utf-8")
        except OSError as exc:
            self.show_error("Could not save output", str(exc))

    def open_config_folder(self) -> None:
        folder = config_path().parent
        folder.mkdir(parents=True, exist_ok=True)
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(folder)))

    def show_error(self, title: str, message: str) -> None:
        QMessageBox.critical(self, title, message)

    def closeEvent(self, event: QCloseEvent) -> None:
        if not self.app_lists_dirty:
            event.accept()
            return
        answer = QMessageBox.question(
            self,
            "Discard unsaved app-list changes?",
            "The Apps page contains changes that have not been saved.",
            QMessageBox.StandardButton.Cancel | QMessageBox.StandardButton.Discard,
            QMessageBox.StandardButton.Cancel,
        )
        if answer == QMessageBox.StandardButton.Discard:
            event.accept()
        else:
            event.ignore()


STYLESHEET = """
QWidget {
    color: #e7edf7;
    background: #0d1420;
    font-family: "Inter", "Noto Sans", "DejaVu Sans", sans-serif;
    font-size: 10.5pt;
}
QFrame#sidebar { background: #101b2b; border-right: 1px solid #27354a; }
QLabel#brand { font-size: 21pt; font-weight: 800; color: #ffffff; }
QLabel#sidebarMuted { color: #8fa1b9; font-size: 8.5pt; }
QPushButton#navButton {
    text-align: left; padding: 11px 14px; border: 0; border-radius: 8px;
    color: #aebcd0; background: transparent; font-weight: 600;
}
QPushButton#navButton:hover { background: #17253a; color: #ffffff; }
QPushButton#navButton:checked { background: #1e66f5; color: #ffffff; }
QLabel#statusReady, QLabel#statusRunning, QLabel#statusDone, QLabel#statusFailed {
    border-radius: 7px; padding: 7px; font-size: 8pt; font-weight: 800;
}
QLabel#statusReady { background: #1a293a; color: #9fb0c6; }
QLabel#statusRunning { background: #3b2f12; color: #ffd166; }
QLabel#statusDone { background: #123527; color: #62d99b; }
QLabel#statusFailed { background: #441d26; color: #ff8798; }
QLabel#pageTitle { font-size: 24pt; font-weight: 800; color: #ffffff; }
QLabel#pageSubtitle { color: #9eafc5; font-size: 11pt; }
QFrame#card { background: #151f2e; border: 1px solid #27354a; border-radius: 12px; }
QFrame#card[dangerCard="true"] { border-color: #60323e; }
QLabel#cardTitle, QLabel#dialogTitle { font-size: 14pt; font-weight: 750; color: #f5f8fc; }
QLabel#muted { color: #98a9bf; }
QLabel#value { font-weight: 650; color: #f5f8fc; }
QFrame#choiceBox { background: #111a27; border: 1px solid #26364b; border-radius: 9px; }
QCheckBox#choiceTitle { font-size: 11pt; font-weight: 700; }
QFrame#banner { border-radius: 9px; background: #152b43; border: 1px solid #24527b; }
QFrame#banner[kind="warning"] { background: #352b16; border-color: #725c20; color: #ffe29a; }
QPushButton {
    background: #202d40; border: 1px solid #34465f; border-radius: 7px;
    padding: 8px 13px; color: #eaf0f8; font-weight: 600;
}
QPushButton:hover { background: #2a3a51; border-color: #4b6689; }
QPushButton:pressed { background: #192538; }
QPushButton:disabled { color: #66758a; background: #17202d; border-color: #263244; }
QPushButton[role="primary"] { background: #1e66f5; border-color: #4080ff; color: white; }
QPushButton[role="primary"]:hover { background: #3477fb; }
QPushButton[role="danger"] { background: #772c3d; border-color: #a14358; color: white; }
QPushButton[role="danger"]:hover { background: #91364b; }
QPlainTextEdit {
    background: #0d1623; border: 1px solid #304158; border-radius: 7px;
    padding: 7px; selection-background-color: #1e66f5;
}
QPlainTextEdit:focus { border-color: #4c85ff; }
QPlainTextEdit#output, QPlainTextEdit#commandPreview { background: #080d14; color: #c9d7e8; }
QLabel#editorStatus { color: #70d6a3; font-weight: 650; padding: 2px 0; }
QLabel#editorStatus[dirty="true"] { color: #ffd166; }
QCheckBox { spacing: 9px; }
QCheckBox::indicator { width: 18px; height: 18px; }
QStatusBar { background: #101927; color: #a4b4c9; }
QScrollBar:vertical { background: #0e1723; width: 12px; }
QScrollBar::handle:vertical { background: #34445a; border-radius: 5px; min-height: 28px; }
QToolTip { background: #f1f5fa; color: #111827; border: 1px solid #b7c2d0; }
"""


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("UPPY")
    app.setApplicationVersion(APP_VERSION)
    app.setOrganizationName("PMHS")
    app.setOrganizationDomain("pmhs.au")
    app.setDesktopFileName(APP_ID)
    app.setWindowIcon(QIcon(str(resource_path())))
    app.setStyle("Fusion")
    app.setStyleSheet(STYLESHEET)
    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())

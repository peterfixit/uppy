"""Configuration and command-building logic for the UPPY desktop app.

This module deliberately has no Qt dependency so its safety rules can be tested
without launching the graphical interface.
"""

from __future__ import annotations

import copy
import json
import os
import re
import shlex
import tempfile
from pathlib import Path
from typing import Any, Iterable


APP_VERSION = "4.1.0"
CONFIG_SCHEMA = 2
PACKAGE_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9@._+:-]*$")


class ConfigError(ValueError):
    """Raised when a user-editable value is unsafe or malformed."""


def default_config() -> dict[str, Any]:
    return {
        "schema_version": CONFIG_SCHEMA,
        "apps": {
            "system": [],
            "flatpak": [],
            "snap": [],
            "remove": [],
        },
    }


def config_path() -> Path:
    base = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
    return base / "uppy" / "config.json"


def state_log_path() -> Path:
    base = Path(os.environ.get("XDG_STATE_HOME", Path.home() / ".local/state"))
    return base / "uppy" / "gui.log"


def _merge_known(default: Any, supplied: Any) -> Any:
    """Merge only keys present in the default structure."""
    if isinstance(default, dict):
        if not isinstance(supplied, dict):
            return copy.deepcopy(default)
        return {
            key: _merge_known(value, supplied.get(key, value))
            for key, value in default.items()
        }
    return copy.deepcopy(supplied)


def _clean_text(value: Any, label: str, *, required: bool = True) -> str:
    if not isinstance(value, str):
        raise ConfigError(f"{label} must be text.")
    cleaned = value.strip()
    if required and not cleaned:
        raise ConfigError(f"{label} cannot be empty.")
    if "\n" in cleaned or "\r" in cleaned or "|" in cleaned:
        raise ConfigError(f"{label} cannot contain a line break or | character.")
    return cleaned


def normalize_package_list(values: Iterable[Any], label: str) -> list[str]:
    if isinstance(values, (str, bytes)) or not isinstance(values, Iterable):
        raise ConfigError(f"{label} must be a list.")

    output: list[str] = []
    seen: set[str] = set()
    for value in values:
        item = _clean_text(value, label)
        if not PACKAGE_PATTERN.fullmatch(item):
            raise ConfigError(
                f"Invalid entry in {label}: {item!r}. Use one exact package name or app ID per line."
            )
        if item not in seen:
            seen.add(item)
            output.append(item)
    return output


def normalize_config(raw: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(raw, dict):
        raise ConfigError("The configuration must be a JSON object.")

    cfg = _merge_known(default_config(), raw)
    apps = cfg["apps"]
    for key, label in (
        ("system", "system packages"),
        ("flatpak", "Flatpak IDs"),
        ("snap", "Snap names"),
        ("remove", "packages to remove"),
    ):
        apps[key] = normalize_package_list(apps[key], label)

    cfg["schema_version"] = CONFIG_SCHEMA
    return cfg


def load_config(path: Path | None = None) -> dict[str, Any]:
    target = path or config_path()
    if not target.exists():
        return default_config()
    try:
        raw = json.loads(target.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ConfigError(f"Could not read {target}: {exc}") from exc
    return normalize_config(raw)


def save_config(config: dict[str, Any], path: Path | None = None) -> Path:
    target = path or config_path()
    normalized = normalize_config(config)
    target.parent.mkdir(parents=True, exist_ok=True)

    fd, temporary_name = tempfile.mkstemp(prefix=".config-", dir=target.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(normalized, handle, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temporary_name, 0o600)
        os.replace(temporary_name, target)
    finally:
        if os.path.exists(temporary_name):
            os.unlink(temporary_name)
    return target


def text_to_entries(text: str) -> list[str]:
    return [line.strip() for line in text.splitlines() if line.strip()]


def app_arguments(config: dict[str, Any], *, install: bool, remove: bool) -> list[str]:
    cfg = normalize_config(config)
    args: list[str] = []
    if install:
        apps = cfg["apps"]
        for value in apps["system"]:
            args.extend(("--add-system", value))
        for value in apps["flatpak"]:
            args.extend(("--add-flatpak", value))
        for value in apps["snap"]:
            args.extend(("--add-snap", value))
        if not any((apps["system"], apps["flatpak"], apps["snap"])):
            args.append("--additional-apps")
    if remove:
        removals = cfg["apps"]["remove"]
        for value in removals:
            args.extend(("--add-bloat", value))
        if not removals:
            args.append("--remove-software")
    return args


def setup_arguments(config: dict[str, Any], selected: dict[str, bool]) -> list[str]:
    names = {
        "core",
        "workstation",
        "gaming",
        "additional_apps",
        "remove_software",
    }
    unknown = set(selected) - names
    if unknown:
        raise ConfigError(f"Unknown setup selection: {', '.join(sorted(unknown))}")
    if not any(selected.get(name, False) for name in names):
        raise ConfigError("Select at least one setup task.")

    args: list[str] = []
    for name, flag in (
        ("core", "--core"),
        ("workstation", "--workstation"),
        ("gaming", "--gaming"),
    ):
        if selected.get(name, False):
            args.append(flag)

    args.extend(
        app_arguments(
            config,
            install=selected.get("additional_apps", False),
            remove=selected.get("remove_software", False),
        )
    )

    return args


def update_arguments(*, maintenance: bool, reboot: bool) -> list[str]:
    if reboot:
        return ["--reboot"]
    if maintenance:
        return ["--update"]
    return ["--no-maintenance"]


def execution_arguments(arguments: Iterable[str], *, preview: bool) -> list[str]:
    output = list(arguments)
    output.append("--yes")
    if preview:
        output.append("--dry-run")
    return output


def display_command(program: str, arguments: Iterable[str]) -> str:
    return shlex.join([program, *arguments])

#!/usr/bin/env bash
# MIT License
#
# Copyright (c) 2026 Peter Haworth
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# UPPY 4.1.0
# Combined Linux updater, maintenance and system setup utility.
# This single-file build is the backend intended for the UPPY AppImage.

set -Eeuo pipefail

UPPY_VERSION="4.1.0"

# ##############################################################################
# #                                                                            #
# #                     USER-EDITABLE CONFIGURATION                            #
# #                                                                            #
# ##############################################################################
#
# Everything between this heading and "END OF USER-EDITABLE CONFIGURATION" may
# be changed by the user, subject to the rules written above each section.
#
# DO NOT rename variables, remove array parentheses, or alter functions below
# the end marker.

# ==============================================================================
# ROUTINE UPDATE SETTINGS — SAFE TO EDIT
# ==============================================================================

# Flatpaks are deliberately managed as system-wide installations. Leave this as
# "system" to avoid Flatpak asking whether to use a user or system installation.
FLATPAK_SCOPE="system"

# Seconds to wait for the optional-maintenance question. Zero waits forever.
MAINTENANCE_PROMPT_TIMEOUT=5

# Number of old Arch package versions retained when paccache is available.
ARCH_CACHE_VERSIONS_TO_KEEP=2

# Optional URL used by: uppy --self-update
# Example: UPPY_UPDATE_URL="https://example.com/uppy.sh"
UPPY_UPDATE_URL="${UPPY_UPDATE_URL:-}"

# ==============================================================================
# SOFTWARE LISTS — SAFE TO EDIT
# ==============================================================================
#
# This is the only section used for deliberate software installation/removal.
#
# YOU CAN:
#   - Delete a complete line to stop managing that package/application.
#   - Add a package name or Flatpak ID on its own line.
#
# DO NOT:
#   - Rename an array or remove its opening/closing parentheses.
#   - Change a package name or Flatpak ID unless you have verified the new ID.

# ------------------------------------------------------------------------------
# SOFTWARE TO INSTALL: core native packages
# ------------------------------------------------------------------------------
# Only the list matching the detected Linux family is used.

ARCH_CORE_PACKAGES=(
    flatpak
    kate
    exfatprogs
)

FEDORA_CORE_PACKAGES=(
    flatpak
)

DEBIAN_CORE_PACKAGES=(
    flatpak
)

# ------------------------------------------------------------------------------
# SOFTWARE TO INSTALL: CachyOS gaming packages
# ------------------------------------------------------------------------------
# This native package is installed only when CachyOS is detected and the gaming
# installation is selected.

CACHYOS_GAMING_PACKAGES=(
    cachyos-gaming-meta
)

# ------------------------------------------------------------------------------
# SOFTWARE TO INSTALL: workstation Flatpaks
# ------------------------------------------------------------------------------
# Flatpaks are installed system-wide so Flatpak does not ask user vs system.

WORKSTATION_FLATPAKS=(
    com.discordapp.Discord
    com.spotify.Client
    org.qbittorrent.qBittorrent
    org.libreoffice.LibreOffice
    com.bitwarden.desktop
    com.brave.Browser
    org.mozilla.firefox
    org.videolan.VLC
    org.kde.skanpage
    org.kde.gwenview
)

# ------------------------------------------------------------------------------
# SOFTWARE TO INSTALL: gaming Flatpaks
# ------------------------------------------------------------------------------

GAMING_FLATPAKS=(
    com.usebottles.bottles
    com.heroicgameslauncher.hgl
    net.davidotek.pupgui2
    org.prismlauncher.PrismLauncher
)

# ------------------------------------------------------------------------------
# ADDITIONAL SOFTWARE — SAFE TO EDIT
# ------------------------------------------------------------------------------
# Add one name/ID per line. Leave an array empty when it is not needed.

ADDITIONAL_SYSTEM_PACKAGES=(
    # package-name
)

ADDITIONAL_FLATPAKS=(
    # org.example.Application
)

ADDITIONAL_SNAPS=(
    # snap-name
)

# ------------------------------------------------------------------------------
# SOFTWARE TO REMOVE: CachyOS only
# ------------------------------------------------------------------------------

CACHYOS_PACKAGES_TO_REMOVE=(
    alacritty
    meld
    jfsutils
    nilfs-utils
    usb_modeswitch
    xl2tpd
    kdegraphics-thumbnailers
    kdeplasma-addons
    plasma-browser-integration
    fwupd
)

# ------------------------------------------------------------------------------
# SOFTWARE TO REMOVE: Nobara only
# ------------------------------------------------------------------------------

NOBARA_PACKAGES_TO_REMOVE=(
    NetworkManager-l2tp
    NetworkManager-libreswan
    NetworkManager-libreswan-gnome
    NetworkManager-openconnect
    NetworkManager-openvpn
    NetworkManager-pptp
    NetworkManager-strongswan
    NetworkManager-strongswan-gnome
    NetworkManager-vpnc
    mariadb-server
    mariadb-backup
    mariadb-embedded
    httpd-core
    mod_fcgid
    mod_perl
    braille-printer-app
    orca
    espeak-ng
    brlapi
    jfsutils
    nilfs-utils
    hfsplus-tools
    hfsutils
    gfs2-utils
    ocfs2-tools
    gcc-gfortran
    gettext-devel
    glibc-devel
    libomp-devel
    openssl-devel
    a2ps
    antiword
    enscript
    html2ps
    paps
    flatpost
    fpaste
    kdebugsettings
    kcharselect
    kde-inotify-survey
    kwalletmanager5
)

# Additional bloat packages for any supported distribution.
ADDITIONAL_BLOAT_PACKAGES=(
    # package-name
)

# ==============================================================================
# END OF USER-EDITABLE CONFIGURATION
# ==============================================================================
#
# DO NOT CHANGE anything below this line unless you are developing the script.
# Functions, option names, validation and safety checks depend on each other.

DRY_RUN=false
VERBOSE=false
QUIET_MODE=false
ASSUME_YES=false
LOG_FILE=""

AUTO_SKIP_OPTIONAL=false
AUTO_REBOOT=false
RUN_ONLY=""
MODE_UPDATE_REQUESTED=false

MODE_SETUP=false
MODE_ALL=false
MODE_CORE=false
MODE_REMOVE=false
MODE_WORKSTATION=false
MODE_GAMING=false
MODE_ADDITIONAL_APPS=false
MODE_LIST=false
MODE_SELECTED=false

run_cmd() {
    local cmd=("$@")

    if $VERBOSE; then
        printf '[cmd]'
        printf ' %q' "${cmd[@]}"
        printf '\n'
    fi

    if [[ -n "$LOG_FILE" ]]; then
        {
            printf '[%s] CMD:' "$(date '+%Y-%m-%d %H:%M:%S')"
            printf ' %q' "${cmd[@]}"
            printf '\n'
        } >> "$LOG_FILE" 2>/dev/null || true
    fi

    if $DRY_RUN; then
        printf '[dry-run]'
        printf ' %q' "${cmd[@]}"
        printf '\n'
        return 0
    fi

    "${cmd[@]}"
}

if [[ $EUID -eq 0 ]]; then
    run_sudo() { run_cmd "$@"; }
else
    run_sudo() { run_cmd sudo "$@"; }
fi

color_enabled() {
    [[ -t 1 && -z "${NO_COLOR:-}" ]]
}

cecho() {
    local code="$1"
    shift
    if color_enabled; then
        printf '\033[%sm%s\033[0m\n' "$code" "$*"
    else
        printf '%s\n' "$*"
    fi
}

info() { $QUIET_MODE || cecho "36" "[INFO] $*"; }
success() { cecho "32" "[OK] $*"; }
warn() { cecho "33" "[WARN] $*"; }
error() { cecho "31" "[ERROR] $*" >&2; }

log_msg() {
    local level="$1"
    shift || true
    [[ -n "$LOG_FILE" ]] || return 0
    printf '[%s] [%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" \
        "$level" "$*" >> "$LOG_FILE" 2>/dev/null || true
}

setup_logging() {
    if [[ $EUID -eq 0 ]]; then
        LOG_FILE="/var/log/uppy.log"
    else
        LOG_FILE="$HOME/uppy.log"
    fi

    touch "$LOG_FILE" 2>/dev/null || LOG_FILE=""
    log_msg "INFO" "UPPY v${UPPY_VERSION} started as ${USER:-unknown}"
    [[ -n "$LOG_FILE" ]] && $VERBOSE && info "Logging to $LOG_FILE"
    return 0
}

on_error() {
    local exit_code=$?
    local line_no=${1:-unknown}
    error "UPPY failed at line $line_no with exit code $exit_code"
    log_msg "ERROR" "Failed at line $line_no with exit code $exit_code"
    exit "$exit_code"
}
trap 'on_error $LINENO' ERR

show_help() {
    cat <<EOF
UPPY v${UPPY_VERSION}

Combined updater and system setup utility for Arch, CachyOS, Nobara, Fedora
and Debian-based systems. Running without a mode performs a routine update.

Usage:
  uppy [OPTIONS] [MODE]

ROUTINE UPDATE:
      --update            Update installed native packages and Flatpaks.
  -n, --no-maintenance    Update without optional cleanup questions.
  -r, --reboot            Update without maintenance, then reboot.
      --clean             Remove unused packages and clean caches/runtimes.
      --check             Print a read-only system report.
      --backup            Export package and configuration lists.
      --self-update       Update /usr/local/bin/uppy from UPPY_UPDATE_URL.

INTERACTIVE SETUP:
      --setup             Run all setup sections interactively.
      --setup-all         Run every applicable setup section.
      --all               Alias for --setup-all.

SOFTWARE INSTALLATION:
      --core              Install the configured native core packages.
      --workstation       Install the configured workstation Flatpaks.
      --gaming            Install configured gaming software.
      --additional-apps   Install the additional editable app lists.
      --add-system NAME   Install an extra system package; repeatable.
      --add-flatpak ID    Install an extra system-wide Flatpak; repeatable.
      --add-snap NAME     Install an extra Snap; repeatable.

SOFTWARE REMOVAL:
      --remove-software   Remove the configured CachyOS/Nobara packages.
      --add-bloat NAME    Add an extra package to the removal run; repeatable.

INFORMATION:
      --list-software     Read-only list of software configured for this OS.

GENERAL OPTIONS:
  -y, --yes               Answer yes to confirmation prompts.
  -q, --quiet             Reduce UPPY's own status output.
      --verbose           Print commands before running them.
      --dry-run           Show changing commands without running them.
      --version           Print the UPPY version.
  -h, --help              Show this help message.

Modes may be combined:
  uppy --core --workstation --gaming
  uppy --list-software
  uppy --setup-all --dry-run
EOF
}

require_option_value() {
    local option="$1"
    local value="${2:-}"

    if [[ -z "$value" || "$value" == -* ]]; then
        error "$option requires a value."
        exit 1
    fi
}

validate_software_name() {
    local option="$1"
    local value="$2"

    if [[ ! "$value" =~ ^[A-Za-z0-9][A-Za-z0-9@._+:-]*$ ]]; then
        error "Invalid value for $option: $value"
        error "Use one exact package name or application ID without spaces."
        return 1
    fi
}

validate_software_array() {
    local array_name="$1"
    local -n values="$array_name"
    local value
    for value in "${values[@]}"; do
        validate_software_name "$array_name" "$value"
    done
}

validate_software_configuration() {
    local array_name
    for array_name in \
        ARCH_CORE_PACKAGES FEDORA_CORE_PACKAGES DEBIAN_CORE_PACKAGES \
        CACHYOS_GAMING_PACKAGES WORKSTATION_FLATPAKS GAMING_FLATPAKS \
        ADDITIONAL_SYSTEM_PACKAGES ADDITIONAL_FLATPAKS ADDITIONAL_SNAPS \
        CACHYOS_PACKAGES_TO_REMOVE NOBARA_PACKAGES_TO_REMOVE \
        ADDITIONAL_BLOAT_PACKAGES; do
        validate_software_array "$array_name"
    done
}

parse_args() {
    while [[ $# -gt 0 ]]; do
        case "$1" in
            -h|--help)
                show_help
                exit 0
                ;;
            --version)
                printf '%s\n' "$UPPY_VERSION"
                exit 0
                ;;
            -y|--yes)
                ASSUME_YES=true
                ;;
            -q|--quiet)
                QUIET_MODE=true
                ;;
            --verbose)
                VERBOSE=true
                ;;
            --dry-run)
                DRY_RUN=true
                ;;
            --update)
                MODE_UPDATE_REQUESTED=true
                ;;
            -n|--no-maintenance)
                MODE_UPDATE_REQUESTED=true
                AUTO_SKIP_OPTIONAL=true
                ;;
            -r|--reboot)
                MODE_UPDATE_REQUESTED=true
                AUTO_SKIP_OPTIONAL=true
                AUTO_REBOOT=true
                ;;
            --clean|--check|--backup|--self-update)
                if [[ -n "$RUN_ONLY" ]]; then
                    error "Only one routine maintenance mode can be used at a time."
                    exit 1
                fi
                RUN_ONLY="${1#--}"
                ;;
            --setup)
                MODE_SETUP=true
                ;;
            --all|--setup-all)
                MODE_ALL=true
                MODE_SELECTED=true
                ;;
            --core)
                MODE_CORE=true
                MODE_SELECTED=true
                ;;
            --remove-software|--debloat)
                MODE_REMOVE=true
                MODE_SELECTED=true
                ;;
            --workstation)
                MODE_WORKSTATION=true
                MODE_SELECTED=true
                ;;
            --gaming)
                MODE_GAMING=true
                MODE_SELECTED=true
                ;;
            --additional-apps)
                MODE_ADDITIONAL_APPS=true
                MODE_SELECTED=true
                ;;
            --add-system)
                require_option_value "$1" "${2:-}"
                validate_software_name "$1" "$2"
                ADDITIONAL_SYSTEM_PACKAGES+=("$2")
                MODE_ADDITIONAL_APPS=true
                MODE_SELECTED=true
                shift
                ;;
            --add-flatpak)
                require_option_value "$1" "${2:-}"
                validate_software_name "$1" "$2"
                ADDITIONAL_FLATPAKS+=("$2")
                MODE_ADDITIONAL_APPS=true
                MODE_SELECTED=true
                shift
                ;;
            --add-snap)
                require_option_value "$1" "${2:-}"
                validate_software_name "$1" "$2"
                ADDITIONAL_SNAPS+=("$2")
                MODE_ADDITIONAL_APPS=true
                MODE_SELECTED=true
                shift
                ;;
            --add-bloat)
                require_option_value "$1" "${2:-}"
                validate_software_name "$1" "$2"
                ADDITIONAL_BLOAT_PACKAGES+=("$2")
                MODE_REMOVE=true
                MODE_SELECTED=true
                shift
                ;;
            --list-software)
                MODE_LIST=true
                MODE_SELECTED=true
                ;;
            *)
                error "Unknown option: $1"
                show_help
                exit 1
                ;;
        esac
        shift
    done

    validate_mode_selection
}

validate_mode_selection() {
    local routine_requested=false
    local setup_requested=false

    if $MODE_UPDATE_REQUESTED || [[ -n "$RUN_ONLY" ]]; then
        routine_requested=true
    fi

    if $MODE_SETUP || $MODE_SELECTED; then
        setup_requested=true
    fi

    if $routine_requested && $setup_requested; then
        error "Routine update and setup modes cannot be combined in one run."
        exit 1
    fi

    if $MODE_SETUP && $MODE_SELECTED; then
        error "Use --setup by itself, or select individual setup modes."
        exit 1
    fi

    if $MODE_LIST && { $MODE_ALL || $MODE_CORE || $MODE_REMOVE || \
        $MODE_WORKSTATION || $MODE_GAMING || $MODE_ADDITIONAL_APPS; }; then
        error "--list-software cannot be combined with changing setup modes."
        exit 1
    fi
}

ask() {
    local prompt="$1"
    local timeout="${2:-0}"
    local reply=""

    if $ASSUME_YES; then
        printf '%s [y/N]: y\n' "$prompt"
        return 0
    fi

    if (( timeout > 0 )); then
        read -r -t "$timeout" -p "$prompt [y/N] (${timeout}s): " reply || true
        printf '\n'
    else
        read -r -p "$prompt [y/N]: " reply || true
    fi

    [[ "${reply:-N}" =~ ^[Yy]$ ]]
}

detect_distro() {
    if [[ ! -f /etc/os-release ]]; then
        error "Cannot detect OS: /etc/os-release was not found."
        exit 1
    fi

    # shellcheck disable=SC1091
    source /etc/os-release

    if [[ "${ID:-}" =~ ^(arch|cachyos|endeavouros|manjaro)$ ]] || \
       [[ "${ID_LIKE:-}" =~ arch ]]; then
        DISTRO="arch"
    elif [[ "${ID:-}" == "nobara" ]]; then
        DISTRO="nobara"
    elif [[ "${ID:-}" =~ ^(fedora|aurora|bazzite)$ ]] || \
         [[ "${ID_LIKE:-}" =~ fedora ]]; then
        DISTRO="fedora"
    elif [[ "${ID:-}" =~ ^(ubuntu|debian|linuxmint|pop)$ ]] || \
         [[ "${ID_LIKE:-}" =~ debian ]]; then
        DISTRO="debian"
    else
        error "Unsupported OS: ${ID:-unknown}"
        exit 1
    fi
}

install_self() {
    local script_path target

    if [[ -n "${APPIMAGE:-}" ]]; then
        info "Running from an AppImage; skipping /usr/local command installation."
        return 0
    fi

    script_path="$(readlink -f "$0")"
    target="/usr/local/bin/uppy"

    if [[ "$script_path" != "$target" ]]; then
        info "Installing/updating the uppy command at $target"
        run_sudo install -m 755 "$script_path" "$target"
    fi

    install_support_files
}

install_support_files() {
    local tmp_man tmp_completion
    tmp_man="$(mktemp)"
    tmp_completion="$(mktemp)"

    cat > "$tmp_man" <<EOF
.TH UPPY 1 "July 2026" "UPPY ${UPPY_VERSION}" "User Commands"
.SH NAME
uppy \- combined Linux updater, maintenance and system setup utility
.SH SYNOPSIS
.B uppy
[OPTIONS] [MODES]
.SH DESCRIPTION
UPPY updates installed native packages and system-wide Flatpaks. It can also
install configured native, Flatpak and Snap applications, remove configured
packages and clean unused package data.
.SH ROUTINE MODES
.TP
.B --update
Update installed native packages and Flatpaks.
.TP
.BR -n ", " --no-maintenance
Update without optional maintenance questions.
.TP
.BR -r ", " --reboot
Update without maintenance, then reboot.
.TP
.B --clean
Remove unused packages and clean caches and Flatpak runtimes.
.TP
.B --check
Print a read-only system report.
.TP
.B --backup
Export package and configuration lists.
.TP
.B --self-update
Update /usr/local/bin/uppy from UPPY_UPDATE_URL.
.SH SOFTWARE MODES
.TP
.B --setup
Run the setup sections interactively.
.TP
.B --setup-all
Run all applicable setup sections.
.TP
.B --core
Install configured native core packages.
.TP
.B --workstation
Install configured workstation Flatpaks system-wide.
.TP
.B --gaming
Install configured gaming software.
.TP
.B --additional-apps
Install the additional system package, Flatpak and Snap lists.
.TP
.B --add-system NAME
Install an extra native package. The option may be repeated.
.TP
.B --add-flatpak ID
Install an extra system-wide Flatpak. The option may be repeated.
.TP
.B --add-snap NAME
Install an extra Snap. The option may be repeated.
.TP
.B --remove-software
Remove configured CachyOS or Nobara packages.
.TP
.B --add-bloat NAME
Add an extra package to the removal run. The option may be repeated.
.SH OTHER MODES
.TP
.B --all
Alias for --setup-all.
.TP
.B --list-software
Print the exact configured software lists without changing anything.
.TP
.BR -y ", " --yes
Answer yes to confirmation prompts.
.TP
.B --dry-run
Show changing commands without running them.
.TP
.B --verbose
Print commands before running them.
.SH SEE ALSO
.BR uppy (1),
.BR flatpak (1)
.SH AUTHOR
Peter Haworth
EOF

    cat > "$tmp_completion" <<'EOF'
_uppy_completion() {
    local cur="${COMP_WORDS[COMP_CWORD]}"
    local opts="-h --help -n --no-maintenance -r --reboot -y --yes -q --quiet --verbose --dry-run --update --clean --check --backup --self-update --setup --setup-all --all --core --remove-software --debloat --workstation --gaming --additional-apps --add-system --add-flatpak --add-snap --add-bloat --list-software"
    COMPREPLY=( $(compgen -W "$opts" -- "$cur") )
}
complete -F _uppy_completion uppy
EOF

    if $DRY_RUN; then
        info "Would install the uppy man page and Bash completion."
        rm -f "$tmp_man" "$tmp_completion"
        return 0
    fi

    gzip -9 "$tmp_man"
    run_sudo install -D -m 644 "${tmp_man}.gz" \
        /usr/local/share/man/man1/uppy.1.gz
    run_sudo install -D -m 644 "$tmp_completion" \
        /etc/bash_completion.d/uppy
    rm -f "${tmp_man}.gz" "$tmp_completion"

    if command -v mandb >/dev/null 2>&1; then
        run_sudo mandb -q || true
    fi
}

# ==============================================================================
# ROUTINE UPDATE AND MAINTENANCE FUNCTIONS
# ==============================================================================

update_system() {
    printf '\n'
    info "Updating installed system packages"

    case "$DISTRO" in
        arch)
            run_sudo pacman -Syu --noconfirm
            ;;
        nobara)
            run_sudo nobara-updater cli
            ;;
        fedora)
            run_sudo dnf upgrade -y
            ;;
        debian)
            run_sudo env DEBIAN_FRONTEND=noninteractive apt update
            run_sudo env DEBIAN_FRONTEND=noninteractive apt full-upgrade -y
            ;;
    esac
}

flatpak_scope_args() {
    case "$FLATPAK_SCOPE" in
        system) printf '%s\n' "--system" ;;
        user) printf '%s\n' "--user" ;;
        *)
            error "FLATPAK_SCOPE must be either system or user."
            return 1
            ;;
    esac
}

update_flatpaks() {
    local scope_arg
    scope_arg="$(flatpak_scope_args)"

    printf '\n'
    info "Updating existing ${FLATPAK_SCOPE}-wide Flatpak applications"

    if ! command -v flatpak >/dev/null 2>&1; then
        warn "Flatpak is not installed; skipping Flatpak updates."
        return 0
    fi

    if [[ "$FLATPAK_SCOPE" == "system" ]]; then
        run_sudo flatpak "$scope_arg" update -y || true
    else
        run_cmd flatpak "$scope_arg" update -y || true
    fi
}

list_unused_packages() {
    case "$DISTRO" in
        arch)
            pacman -Qdtq 2>/dev/null || true
            ;;
        nobara|fedora)
            dnf repoquery --unneeded 2>/dev/null || true
            ;;
        debian)
            apt autoremove --dry-run 2>/dev/null | \
                sed -n '/The following packages will be REMOVED:/,/^$/p' || true
            ;;
    esac
}

remove_unused_packages() {
    printf '\n'
    info "Checking for packages no longer required by installed software"

    case "$DISTRO" in
        arch)
            local -a orphans=()
            mapfile -t orphans < <(pacman -Qdtq 2>/dev/null || true)
            if [[ ${#orphans[@]} -eq 0 ]]; then
                success "No orphan packages found."
                return 0
            fi
            printf 'Packages that will be removed:\n'
            printf '  - %s\n' "${orphans[@]}"
            ask "Remove these orphan packages?" && \
                run_sudo pacman -Rns --noconfirm "${orphans[@]}"
            ;;
        nobara|fedora)
            printf 'DNF reports these packages as unneeded:\n'
            dnf repoquery --unneeded 2>/dev/null | sed 's/^/  - /' || true
            ask "Run dnf autoremove?" && run_sudo dnf autoremove -y
            ;;
        debian)
            apt autoremove --dry-run 2>/dev/null | \
                sed -n '/The following packages will be REMOVED:/,/^$/p' || true
            ask "Run apt autoremove?" && run_sudo apt autoremove -y
            ;;
    esac
}

clean_package_cache() {
    printf '\n'
    info "Cleaning downloaded package caches"

    case "$DISTRO" in
        arch)
            if command -v paccache >/dev/null 2>&1; then
                run_sudo paccache -rk "$ARCH_CACHE_VERSIONS_TO_KEEP"
                run_sudo paccache -ruk0 || true
            else
                warn "paccache is unavailable; pacman will keep installed package versions."
                run_sudo pacman -Sc --noconfirm
            fi
            ;;
        nobara|fedora)
            run_sudo dnf clean all
            ;;
        debian)
            run_sudo apt autoclean -y
            run_sudo apt clean
            ;;
    esac
}

clean_flatpak_runtimes() {
    local scope_arg
    scope_arg="$(flatpak_scope_args)"

    printf '\n'
    info "Removing unused ${FLATPAK_SCOPE}-wide Flatpak runtimes"

    if ! command -v flatpak >/dev/null 2>&1; then
        warn "Flatpak is not installed; skipping runtime cleanup."
        return 0
    fi

    if [[ "$FLATPAK_SCOPE" == "system" ]]; then
        run_sudo flatpak "$scope_arg" uninstall --unused -y || true
    else
        run_cmd flatpak "$scope_arg" uninstall --unused -y || true
    fi
}

uppy_backup() {
    local backup_dir
    backup_dir="$HOME/uppy-backups/$(date +%Y%m%d-%H%M%S)"

    info "Creating package/configuration backup at $backup_dir"
    run_cmd mkdir -p "$backup_dir"

    if $DRY_RUN; then
        return 0
    fi

    if command -v rpm >/dev/null 2>&1; then
        rpm -qa --qf '%{NAME}\n' | sort > "$backup_dir/all-rpm-packages.txt"
        dnf repoquery --userinstalled --qf '%{name}' 2>/dev/null | sort \
            > "$backup_dir/userinstalled-rpm-packages.txt" || true
    fi

    if command -v pacman >/dev/null 2>&1; then
        pacman -Qqe | sort > "$backup_dir/userinstalled-pacman-packages.txt" || true
        pacman -Qq | sort > "$backup_dir/all-pacman-packages.txt" || true
    fi

    if command -v dpkg-query >/dev/null 2>&1; then
        dpkg-query -W -f='${Package}\n' | sort \
            > "$backup_dir/all-dpkg-packages.txt" || true
    fi

    if command -v flatpak >/dev/null 2>&1; then
        flatpak "$(flatpak_scope_args)" list --app --columns=application \
            > "$backup_dir/flatpak-apps.txt" 2>/dev/null || true
    fi

    cp /etc/os-release "$backup_dir/os-release" 2>/dev/null || true
    nmcli connection show > "$backup_dir/nmcli-connections.txt" 2>/dev/null || true
    lsblk -f > "$backup_dir/lsblk-f.txt" 2>/dev/null || true

    success "Backup complete: $backup_dir"
}

uppy_check() {
    printf '\nUPPY SYSTEM CHECK\n'
    printf '=================\n'
    printf 'UPPY version: %s\n' "$UPPY_VERSION"
    printf 'Distro family: %s\n\n' "$DISTRO"

    printf 'OS:\n'
    grep -E '^(PRETTY_NAME|ID|VERSION_ID)=' /etc/os-release || true
    printf '\nKernel:\n'
    uname -a || true
    printf '\nDisk usage:\n'
    df -h / /home 2>/dev/null || df -h || true
    printf '\nMemory:\n'
    free -h || true
    printf '\nFailed systemd services:\n'
    systemctl --failed --no-pager 2>/dev/null || true
    printf '\nConfigured NetworkManager connections:\n'
    nmcli -t -f NAME,TYPE connection show 2>/dev/null || true
    printf '\n%s-wide Flatpak applications:\n' "$FLATPAK_SCOPE"
    if command -v flatpak >/dev/null 2>&1; then
        flatpak "$(flatpak_scope_args)" list --app --columns=application \
            2>/dev/null || true
    else
        printf 'Flatpak is not installed.\n'
    fi
    printf '\nPotentially unused packages:\n'
    list_unused_packages
}

uppy_clean() {
    remove_unused_packages
    clean_package_cache
    clean_flatpak_runtimes
}

self_update() {
    local target="/usr/local/bin/uppy"
    local tmp

    if [[ -n "${APPIMAGE:-}" ]]; then
        error "Script self-update is unavailable while running from an AppImage."
        error "Use the AppImage update mechanism instead."
        return 1
    fi

    if [[ -z "$UPPY_UPDATE_URL" ]]; then
        error "UPPY_UPDATE_URL is not set in the USER-EDITABLE CONFIGURATION section."
        return 1
    fi

    tmp="$(mktemp)"
    trap 'rm -f "$tmp"' RETURN

    if command -v curl >/dev/null 2>&1; then
        run_cmd curl -fsSL "$UPPY_UPDATE_URL" -o "$tmp"
    elif command -v wget >/dev/null 2>&1; then
        run_cmd wget -qO "$tmp" "$UPPY_UPDATE_URL"
    else
        error "curl or wget is required for self-update."
        return 1
    fi

    if $DRY_RUN; then
        info "Would validate and install the downloaded script at $target"
        return 0
    fi

    bash -n "$tmp"
    run_sudo install -m 755 "$tmp" "$target"
    success "UPPY updated at $target"
}

run_routine_mode() {
    case "$RUN_ONLY" in
        clean) uppy_clean ;;
        check) uppy_check ;;
        backup) uppy_backup ;;
        self-update) self_update ;;
        *)
            error "Unknown maintenance mode: $RUN_ONLY"
            return 1
            ;;
    esac
}

run_routine_update() {
    update_system
    update_flatpaks

    if ! $AUTO_SKIP_OPTIONAL && \
       ask "Run optional package and cache maintenance?" "$MAINTENANCE_PROMPT_TIMEOUT"; then
        remove_unused_packages
        clean_package_cache
        clean_flatpak_runtimes
    fi

    if $AUTO_REBOOT; then
        if $DRY_RUN; then
            info "Would reboot after the update."
        else
            info "Rebooting in 5 seconds. Press Ctrl+C to cancel."
            sleep 5
        fi
        run_sudo reboot
    fi
}

# ==============================================================================
# SYSTEM SETUP FUNCTIONS
# ==============================================================================

print_software_list() {
    local heading="$1"
    shift
    local item

    printf '\n%s\n' "$heading"
    printf '%*s\n' "${#heading}" '' | tr ' ' '-'

    if [[ $# -eq 0 ]]; then
        printf '  (none configured)\n'
        return 0
    fi

    for item in "$@"; do
        printf '  - %s\n' "$item"
    done
}

core_array_name() {
    case "$DISTRO" in
        arch) printf '%s\n' "ARCH_CORE_PACKAGES" ;;
        nobara|fedora) printf '%s\n' "FEDORA_CORE_PACKAGES" ;;
        debian) printf '%s\n' "DEBIAN_CORE_PACKAGES" ;;
    esac
}

removal_array_name() {
    if [[ "${ID:-}" == "cachyos" ]]; then
        printf '%s\n' "CACHYOS_PACKAGES_TO_REMOVE"
    elif [[ "$DISTRO" == "nobara" ]]; then
        printf '%s\n' "NOBARA_PACKAGES_TO_REMOVE"
    else
        printf '%s\n' ""
    fi
}

list_software() {
    local core_name remove_name
    core_name="$(core_array_name)"
    remove_name="$(removal_array_name)"
    local -n core_entries="$core_name"

    printf '\nSOFTWARE CONFIGURED FOR %s\n' "${PRETTY_NAME:-$DISTRO}"
    printf '========================================\n'
    print_software_list "NATIVE SOFTWARE TO INSTALL" "${core_entries[@]}"

    if [[ "${ID:-}" == "cachyos" ]]; then
        print_software_list "CACHYOS GAMING SOFTWARE TO INSTALL" \
            "${CACHYOS_GAMING_PACKAGES[@]}"
    fi

    print_software_list "WORKSTATION FLATPAKS TO INSTALL" \
        "${WORKSTATION_FLATPAKS[@]}"
    print_software_list "GAMING FLATPAKS TO INSTALL" "${GAMING_FLATPAKS[@]}"
    print_software_list "ADDITIONAL SYSTEM PACKAGES" \
        "${ADDITIONAL_SYSTEM_PACKAGES[@]}"
    print_software_list "ADDITIONAL FLATPAKS" "${ADDITIONAL_FLATPAKS[@]}"
    print_software_list "ADDITIONAL SNAPS" "${ADDITIONAL_SNAPS[@]}"

    if [[ -n "$remove_name" ]]; then
        local -n remove_entries="$remove_name"
        print_software_list "SOFTWARE TO REMOVE" "${remove_entries[@]}"
    else
        printf '\nSOFTWARE TO REMOVE\n'
        printf '%s\n' '------------------'
        printf '  (No fixed removal list applies to this distribution.)\n'
    fi
    print_software_list "ADDITIONAL BLOAT PACKAGES" \
        "${ADDITIONAL_BLOAT_PACKAGES[@]}"

    printf '\nNo software is changed by --list-software.\n'
}

install_core_software() {
    local array_name
    array_name="$(core_array_name)"
    local -n entries="$array_name"
    local -a packages=("${entries[@]}")

    print_software_list "NATIVE SOFTWARE THAT WILL BE INSTALLED" "${entries[@]}"

    if [[ ${#packages[@]} -eq 0 ]]; then
        success "No core native packages are configured."
        return 0
    fi

    ask "Install these native packages?" || {
        warn "Native software installation skipped."
        return 0
    }

    case "$DISTRO" in
        arch)
            run_sudo pacman -S --needed --noconfirm "${packages[@]}"
            ;;
        nobara|fedora)
            run_sudo dnf install -y "${packages[@]}"
            ;;
        debian)
            run_sudo env DEBIAN_FRONTEND=noninteractive apt update
            run_sudo env DEBIAN_FRONTEND=noninteractive apt install -y \
                "${packages[@]}"
            ;;
    esac
}

package_is_installed() {
    local package="$1"
    case "$DISTRO" in
        arch) pacman -Q "$package" >/dev/null 2>&1 ;;
        nobara|fedora) rpm -q "$package" >/dev/null 2>&1 ;;
        debian) dpkg-query -W -f='${Status}' "$package" 2>/dev/null | \
            grep -q 'install ok installed' ;;
    esac
}

remove_configured_software() {
    local array_name
    array_name="$(removal_array_name)"
    local -a configured_packages=("${ADDITIONAL_BLOAT_PACKAGES[@]}")
    local -a installed_entries=()
    local -a installed_packages=()
    local package

    if [[ -n "$array_name" ]]; then
        local -n distro_removal_packages="$array_name"
        configured_packages+=("${distro_removal_packages[@]}")
    fi

    if [[ ${#configured_packages[@]} -eq 0 ]]; then
        info "No software-removal packages are configured for ${PRETTY_NAME:-$DISTRO}."
        return 0
    fi

    for package in "${configured_packages[@]}"; do
        if package_is_installed "$package"; then
            installed_entries+=("$package")
            installed_packages+=("$package")
        fi
    done

    if [[ ${#installed_packages[@]} -eq 0 ]]; then
        success "None of the configured removal packages are installed."
        return 0
    fi

    print_software_list "INSTALLED SOFTWARE THAT WILL BE REMOVED" \
        "${installed_entries[@]}"
    warn "Review this list carefully. Packages shown above will be uninstalled."

    ask "Remove exactly the software listed above?" || {
        warn "Software removal skipped."
        return 0
    }

    case "$DISTRO" in
        arch)
            run_sudo pacman -Rns --noconfirm "${installed_packages[@]}"
            ;;
        nobara|fedora)
            run_sudo dnf remove -y "${installed_packages[@]}"
            ;;
        debian)
            run_sudo env DEBIAN_FRONTEND=noninteractive apt remove -y \
                "${installed_packages[@]}"
            ;;
    esac
}

setup_flathub() {
    if ! command -v flatpak >/dev/null 2>&1; then
        if ! $DRY_RUN; then
            error "Flatpak is not installed. Run uppy --core first."
            return 1
        fi
        warn "Flatpak is not installed; continuing only because this is a dry-run."
    fi

    run_sudo flatpak --system remote-add --if-not-exists flathub \
        https://flathub.org/repo/flathub.flatpakrepo
}

install_flatpak_entries() {
    local heading="$1"
    shift
    local -a entries=("$@")
    local app_id

    print_software_list "$heading" "${entries[@]}"
    if [[ ${#entries[@]} -eq 0 ]]; then
        return 0
    fi

    ask "Install these applications system-wide?" || {
        warn "Flatpak installation skipped."
        return 0
    }

    setup_flathub
    for app_id in "${entries[@]}"; do
        run_sudo flatpak --system install -y flathub "$app_id"
    done
}

install_workstation_apps() {
    install_flatpak_entries "WORKSTATION FLATPAKS THAT WILL BE INSTALLED" \
        "${WORKSTATION_FLATPAKS[@]}"
}

install_gaming_apps() {
    local -a native_packages=("${CACHYOS_GAMING_PACKAGES[@]}")

    if [[ "${ID:-}" == "cachyos" ]]; then
        print_software_list "CACHYOS GAMING SOFTWARE THAT WILL BE INSTALLED" \
            "${CACHYOS_GAMING_PACKAGES[@]}"
        if ask "Install these native CachyOS gaming packages?"; then
            run_sudo pacman -S --needed --noconfirm "${native_packages[@]}"
        else
            warn "Native CachyOS gaming installation skipped."
        fi
    fi

    install_flatpak_entries "GAMING FLATPAKS THAT WILL BE INSTALLED" \
        "${GAMING_FLATPAKS[@]}"
}

install_additional_apps() {
    local -a packages=("${ADDITIONAL_SYSTEM_PACKAGES[@]}")
    local snap_name

    print_software_list "ADDITIONAL SYSTEM PACKAGES THAT WILL BE INSTALLED" \
        "${packages[@]}"
    if [[ ${#packages[@]} -gt 0 ]] && ask "Install these additional system packages?"; then
        case "$DISTRO" in
            arch)
                run_sudo pacman -S --needed --noconfirm "${packages[@]}"
                ;;
            nobara|fedora)
                run_sudo dnf install -y "${packages[@]}"
                ;;
            debian)
                run_sudo env DEBIAN_FRONTEND=noninteractive apt update
                run_sudo env DEBIAN_FRONTEND=noninteractive apt install -y \
                    "${packages[@]}"
                ;;
        esac
    fi

    install_flatpak_entries "ADDITIONAL FLATPAKS THAT WILL BE INSTALLED" \
        "${ADDITIONAL_FLATPAKS[@]}"

    print_software_list "ADDITIONAL SNAPS THAT WILL BE INSTALLED" \
        "${ADDITIONAL_SNAPS[@]}"
    if [[ ${#ADDITIONAL_SNAPS[@]} -eq 0 ]]; then
        return 0
    fi

    if ! command -v snap >/dev/null 2>&1; then
        if ! $DRY_RUN; then
            warn "snap is not installed; additional Snap applications were skipped."
            return 0
        fi
        warn "snap is not installed; continuing only because this is a dry-run."
    fi

    if ask "Install these Snap applications?"; then
        for snap_name in "${ADDITIONAL_SNAPS[@]}"; do
            run_sudo snap install "$snap_name"
        done
    fi
}

run_selected_modes() {
    if $MODE_ALL; then
        MODE_CORE=true
        MODE_REMOVE=true
        MODE_WORKSTATION=true
        MODE_GAMING=true
        MODE_ADDITIONAL_APPS=true
    fi

    $MODE_CORE && install_core_software
    $MODE_REMOVE && remove_configured_software
    $MODE_WORKSTATION && install_workstation_apps
    $MODE_GAMING && install_gaming_apps
    $MODE_ADDITIONAL_APPS && install_additional_apps
    return 0
}

run_interactive() {
    printf '\nINTERACTIVE SETUP\n'
    printf '%s\n' '================='
    printf 'Each section shows exactly what it will change before asking.\n'
    install_core_software
    remove_configured_software
    install_workstation_apps
    install_gaming_apps
    install_additional_apps
}

main() {
    parse_args "$@"
    validate_software_configuration
    detect_distro

    printf 'UPPY v%s\n' "$UPPY_VERSION"
    info "Detected: ${PRETTY_NAME:-$DISTRO}"

    if $MODE_LIST; then
        list_software
        exit 0
    fi

    # --check is read-only, so it must not install UPPY or create a log.
    if [[ "$RUN_ONLY" != "check" ]]; then
        setup_logging
        install_self
    fi
    $DRY_RUN && warn "Dry-run enabled; changing commands will only be printed."

    if $MODE_SETUP; then
        run_interactive
    elif $MODE_SELECTED; then
        run_selected_modes
    elif [[ -n "$RUN_ONLY" ]]; then
        run_routine_mode
    else
        run_routine_update
    fi

    success "UPPY finished."
}

main "$@"

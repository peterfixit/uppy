# Third-party notices

UPPY's original source code is licensed under the MIT License. A built AppImage
also contains third-party components that retain their own licenses.

## Qt for Python / PySide6 / Qt 6

The graphical interface uses PySide6 6.11.1, the official Qt for Python
bindings. PySide6 and the Qt libraries are offered under applicable LGPLv3,
GPL, and commercial licensing terms. This project selects the open-source
distribution from PyPI. See the license files shipped in the installed PySide6
wheel and <https://www.qt.io/licensing/open-source-lgpl-obligations>.

UPPY does not modify Qt or PySide6. They are loaded as separate shared
libraries in the generated bundle.

## PyInstaller

PyInstaller 6.21.0 is licensed under GPL-2.0-or-later with an exception that
permits distributing the generated executable under the application's license.
Its community hooks package contains GPL and Apache-2.0 licensed material.

## AppImageKit runtime and appimagetool

The build uses the AppImageKit `appimagetool` and runtime. Their source and
license information are available from <https://github.com/AppImage/AppImageKit>.

This notice is informational and is not a substitute for reviewing the license
files included with the exact dependency artifacts used for a distribution.

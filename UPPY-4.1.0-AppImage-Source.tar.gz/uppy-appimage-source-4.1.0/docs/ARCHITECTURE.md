# Architecture and privilege model

## Runtime flow

```text
Qt interface
  ├─ preview/report/backup ──> UPPY Bash backend as the desktop user
  └─ system change ──────────> pkexec ──> minimal runner ──> backend as root
```

The interface never constructs a shell command string for execution. Every
value is validated, then passed as a separate process argument. The backend
performs its own format and safety validation again before changing anything.

## AppImage contents

PyInstaller creates an onedir bundle containing the Python interpreter, PySide6
and the GUI modules. `build-appimage.sh` places that bundle in
`usr/lib/uppy/gui`, then adds the Bash backend, privileged runner, desktop file,
icon, AppStream metadata and documentation.

The host package managers and system administration tools are intentionally not
bundled. They must operate on the host distribution and its configured package
repositories.

## Persistent state

The AppImage is read-only. User-edited state lives in XDG locations:

- `$XDG_CONFIG_HOME/uppy/config.json`, normally `~/.config/uppy/config.json`
- `$XDG_STATE_HOME/uppy/gui.log`, normally `~/.local/state/uppy/gui.log`

The JSON configuration contains only application names and IDs. Unknown keys
are removed and invalid values are rejected. Writes are atomic and use private
file permissions.

## Privileged boundary

The only privileged wrapper is `scripts/uppy-privileged`. It finds the packaged
backend, marks the run as AppImage-hosted so the backend cannot self-install or
self-update, and replaces itself with the backend process.

The GUI uses PolicyKit only after the user reviews the exact backend arguments
and confirms the operation. Preview commands include `--dry-run` and run as the
desktop user.

## Package-value safety

- Each package, Flatpak ID and Snap name is validated independently.
- Values containing whitespace, shell metacharacters or line breaks are rejected.
- The GUI passes every value as an individual process argument.
- The backend repeats validation before invoking a package manager.
- Removal actions show their complete target list before confirmation.

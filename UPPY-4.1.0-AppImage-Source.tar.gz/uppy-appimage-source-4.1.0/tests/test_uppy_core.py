from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from uppy_core import (
    ConfigError,
    app_arguments,
    default_config,
    execution_arguments,
    load_config,
    normalize_config,
    save_config,
    setup_arguments,
    update_arguments,
)


class ConfigurationTests(unittest.TestCase):
    def test_default_configuration_is_valid(self) -> None:
        self.assertEqual(normalize_config(default_config()), default_config())

    def test_round_trip_uses_private_permissions(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "uppy/config.json"
            config = default_config()
            config["apps"]["system"] = ["htop"]
            save_config(config, path)
            self.assertEqual(load_config(path)["apps"]["system"], ["htop"])
            self.assertEqual(path.stat().st_mode & 0o777, 0o600)

    def test_unknown_keys_are_not_preserved(self) -> None:
        config = default_config()
        config["run_as_root_without_confirmation"] = True
        normalized = normalize_config(config)
        self.assertNotIn("run_as_root_without_confirmation", normalized)

    def test_invalid_package_entry_is_rejected(self) -> None:
        config = default_config()
        config["apps"]["system"] = ["htop curl"]
        with self.assertRaises(ConfigError):
            normalize_config(config)

    def test_removed_storage_settings_are_not_preserved(self) -> None:
        config = default_config()
        config["storage"] = {"legacy": True}
        self.assertNotIn("storage", normalize_config(config))

    def test_duplicate_entries_are_collapsed_in_order(self) -> None:
        config = default_config()
        config["apps"]["system"] = ["htop", "curl", "htop"]
        self.assertEqual(normalize_config(config)["apps"]["system"], ["htop", "curl"])

    def test_invalid_json_has_clear_error(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "config.json"
            path.write_text("{invalid", encoding="utf-8")
            with self.assertRaises(ConfigError):
                load_config(path)


class ArgumentTests(unittest.TestCase):
    def configured(self) -> dict:
        config = default_config()
        config["apps"] = {
            "system": ["htop"],
            "flatpak": ["org.example.App"],
            "snap": ["example-snap"],
            "remove": ["example-bloat"],
        }
        return normalize_config(config)

    def test_app_arguments_are_repeatable_flags(self) -> None:
        args = app_arguments(self.configured(), install=True, remove=True)
        self.assertIn("--add-system", args)
        self.assertIn("htop", args)
        self.assertIn("--add-flatpak", args)
        self.assertIn("--add-snap", args)
        self.assertIn("--add-bloat", args)

    def test_setup_arguments_combine_modes(self) -> None:
        selected = {
            "core": True,
            "workstation": True,
            "gaming": False,
            "additional_apps": True,
            "remove_software": True,
        }
        args = setup_arguments(self.configured(), selected)
        self.assertIn("--core", args)
        self.assertIn("--workstation", args)
        self.assertIn("--add-system", args)
        self.assertIn("--add-bloat", args)

    def test_removed_setup_mode_is_rejected(self) -> None:
        with self.assertRaises(ConfigError):
            setup_arguments(default_config(), {"mounts": True})

    def test_no_setup_selection_is_rejected(self) -> None:
        with self.assertRaises(ConfigError):
            setup_arguments(default_config(), {})

    def test_preview_adds_yes_and_dry_run(self) -> None:
        args = execution_arguments(["--clean"], preview=True)
        self.assertEqual(args, ["--clean", "--yes", "--dry-run"])

    def test_update_variants(self) -> None:
        self.assertEqual(update_arguments(maintenance=False, reboot=False), ["--no-maintenance"])
        self.assertEqual(update_arguments(maintenance=True, reboot=False), ["--update"])
        self.assertEqual(update_arguments(maintenance=True, reboot=True), ["--reboot"])


if __name__ == "__main__":
    unittest.main()

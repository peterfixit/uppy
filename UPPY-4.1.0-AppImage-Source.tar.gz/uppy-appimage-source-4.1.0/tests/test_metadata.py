from __future__ import annotations

import configparser
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path

from uppy_core import APP_VERSION


ROOT = Path(__file__).resolve().parents[1]
APP_ID = "io.pmhs.uppy"
MAIN_CATEGORIES = {
    "AudioVideo",
    "Audio",
    "Video",
    "Development",
    "Education",
    "Game",
    "Graphics",
    "Network",
    "Office",
    "Science",
    "Settings",
    "System",
    "Utility",
}


class DesktopMetadataTests(unittest.TestCase):
    def test_desktop_file_has_one_main_category(self) -> None:
        parser = configparser.ConfigParser(interpolation=None)
        parser.optionxform = str
        parser.read(ROOT / "packaging" / f"{APP_ID}.desktop", encoding="utf-8")
        entry = parser["Desktop Entry"]
        categories = {value for value in entry["Categories"].split(";") if value}
        self.assertEqual(categories & MAIN_CATEGORIES, {"System"})
        self.assertEqual(entry["Icon"], APP_ID)

    def test_appstream_source_has_project_identity_without_live_homepage(self) -> None:
        metadata_path = ROOT / "packaging" / f"{APP_ID}.appdata.xml"
        root = ET.parse(metadata_path).getroot()
        self.assertEqual(root.findtext("id"), APP_ID)
        self.assertEqual(root.findtext("launchable"), f"{APP_ID}.desktop")

        self.assertIsNone(root.find("url[@type='homepage']"))
        self.assertIn(
            '<!-- <url type="homepage">https://pmhs.au/</url> -->',
            metadata_path.read_text(encoding="utf-8"),
        )

        developer = root.find("developer")
        self.assertIsNotNone(developer)
        self.assertTrue(developer.get("id"))
        self.assertTrue(developer.findtext("name"))

        releases = root.find("releases")
        self.assertIsNotNone(releases)
        self.assertEqual(releases[0].get("version"), APP_VERSION)

    def test_appstream_metadata_is_not_bundled_without_a_real_homepage(self) -> None:
        build_script = (ROOT / "build-appimage.sh").read_text(encoding="utf-8")
        self.assertNotIn("usr/share/metainfo", build_script)
        self.assertNotIn(
            'install -m 0644 "$ROOT_DIR/packaging/io.pmhs.uppy.appdata.xml"',
            build_script,
        )

    def test_packaging_versions_match_application(self) -> None:
        parser = configparser.ConfigParser(interpolation=None)
        parser.optionxform = str
        parser.read(ROOT / "packaging" / f"{APP_ID}.desktop", encoding="utf-8")
        self.assertEqual(parser["Desktop Entry"]["X-AppImage-Version"], APP_VERSION)

        build_script = (ROOT / "build-appimage.sh").read_text(encoding="utf-8")
        backend = (ROOT / "src" / "uppy-backend.sh").read_text(encoding="utf-8")
        self.assertIn(f'VERSION="{APP_VERSION}"', build_script)
        self.assertIn(f'UPPY_VERSION="{APP_VERSION}"', backend)


if __name__ == "__main__":
    unittest.main()

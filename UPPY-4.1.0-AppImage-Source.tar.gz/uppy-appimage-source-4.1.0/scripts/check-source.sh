#!/usr/bin/env bash

set -Eeuo pipefail

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
PYTHON="${PYTHON:-python3}"
PYCACHE_DIR="${TMPDIR:-/tmp}/uppy-check-pycache-$$"
trap 'rm -rf -- "$PYCACHE_DIR"' EXIT

printf '[check] Bash syntax\n'
for script in \
    "$ROOT_DIR/build-appimage.sh" \
    "$ROOT_DIR/run-from-source.sh" \
    "$ROOT_DIR/scripts/check-source.sh" \
    "$ROOT_DIR/scripts/uppy-privileged" \
    "$ROOT_DIR/packaging/AppRun" \
    "$ROOT_DIR/src/uppy-backend.sh"; do
    bash -n "$script"
done

printf '[check] Python syntax and unit tests\n'
PYTHONPYCACHEPREFIX="$PYCACHE_DIR" "$PYTHON" -m py_compile \
    "$ROOT_DIR/src/main.py" "$ROOT_DIR/src/uppy_core.py"
PYTHONPATH="$ROOT_DIR/src" PYTHONPYCACHEPREFIX="$PYCACHE_DIR" \
    "$PYTHON" -m unittest discover -s "$ROOT_DIR/tests" -v

printf '[check] Desktop metadata\n'
"$PYTHON" -c 'import sys, xml.etree.ElementTree as ET; ET.parse(sys.argv[1])' \
    "$ROOT_DIR/packaging/io.pmhs.uppy.appdata.xml"
"$PYTHON" -c 'import sys, xml.etree.ElementTree as ET; ET.parse(sys.argv[1])' \
    "$ROOT_DIR/packaging/io.pmhs.uppy.svg"
if command -v desktop-file-validate >/dev/null 2>&1; then
    desktop-file-validate "$ROOT_DIR/packaging/io.pmhs.uppy.desktop"
fi

printf '[check] Backend command paths\n'
APPIMAGE="UPPY-test" "$ROOT_DIR/src/uppy-backend.sh" --version | grep -Fxq '4.1.0'
APPIMAGE="UPPY-test" "$ROOT_DIR/src/uppy-backend.sh" --help >/dev/null
APPIMAGE="UPPY-test" "$ROOT_DIR/src/uppy-backend.sh" \
    --dry-run --yes \
    --add-system htop \
    --add-flatpak org.example.Application \
    --add-snap example-snap \
    --add-bloat example-bloat >/dev/null
if APPIMAGE="UPPY-test" "$ROOT_DIR/src/uppy-backend.sh" \
    --dry-run --yes --mounts >/dev/null 2>&1; then
    printf '[ERROR] A removed storage option is still accepted.\n' >&2
    exit 1
fi
if APPIMAGE="UPPY-test" "$ROOT_DIR/src/uppy-backend.sh" \
    --dry-run --yes --add-system 'unsafe package' >/dev/null 2>&1; then
    printf '[ERROR] An unsafe software value was accepted.\n' >&2
    exit 1
fi

if command -v rg >/dev/null 2>&1; then
    personal_matches="$(rg -n -i 'buddybackup|poolz|192\.168\.' \
        --glob '!check-source.sh' "$ROOT_DIR" || true)"
else
    personal_matches="$(grep -RInE 'buddybackup|poolz|192\.168\.' \
        --exclude='check-source.sh' --exclude-dir='.build' --exclude-dir='.venv' \
        "$ROOT_DIR" || true)"
fi
if [[ -n "$personal_matches" ]]; then
    printf '%s\n' "$personal_matches"
    printf '[ERROR] Personal storage configuration was found in the source tree.\n' >&2
    exit 1
fi

if command -v rg >/dev/null 2>&1; then
    share_code_matches="$(rg -n -i '\b(nfs|cifs|iscsi)\b|/etc/fstab' \
        "$ROOT_DIR/src" "$ROOT_DIR/packaging" || true)"
else
    share_code_matches="$(grep -RInEi '\b(nfs|cifs|iscsi)\b|/etc/fstab' \
        "$ROOT_DIR/src" "$ROOT_DIR/packaging" || true)"
fi
if [[ -n "$share_code_matches" ]]; then
    printf '%s\n' "$share_code_matches"
    printf '[ERROR] Removed share-management code was found in the runtime source.\n' >&2
    exit 1
fi

printf '[check] All checks passed.\n'

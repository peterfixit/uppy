# Changelog

## 4.1.0 source refresh — 2026-07-21

- Commented out the unrelated `pmhs.au` homepage metadata.
- Stopped bundling incomplete AppStream metadata, preventing build-time URL
  checks and fatal missing-homepage validation.

## 4.1.0 — 2026-07-21

- Removed all network-share and block-storage setup features from the GUI,
  settings, backend, dependencies, documentation and tests.
- Refocused UPPY on updates, maintenance, app installation and bloat removal.
- Reduced navigation to five clear pages.
- Added live custom-entry counts and explicit saved/unsaved status.
- Added a discard-edits action and a warning before closing with unsaved lists.
- Added automatic migration that drops obsolete 4.0 settings fields.
- Added regression checks that prevent removed share-management code returning.

## 4.0.0 — 2026-07-20

- Added a complete PySide6 desktop interface for the combined UPPY backend.
- Added preview and reviewed-confirmation workflows.
- Added an external, mode-0600 JSON configuration for AppImage persistence.
- Added simple system-package, Flatpak, Snap and bloat-removal list editors.
- Added graphical NFS, CIFS and iSCSI configuration.
- Added safe repeatable backend arguments for GUI-provided storage settings.
- Limited automatic iSCSI repair to ext4 while retaining the no-format rule.
- Added live output, log rotation, desktop metadata and original vector icon.
- Added PyInstaller/AppDir/AppImage build automation and source validation.
- Corrected AppStream project identity fields and desktop menu categorisation.

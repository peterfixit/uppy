#!/usr/bin/env bash

set -Eeuo pipefail

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
VENV_DIR="${UPPY_VENV_DIR:-$ROOT_DIR/.venv}"
PYTHON="${PYTHON:-python3}"

if [[ ! -x "$VENV_DIR/bin/python" ]]; then
    "$PYTHON" -m venv "$VENV_DIR"
    "$VENV_DIR/bin/python" -m pip install --upgrade pip
fi

if ! "$VENV_DIR/bin/python" -c 'import PySide6' >/dev/null 2>&1; then
    "$VENV_DIR/bin/python" -m pip install -r "$ROOT_DIR/requirements.txt"
fi

export UPPY_BACKEND="$ROOT_DIR/src/uppy-backend.sh"
export UPPY_PRIVILEGED_RUNNER="$ROOT_DIR/scripts/uppy-privileged"
export APPIMAGE="UPPY-source"

exec "$VENV_DIR/bin/python" "$ROOT_DIR/src/main.py" "$@"

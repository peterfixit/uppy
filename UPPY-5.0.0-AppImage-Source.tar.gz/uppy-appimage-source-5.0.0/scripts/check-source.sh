#!/usr/bin/env bash

set -Eeuo pipefail

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
CHECK_DIR="$(mktemp -d)"
CC="${CC:-cc}"
trap 'rm -rf -- "$CHECK_DIR"' EXIT

printf '[check] Shell syntax\n'
for script in \
    "$ROOT_DIR/build-appimage.sh" \
    "$ROOT_DIR/run-from-source.sh" \
    "$ROOT_DIR/scripts/dependencies.sh" \
    "$ROOT_DIR/scripts/check-source.sh" \
    "$ROOT_DIR/scripts/uppy-privileged" \
    "$ROOT_DIR/packaging/AppRun" \
    "$ROOT_DIR/tests/test_backend.sh" \
    "$ROOT_DIR/tests/test_privileged.sh" \
    "$ROOT_DIR/src/uppy-backend.sh"; do
    bash -n "$script"
done

printf '[check] Dependency bootstrap\n'
"$ROOT_DIR/tests/test_dependencies.sh"

printf '[check] Native GUI and core tests\n'
"$CC" -std=c11 -O2 -Wall -Wextra -Werror -pedantic \
    -I"$ROOT_DIR/src" \
    "$ROOT_DIR/tests/test_core.c" "$ROOT_DIR/src/uppy_core.c" \
    -o "$CHECK_DIR/test-core"
"$CHECK_DIR/test-core"

"$CC" -std=c11 -O2 -Wall -Wextra -Werror -pedantic \
    -I"$ROOT_DIR/src" \
    "$ROOT_DIR/src/uppy_gui.c" "$ROOT_DIR/src/uppy_core.c" \
    -Wl,--as-needed -Wl,-l:libX11.so.6 -Wl,-l:libcairo.so.2 -lm \
    -o "$CHECK_DIR/uppy-gui"
"$CHECK_DIR/uppy-gui" --self-test
for page in overview setup apps output about; do
    "$CHECK_DIR/uppy-gui" --render-preview "$CHECK_DIR/$page.png" "$page"
    [[ "$(od -An -tx1 -N8 "$CHECK_DIR/$page.png" | tr -d ' \n')" == "89504e470d0a1a0a" ]]
done

printf '[check] Backend distro and privilege tests\n'
"$ROOT_DIR/tests/test_backend.sh"
"$ROOT_DIR/tests/test_privileged.sh"

printf '[check] Desktop and source metadata\n'
grep -Fxq 'Categories=System;' "$ROOT_DIR/packaging/io.pmhs.uppy.desktop"
grep -Fxq 'X-AppImage-Version=5.0.0' "$ROOT_DIR/packaging/io.pmhs.uppy.desktop"
if command -v desktop-file-validate >/dev/null 2>&1; then
    desktop-file-validate "$ROOT_DIR/packaging/io.pmhs.uppy.desktop"
fi

grep -Fq '#define UPPY_VERSION "5.0.0"' "$ROOT_DIR/src/uppy_core.h"
grep -Fq 'UPPY_VERSION="5.0.0"' "$ROOT_DIR/src/uppy-backend.sh"
if command -v rg >/dev/null 2>&1; then
    privacy_matches="$(rg -n -i '\b(nfs|cifs|iscsi)\b|/etc/fstab|192\.168\.|buddybackup|pmhs\.au/' \
        "$ROOT_DIR/src" "$ROOT_DIR/packaging" || true)"
    legacy_matches="$(rg -n 'PySide|PyInstaller|requirements\.txt|main\.py|uppy_core\.py' \
        "$ROOT_DIR/src" "$ROOT_DIR/build-appimage.sh" "$ROOT_DIR/run-from-source.sh" || true)"
else
    privacy_matches="$(grep -REni '\b(nfs|cifs|iscsi)\b|/etc/fstab|192\.168\.|buddybackup|pmhs\.au/' \
        "$ROOT_DIR/src" "$ROOT_DIR/packaging" || true)"
    legacy_matches="$(grep -REn 'PySide|PyInstaller|requirements\.txt|main\.py|uppy_core\.py' \
        "$ROOT_DIR/src" "$ROOT_DIR/build-appimage.sh" "$ROOT_DIR/run-from-source.sh" || true)"
fi
if [[ -n "$privacy_matches" ]]; then
    printf '%s\n' "$privacy_matches"
    printf '[ERROR] Removed share code, personal data, or a website URL remains.\n' >&2
    exit 1
fi
if [[ -n "$legacy_matches" ]]; then
    printf '%s\n' "$legacy_matches"
    printf '[ERROR] Python/Qt packaging remnants remain.\n' >&2
    exit 1
fi

printf '[check] All checks passed.\n'

#!/usr/bin/env bash

# Shared build-dependency detection for build-appimage.sh and
# run-from-source.sh. This file is sourced; it intentionally does not change
# the caller's shell options.

UPPY_DEP_ISSUES=()
UPPY_DEP_PROBE_ERROR=""

uppy_dependency_family() {
    local os_release="${UPPY_OS_RELEASE:-/etc/os-release}"
    local id="" id_like="" line key value token

    [[ -r "$os_release" ]] || return 1
    while IFS='=' read -r key value; do
        value="${value%\"}"
        value="${value#\"}"
        value="${value%\'}"
        value="${value#\'}"
        case "$key" in
            ID) id="${value,,}" ;;
            ID_LIKE) id_like="${value,,}" ;;
        esac
    done < "$os_release"

    for token in "$id" $id_like; do
        case "$token" in
            arch|archlinux|cachyos|endeavouros|manjaro)
                printf 'arch\n'
                return 0
                ;;
            fedora|nobara|rhel|centos)
                printf 'fedora\n'
                return 0
                ;;
            debian|ubuntu|linuxmint|pop|pop_os)
                printf 'debian\n'
                return 0
                ;;
        esac
    done
    return 1
}

uppy_privilege_prefix() {
    if (( EUID == 0 )); then
        return 0
    fi
    if command -v sudo >/dev/null 2>&1; then
        printf 'sudo\n'
        return 0
    fi
    if command -v doas >/dev/null 2>&1; then
        printf 'doas\n'
        return 0
    fi
    return 1
}

uppy_dependency_command() {
    local family="$1"
    local prefix="${2:-sudo}"

    case "$family" in
        arch)
            printf '%s pacman -S --needed base-devel libx11 cairo curl\n' "$prefix"
            ;;
        fedora)
            printf '%s dnf install -y gcc binutils libX11 cairo curl\n' "$prefix"
            ;;
        debian)
            printf '%s apt-get update\n' "$prefix"
            printf '%s apt-get install -y build-essential binutils libx11-6 libcairo2 curl\n' "$prefix"
            ;;
        *)
            return 1
            ;;
    esac
}

uppy_check_dependencies() {
    local mode="${1:-build}"
    local cc="${CC:-cc}"
    local strip="${STRIP:-strip}"
    local command_name probe_dir
    local -a commands=("$cc" install)

    UPPY_DEP_ISSUES=()
    UPPY_DEP_PROBE_ERROR=""

    if [[ "$mode" == "build" ]]; then
        commands+=("$strip" ldd awk sha256sum stat)
    fi

    for command_name in "${commands[@]}"; do
        if ! command -v "$command_name" >/dev/null 2>&1; then
            UPPY_DEP_ISSUES+=("command: $command_name")
        fi
    done

    if command -v "$cc" >/dev/null 2>&1; then
        probe_dir="$(mktemp -d)"
        if ! printf '%s\n' 'int main(void) { return 0; }' | \
            "$cc" -x c - -Wl,--as-needed \
                -Wl,-l:libX11.so.6 -Wl,-l:libcairo.so.2 -lm \
                -o "$probe_dir/uppy-link-probe" \
                2>"$probe_dir/probe-error"; then
            UPPY_DEP_ISSUES+=("working C/X11/Cairo linker")
            UPPY_DEP_PROBE_ERROR="$(<"$probe_dir/probe-error")"
        fi
        rm -rf -- "$probe_dir"
    fi

    if [[ "$mode" == "build" ]] && \
        [[ -z "${APPIMAGETOOL:-}" ]] && \
        ! command -v appimagetool >/dev/null 2>&1 && \
        ! command -v curl >/dev/null 2>&1 && \
        ! command -v wget >/dev/null 2>&1; then
        UPPY_DEP_ISSUES+=("downloader: curl or wget")
    fi

    ((${#UPPY_DEP_ISSUES[@]} == 0))
}

uppy_print_dependency_issues() {
    local issue
    printf '[ERROR] Missing or unusable build dependencies:\n' >&2
    for issue in "${UPPY_DEP_ISSUES[@]}"; do
        printf '  - %s\n' "$issue" >&2
    done
}

uppy_install_dependencies() {
    local family="$1" prefix="$2"
    local -a elevate=()

    [[ -z "$prefix" ]] || elevate=("$prefix")
    case "$family" in
        arch)
            "${elevate[@]}" pacman -S --needed base-devel libx11 cairo curl
            ;;
        fedora)
            "${elevate[@]}" dnf install -y gcc binutils libX11 cairo curl
            ;;
        debian)
            "${elevate[@]}" apt-get update
            "${elevate[@]}" apt-get install -y \
                build-essential binutils libx11-6 libcairo2 curl
            ;;
        *)
            return 1
            ;;
    esac
}

uppy_ensure_dependencies() {
    local mode="${1:-build}"
    local assume_yes="${2:-0}"
    local force_install="${3:-0}"
    local family prefix answer

    if uppy_check_dependencies "$mode" && [[ "$force_install" != "1" ]]; then
        printf '[deps] Compiler and build dependencies are ready.\n'
        return 0
    fi

    if ((${#UPPY_DEP_ISSUES[@]} > 0)); then
        uppy_print_dependency_issues
    fi

    if ! family="$(uppy_dependency_family)"; then
        printf '[ERROR] Uppy could not identify a supported package manager.\n' >&2
        printf 'Install a C compiler, binutils, libX11.so.6, libcairo.so.2, and curl, then retry.\n' >&2
        return 1
    fi
    if ! prefix="$(uppy_privilege_prefix)"; then
        printf '[ERROR] Administrator access requires sudo or doas.\n' >&2
        return 1
    fi

    printf '\nRequired dependency command:\n'
    uppy_dependency_command "$family" "$prefix"

    if [[ "$assume_yes" != "1" && "$force_install" != "1" ]]; then
        if [[ ! -t 0 ]]; then
            printf '[ERROR] Cannot ask for confirmation without a terminal.\n' >&2
            printf 'Run this script again with --yes, or run the command shown above.\n' >&2
            return 1
        fi
        printf 'Install these dependencies now? [Y/n] '
        IFS= read -r answer
        case "${answer,,}" in
            ""|y|yes) ;;
            *)
                printf '[ERROR] Dependency installation declined.\n' >&2
                return 1
                ;;
        esac
    fi

    printf '\n[deps] Installing build dependencies for %s...\n' "$family"
    uppy_install_dependencies "$family" "$prefix"

    if ! uppy_check_dependencies "$mode"; then
        uppy_print_dependency_issues
        if [[ -n "$UPPY_DEP_PROBE_ERROR" ]]; then
            printf '\nCompiler/linker diagnostic:\n%s\n' "$UPPY_DEP_PROBE_ERROR" >&2
        fi
        printf '[ERROR] Dependencies are still incomplete after installation.\n' >&2
        return 1
    fi
    printf '[deps] Dependency check passed.\n'
}

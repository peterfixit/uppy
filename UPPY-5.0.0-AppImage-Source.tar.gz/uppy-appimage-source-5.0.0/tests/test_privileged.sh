#!/usr/bin/env bash

set -Eeuo pipefail

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
TEMP_DIR="$(mktemp -d)"
CALLER_UID="$(id -u)"
CANCEL_DIR="/tmp/uppy-${CALLER_UID}"
CANCEL_FILE="$CANCEL_DIR/cancel-$$-deadbeef"
EARLY_CANCEL_FILE="$CANCEL_DIR/cancel-$$-cafebabe"
HELPER_PID=""
trap '[[ -n "$HELPER_PID" ]] && kill "$HELPER_PID" 2>/dev/null || true; rm -rf -- "$TEMP_DIR"; rm -f -- "$CANCEL_FILE" "$EARLY_CANCEL_FILE"' EXIT

install -m 0755 "$ROOT_DIR/scripts/uppy-privileged" "$TEMP_DIR/uppy-privileged"
cat > "$TEMP_DIR/uppy-backend.sh" <<'EOF'
#!/usr/bin/env bash
trap 'exit 130' TERM INT HUP
printf 'fake backend started\n'
while true; do sleep 0.1; done
EOF
chmod 0755 "$TEMP_DIR/uppy-backend.sh"

mkdir -p "$CANCEL_DIR"
chmod 0700 "$CANCEL_DIR"
rm -f -- "$CANCEL_FILE"

set +e
PKEXEC_UID="$CALLER_UID" "$TEMP_DIR/uppy-privileged" \
    --cancel-file "$CANCEL_FILE" -- --test > "$TEMP_DIR/output" 2>&1 &
HELPER_PID=$!
set -e
sleep 0.3
touch "$CANCEL_FILE"
set +e
wait "$HELPER_PID"
status=$?
set -e
HELPER_PID=""
[[ $status -eq 130 ]] || {
    printf '[ERROR] Cancellation returned %s instead of 130.\n' "$status" >&2
    cat "$TEMP_DIR/output" >&2
    exit 1
}
grep -Fq 'Cancellation requested' "$TEMP_DIR/output"
[[ ! -e "$CANCEL_FILE" ]]

# A cancellation request can beat pkexec/helper startup. It must not be erased
# as a stale token and allowed to run indefinitely.
touch "$EARLY_CANCEL_FILE"
set +e
PKEXEC_UID="$CALLER_UID" "$TEMP_DIR/uppy-privileged" \
    --cancel-file "$EARLY_CANCEL_FILE" -- --test > "$TEMP_DIR/early-output" 2>&1
early_status=$?
set -e
[[ $early_status -eq 130 ]] || {
    printf '[ERROR] Early cancellation returned %s instead of 130.\n' "$early_status" >&2
    cat "$TEMP_DIR/early-output" >&2
    exit 1
}
grep -Fq 'Cancellation requested' "$TEMP_DIR/early-output"
[[ ! -e "$EARLY_CANCEL_FILE" ]]

if PKEXEC_UID="$CALLER_UID" "$TEMP_DIR/uppy-privileged" \
    --cancel-file "/tmp/cancel-$$-deadbeef" -- --test >/dev/null 2>&1; then
    printf '[ERROR] Unsafe cancellation path was accepted.\n' >&2
    exit 1
fi

printf 'test_privileged: all tests passed\n'

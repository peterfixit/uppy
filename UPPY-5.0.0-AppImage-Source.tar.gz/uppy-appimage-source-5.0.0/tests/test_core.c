#define _POSIX_C_SOURCE 200809L

#include "uppy_core.h"

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

static void expect_argument(const UppyArgs *args, size_t index,
                            const char *expected) {
    assert(index < args->length);
    assert(strcmp(args->values[index], expected) == 0);
}

static void test_validation(void) {
    assert(uppy_software_name_valid("htop"));
    assert(uppy_software_name_valid("org.example.App"));
    assert(uppy_software_name_valid("lib32-mesa"));
    assert(!uppy_software_name_valid(""));
    assert(!uppy_software_name_valid("--option"));
    assert(!uppy_software_name_valid("two words"));
    assert(!uppy_software_name_valid("name;touch"));
    assert(!uppy_software_name_valid("$(id)"));
}

static void test_lines(void) {
    UppyStringList list;
    char error[256] = "";
    char *joined;
    uppy_list_init(&list);
    assert(uppy_parse_lines(&list, " htop\n\nhtop\norg.example.App\n",
                            "test", error, sizeof(error)));
    assert(list.length == 2);
    joined = uppy_join_lines(&list);
    assert(joined != NULL);
    assert(strcmp(joined, "htop\norg.example.App") == 0);
    free(joined);
    assert(!uppy_parse_lines(&list, "okay\nbad entry\n", "test",
                             error, sizeof(error)));
    assert(strstr(error, "line 2") != NULL);
    assert(list.length == 2);
    uppy_list_clear(&list);
}

static void test_commands(void) {
    UppyConfig config;
    UppyArgs args;
    UppySetupSelection selected = {0};
    char error[256] = "";
    char *display;
    uppy_config_init(&config);
    assert(uppy_list_add(&config.system, "htop", error, sizeof(error)));
    assert(uppy_list_add(&config.flatpak, "org.example.App", error, sizeof(error)));
    assert(uppy_list_add(&config.snap, "example-snap", error, sizeof(error)));
    assert(uppy_list_add(&config.remove, "example-bloat", error, sizeof(error)));

    uppy_args_init(&args);
    assert(uppy_build_update_args(&args, true, false, true,
                                  error, sizeof(error)));
    assert(args.length == 3);
    expect_argument(&args, 0, "--update");
    expect_argument(&args, 1, "--yes");
    expect_argument(&args, 2, "--dry-run");
    uppy_args_clear(&args);

    uppy_args_init(&args);
    selected.core = true;
    selected.additional_apps = true;
    selected.remove_software = true;
    assert(uppy_build_setup_args(&args, &config, selected, false,
                                 error, sizeof(error)));
    expect_argument(&args, 0, "--core");
    expect_argument(&args, 1, "--add-system");
    expect_argument(&args, 2, "htop");
    expect_argument(&args, 3, "--add-flatpak");
    expect_argument(&args, 4, "org.example.App");
    expect_argument(&args, 5, "--add-snap");
    expect_argument(&args, 6, "example-snap");
    expect_argument(&args, 7, "--add-bloat");
    expect_argument(&args, 8, "example-bloat");
    expect_argument(&args, 9, "--yes");
    display = uppy_display_command(&args);
    assert(display != NULL && strstr(display, "'--add-system' 'htop'") != NULL);
    free(display);
    uppy_args_clear(&args);
    uppy_config_clear(&config);
}

static void test_config_round_trip(void) {
    char template[] = "/tmp/uppy-core-test-XXXXXX";
    char path[512];
    char malformed[512];
    char error[256] = "";
    char *directory;
    UppyConfig first;
    UppyConfig second;
    struct stat details;
    FILE *file;

    directory = mkdtemp(template);
    assert(directory != NULL);
    snprintf(path, sizeof(path), "%s/settings/config.json", directory);
    snprintf(malformed, sizeof(malformed), "%s/bad.json", directory);
    uppy_config_init(&first);
    uppy_config_init(&second);
    assert(uppy_list_add(&first.system, "htop", error, sizeof(error)));
    assert(uppy_list_add(&first.flatpak, "org.example.App", error, sizeof(error)));
    assert(uppy_config_save(&first, path, error, sizeof(error)));
    assert(stat(path, &details) == 0);
    assert((details.st_mode & 0777) == 0600);
    assert(uppy_config_load(&second, path, error, sizeof(error)));
    assert(second.system.length == 1);
    assert(second.flatpak.length == 1);
    assert(strcmp(second.system.items[0], "htop") == 0);

    file = fopen(malformed, "w");
    assert(file != NULL);
    fputs("{\"apps\": {\"system\": [\"okay\", \"bad value\"]}}", file);
    fclose(file);
    assert(!uppy_config_load(&second, malformed, error, sizeof(error)));

    file = fopen(malformed, "w");
    assert(file != NULL);
    fputs("{\"schema_version\":2,\"storage\":{\"old\":true},"
          "\"apps\":{\"system\":[\"migrated\"],\"flatpak\":[],"
          "\"snap\":[],\"remove\":[]}}", file);
    fclose(file);
    assert(uppy_config_load(&second, malformed, error, sizeof(error)));
    assert(second.system.length == 1);
    assert(strcmp(second.system.items[0], "migrated") == 0);

    file = fopen(malformed, "w");
    assert(file != NULL);
    fputs("{\"legacy\":nan,\"apps\":{}}", file);
    fclose(file);
    assert(!uppy_config_load(&second, malformed, error, sizeof(error)));
    assert(second.system.length == 1);

    file = fopen(malformed, "w");
    assert(file != NULL);
    fputs("{\"apps\": {\"system\": [\"first\"], \"system\": [\"second\"]}}", file);
    fclose(file);
    assert(!uppy_config_load(&second, malformed, error, sizeof(error)));

    uppy_config_clear(&first);
    uppy_config_clear(&second);
    unlink(path);
    unlink(malformed);
    {
        char settings_dir[512];
        snprintf(settings_dir, sizeof(settings_dir), "%s/settings", directory);
        rmdir(settings_dir);
    }
    rmdir(directory);
}

int main(void) {
    test_validation();
    test_lines();
    test_commands();
    test_config_round_trip();
    puts("test_core: all tests passed");
    return 0;
}

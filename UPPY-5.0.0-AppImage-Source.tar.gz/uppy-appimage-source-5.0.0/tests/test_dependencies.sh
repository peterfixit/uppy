#!/usr/bin/env bash

set -Eeuo pipefail

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
TEST_DIR="$(mktemp -d)"
trap 'rm -rf -- "$TEST_DIR"' EXIT

# shellcheck source=../scripts/dependencies.sh
source "$ROOT_DIR/scripts/dependencies.sh"

fail() {
    printf '[FAIL] %s\n' "$*" >&2
    exit 1
}

write_os_release() {
    printf 'ID=%s\nID_LIKE="%s"\n' "$1" "${2:-}" > "$TEST_DIR/os-release"
    UPPY_OS_RELEASE="$TEST_DIR/os-release"
}

write_os_release cachyos arch
[[ "$(uppy_dependency_family)" == "arch" ]] || fail 'CachyOS was not detected as Arch'
[[ "$(uppy_dependency_command arch sudo)" == *'base-devel libx11 cairo curl'* ]] || \
    fail 'Arch dependency command is incomplete'

write_os_release nobara fedora
[[ "$(uppy_dependency_family)" == "fedora" ]] || fail 'Nobara was not detected as Fedora'
[[ "$(uppy_dependency_command fedora sudo)" == *'gcc binutils libX11 cairo curl'* ]] || \
    fail 'Fedora dependency command is incomplete'

write_os_release ubuntu debian
[[ "$(uppy_dependency_family)" == "debian" ]] || fail 'Ubuntu was not detected as Debian'
debian_commands="$(uppy_dependency_command debian sudo)"
[[ "$debian_commands" == *'apt-get update'* ]] || fail 'Debian update command is missing'
[[ "$debian_commands" == *'build-essential binutils libx11-6 libcairo2 curl'* ]] || \
    fail 'Debian dependency command is incomplete'

write_os_release unsupported unknown
if uppy_dependency_family >/dev/null 2>&1; then
    fail 'An unsupported distribution was accepted'
fi

CC=uppy-intentionally-missing-compiler
if uppy_check_dependencies run; then
    fail 'A missing compiler was not detected'
fi
printf '%s\n' "${UPPY_DEP_ISSUES[@]}" | grep -Fqx \
    'command: uppy-intentionally-missing-compiler' || fail 'Missing compiler diagnostic is unclear'

printf '[test] Dependency detection and install plans passed.\n'

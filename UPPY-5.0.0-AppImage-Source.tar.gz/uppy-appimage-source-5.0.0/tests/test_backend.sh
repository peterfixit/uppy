#!/usr/bin/env bash

set -Eeuo pipefail

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
BACKEND="$ROOT_DIR/src/uppy-backend.sh"
TEMP_DIR="$(mktemp -d)"
trap 'rm -rf -- "$TEMP_DIR"' EXIT

mkdir -p "$TEMP_DIR/bin" "$TEMP_DIR/home"
for command_name in pacman dnf apt flatpak snap nobara-sync; do
    ln -s /bin/true "$TEMP_DIR/bin/$command_name"
done

write_os() {
    local id="$1" like="$2" name="$3"
    cat > "$TEMP_DIR/os-release" <<EOF
ID=$id
ID_LIKE="$like"
PRETTY_NAME="$name"
VERSION_ID=1
EOF
}

run_backend() {
    env PATH="$TEMP_DIR/bin:/usr/bin:/bin" HOME="$TEMP_DIR/home" \
        APPIMAGE=UPPY-test UPPY_TESTING=1 \
        UPPY_OS_RELEASE_FILE="$TEMP_DIR/os-release" \
        "$BACKEND" "$@"
}

write_os arch arch "Test Arch"
run_backend --no-maintenance --yes --dry-run > "$TEMP_DIR/arch.out"
grep -Fq 'pacman -Syu --noconfirm' "$TEMP_DIR/arch.out"

write_os fedora fedora "Test Fedora"
run_backend --no-maintenance --yes --dry-run > "$TEMP_DIR/fedora.out"
grep -Fq 'dnf upgrade -y' "$TEMP_DIR/fedora.out"

write_os debian debian "Test Debian"
run_backend --no-maintenance --yes --dry-run > "$TEMP_DIR/debian.out"
grep -Fq 'apt update' "$TEMP_DIR/debian.out"
grep -Fq 'apt full-upgrade -y' "$TEMP_DIR/debian.out"

write_os nobara fedora "Test Nobara"
run_backend --no-maintenance --yes --dry-run > "$TEMP_DIR/nobara.out"
grep -Fq 'nobara-sync cli' "$TEMP_DIR/nobara.out"

write_os cachyos arch "Test CachyOS"
run_backend --yes --dry-run \
    --add-system htop \
    --add-flatpak org.example.Application \
    --add-snap example-snap \
    --add-bloat example-bloat > "$TEMP_DIR/setup.out"
grep -Fq 'pacman -S --needed --noconfirm htop' "$TEMP_DIR/setup.out"
grep -Fq 'flatpak --system install -y flathub org.example.Application' "$TEMP_DIR/setup.out"
grep -Fq 'snap install example-snap' "$TEMP_DIR/setup.out"
grep -Fq 'example-bloat' "$TEMP_DIR/setup.out"

[[ ! -e "$TEMP_DIR/home/uppy.log" ]]

if run_backend --yes --dry-run --add-system 'unsafe package' >/dev/null 2>&1; then
    printf '[ERROR] Unsafe package value was accepted.\n' >&2
    exit 1
fi
if run_backend --yes --dry-run --mounts >/dev/null 2>&1; then
    printf '[ERROR] Removed storage mode was accepted.\n' >&2
    exit 1
fi
if run_backend --self-update >/dev/null 2>&1; then
    printf '[ERROR] Removed script self-update mode was accepted.\n' >&2
    exit 1
fi

write_os bazzite fedora "Test Immutable Fedora"
if run_backend --check > "$TEMP_DIR/immutable.out" 2>&1; then
    printf '[ERROR] Immutable Fedora variant was accepted.\n' >&2
    exit 1
fi
grep -Fq 'Unsupported immutable Fedora variant' "$TEMP_DIR/immutable.out"

printf 'test_backend: all tests passed\n'

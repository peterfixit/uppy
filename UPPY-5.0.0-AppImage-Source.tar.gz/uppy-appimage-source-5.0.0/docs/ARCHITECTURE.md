# UPPY architecture

UPPY deliberately separates an unprivileged interface from a small privileged
backend boundary.

```text
Native GUI (ordinary user)
  ├─ settings, previews, reports and output
  └─ reviewed change request
       ↓ pkexec
privileged helper
  ├─ resolves only its adjacent fixed backend
  ├─ validates a caller-owned cancellation path
  └─ supervises one backend process group
       ↓
Bash backend
  ├─ validates all names again
  ├─ detects the supported distro family
  └─ invokes pacman, dnf/nobara-sync, apt, flatpak or snap
```

## Trust boundaries

The GUI never builds a shell command string for execution. It builds an argv
array, shows a separately quoted display form, then passes the original values
as individual arguments. The root helper does not accept a backend path or
arbitrary executable. It locates `uppy-backend.sh` beside itself and forwards
the already-separated arguments.

Package values must start with an ASCII letter or digit and may then contain
only letters, digits, `@`, `.`, `_`, `+`, `:`, or `-`. The GUI and backend both
enforce that rule.

## Cancellation

Killing `pkexec` from the unprivileged side is unreliable after it becomes
root. Uppy creates a random, caller-owned token path below a private `0700`
runtime directory. The helper validates the directory, owner, mode, canonical
location and token name before starting. It then monitors that token and stops
the complete backend process group with TERM followed by KILL after a grace
period. The GUI deliberately keeps `pkexec` alive until the helper exits; this
prevents a cancellation race from orphaning a privileged package-manager
process.

## Packaging

The GUI directly uses the stable Xlib and Cairo ABIs. The build copies the
resolved non-glibc graphics dependency closure into the AppDir and sets a
private library path from `AppRun`. Glibc, the kernel, X11/XWayland, PolicyKit
and host package managers remain host components.

No AppStream file is included, so appimagetool performs no homepage check.

# Third-party notices

UPPY source code is MIT licensed. A built AppImage also contains the
`appimagetool` runtime and copies of the non-glibc libraries resolved by `ldd`
for the native X11/Cairo interface.

Depending on the build distribution, that closure normally includes:

- Cairo — LGPL-2.1-or-later or MPL-1.1
- Xlib, Xext, Xrender, Xau and Xdmcp — MIT/X11 family licences
- XCB and XCB render/shared-memory libraries — MIT/X11 family licences
- Pixman — MIT
- Fontconfig — MIT
- FreeType — FreeType Licence or GPL-2.0-or-later
- libpng — libpng licence
- zlib — zlib licence
- Expat — MIT
- bzip2 — BSD-style licence
- Brotli — MIT
- libbsd and libmd — BSD-style licences
- AppImageKit runtime — MIT

These components remain separate dynamically linked libraries inside the
AppImage. Their names and exact versions are determined by the machine that
builds the AppImage. Run `ldd .build/bin/uppy-gui` and inspect
`.build/UPPY.AppDir/usr/lib/uppy/lib/` for the exact set in a build.

Upstream licence information:

- https://www.cairographics.org/
- https://www.x.org/releases/current/doc/libX11/libX11/libX11.html
- https://xcb.freedesktop.org/
- https://www.freedesktop.org/wiki/Software/fontconfig/
- https://freetype.org/license.html
- https://www.libpng.org/pub/png/src/libpng-LICENSE.txt
- https://zlib.net/zlib_license.html
- https://github.com/AppImage/AppImageKit

The package managers, PolicyKit service and display server are host programs
invoked or contacted by Uppy; they are not included in this source archive.

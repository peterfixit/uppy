#!/usr/bin/env bash

set -Eeuo pipefail

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
BUILD_DIR="${UPPY_BUILD_DIR:-$ROOT_DIR/.build-source}"
CC="${CC:-cc}"

# shellcheck source=scripts/dependencies.sh
source "$ROOT_DIR/scripts/dependencies.sh"

case "${1:-}" in
    --check-deps)
        if uppy_check_dependencies run; then
            printf '[deps] Compiler and runtime-link dependencies are ready.\n'
            exit 0
        fi
        uppy_print_dependency_issues
        if family="$(uppy_dependency_family)"; then
            printf '\nInstall with:\n'
            uppy_dependency_command "$family" sudo
        fi
        exit 1
        ;;
    --install-deps)
        uppy_ensure_dependencies run 1 1
        exit 0
        ;;
    --yes)
        shift
        uppy_ensure_dependencies run 1 0
        ;;
    *)
        uppy_ensure_dependencies run 0 0
        ;;
esac

install -d "$BUILD_DIR"
"$CC" -std=c11 -O2 -Wall -Wextra -Werror -pedantic \
    -I"$ROOT_DIR/src" \
    "$ROOT_DIR/src/uppy_gui.c" "$ROOT_DIR/src/uppy_core.c" \
    -Wl,--as-needed -Wl,-l:libX11.so.6 -Wl,-l:libcairo.so.2 -lm \
    -o "$BUILD_DIR/uppy-gui"

export UPPY_BACKEND="$ROOT_DIR/src/uppy-backend.sh"
export UPPY_PRIVILEGED_RUNNER="$ROOT_DIR/scripts/uppy-privileged"
export APPIMAGE="UPPY-source"
exec "$BUILD_DIR/uppy-gui" "$@"

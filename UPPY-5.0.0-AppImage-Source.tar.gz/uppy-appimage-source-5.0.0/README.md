# UPPY 5.0.0 — compact AppImage source

UPPY is a graphical Linux updater, maintenance tool and software-setup utility
for Arch-, Fedora- and Debian-based systems. Version 5 replaces the earlier
Python/Qt interface with a small native C/Cairo interface while retaining the
hardened Bash package-management backend.

The build has a strict acceptance check: the completed AppImage must be less
than **25,000,000 bytes**. A build at or above that size fails.

## What Uppy does

- Updates installed native packages and system-wide Flatpaks.
- Optionally removes orphan packages and cleans package/Flatpak caches.
- Installs configurable core, workstation and gaming profiles.
- Saves simple one-name-per-line lists for native packages, Flatpaks and Snaps.
- Adds user-selected packages to the reviewed bloat-removal operation.
- Produces system reports and package/configuration backups.
- Streams live output and saves timestamped output files.

NFS, CIFS/SMB, iSCSI and all share-management code have been removed.

## Safety design

- Previews append `--dry-run` and do not request administrator access.
- Changes require an explicit reviewed confirmation before PolicyKit opens.
- Package removal remains locked until a successful preview of the exact
  current selection; the approval expires after 10 minutes or any list change.
- The interface and backend independently validate every package/app value.
- Values are passed as separate process arguments and never evaluated as code.
- Immutable Fedora systems such as Bazzite, Aurora, Silverblue and Kinoite are
  rejected instead of incorrectly attempting to run `dnf` on the host image.
- Authenticated cancellation is monitored by the root helper, so cancelling
  stops the backend process group rather than only closing `pkexec`.
- Settings use atomic replacement and mode `0600`; malformed files leave the
  existing file untouched and load safe empty lists.
- GUI logs rotate at approximately 2 MB. Output memory is also capped at 2 MB.

Package-manager cancellation should still be used only for a genuinely stuck
task. Interrupting a transaction can require recovery with the distribution's
package manager.

## Supported systems

- Arch Linux, CachyOS, EndeavourOS and Manjaro
- Fedora and Nobara
- Debian, Ubuntu, Linux Mint, Pop!_OS and compatible Debian-based systems

Uppy requires an X11 display or XWayland. Package changes require PolicyKit's
`pkexec`. The AppImage bundles its Cairo/X11 client libraries, but it cannot
bundle the host display server, package managers or PolicyKit service.

Like other native AppImages, a build inherits the C-library baseline of the
machine used to compile it. A build made for one computer will work on that
computer; for redistribution to older systems, build on the oldest Linux
release you intend to support.

## Build prerequisites

No Rust, Python, Qt, GTK development kit or C header package is needed. Uppy
declares the small stable Xlib/Cairo ABI subset it uses and links directly to
the installed runtime libraries.

You do not need to install these manually. Both launchers detect missing
dependencies, show the exact distro-specific command, and ask permission to
install them. On Arch/CachyOS, for example:

```text
Missing or unusable build dependencies:
  - command: cc

Required dependency command:
sudo pacman -S --needed base-devel libx11 cairo curl
Install these dependencies now? [Y/n]
```

Use `./build-appimage.sh --yes` to approve dependency installation without the
extra question, or `./build-appimage.sh --check-deps` to make no changes and
only report what is missing.

The equivalent manual commands are:

Arch/CachyOS:

```bash
sudo pacman -S --needed base-devel libx11 cairo binutils curl
```

Fedora/Nobara:

```bash
sudo dnf install gcc libX11 cairo binutils curl
```

Debian/Ubuntu:

```bash
sudo apt install build-essential libx11-6 libcairo2 binutils curl
```

## Build

```bash
chmod +x build-appimage.sh run-from-source.sh scripts/*.sh tests/*.sh
./build-appimage.sh
```

Output:

```text
dist-appimage/UPPY-5.0.0-<architecture>.AppImage
```

The builder performs these checks before reporting success:

1. Strict C and Bash compilation/syntax checks.
2. Configuration parser, validation and command-builder unit tests.
3. Dry-run backend tests for Arch, Fedora, Nobara and Debian.
4. Unsafe-input, removed-option and immutable-system rejection tests.
5. Privileged-helper cancellation and path-validation tests.
6. Headless rendering of all five GUI pages.
7. AppDir self-test and completed-AppImage extraction self-test.
8. A strict final size check below 25,000,000 bytes.

`appimagetool` is downloaded to the private `.build` directory if unavailable.
Use `APPIMAGETOOL=/absolute/path/to/appimagetool` to select an existing copy, or
`NO_DOWNLOAD=1` to prohibit downloads.

Build dependency controls:

```bash
./build-appimage.sh --check-deps       # report only; change nothing
./build-appimage.sh --install-deps     # install dependencies, then exit
./build-appimage.sh --yes              # install if needed, then build
./build-appimage.sh --no-install-deps  # fail instead of offering installation
```

## Run from source

```bash
./run-from-source.sh
```

`run-from-source.sh` performs the same dependency check and installation prompt
before compiling. It also accepts `--check-deps`, `--install-deps`, and `--yes`.

Useful non-GUI checks:

```bash
./run-from-source.sh --self-test
./scripts/check-source.sh
```

## Settings, logs and backups

- App lists: `~/.config/uppy/config.json`
- GUI log: `~/.local/state/uppy/gui.log`
- Privileged backend log: `/var/log/uppy.log`
- Package/configuration backups: `~/uppy-backups/<timestamp>-<suffix>`
- Saved output: `~/Downloads/uppy-output-<timestamp>.txt`

Existing Uppy 4 settings are accepted. Unknown legacy fields are ignored, and
the four supported app lists are retained when settings are next saved.

## Build controls

| Variable | Purpose |
| --- | --- |
| `CC` | C compiler; default `cc`. |
| `STRIP` | Binary-strip tool; default `strip`. |
| `UPPY_BUILD_DIR` | Private build directory; default `.build`. |
| `UPPY_OUTPUT_DIR` | AppImage output directory; default `dist-appimage`. |
| `APPIMAGETOOL` | Absolute path to an existing appimagetool. |
| `NO_DOWNLOAD=1` | Refuse to download appimagetool. |
| `MAX_APPIMAGE_BYTES` | Size gate; default `25000000`. |

## Project layout

```text
src/uppy_gui.c             Native interface, process handling and rendering
src/uppy_core.c            Settings parser, validation and command construction
src/uppy-backend.sh        Host package-management backend
scripts/uppy-privileged    PolicyKit boundary and authenticated cancellation
scripts/check-source.sh    Full source validation
tests/                     Native, backend and privilege tests
packaging/                 AppRun, desktop metadata and vector icon
build-appimage.sh          Build, bundle, self-test and size gate
```

## Metadata and network access

The AppDir intentionally contains no AppStream metadata or homepage URL. The
build therefore does not contact `pmhs.au` or validate any project website.
Uppy itself only uses network access through the host package managers selected
by the user.

## Licence

UPPY is MIT licensed. See `LICENSE`. Libraries copied into the AppImage keep
their upstream licences; see `THIRD_PARTY_NOTICES.md`.

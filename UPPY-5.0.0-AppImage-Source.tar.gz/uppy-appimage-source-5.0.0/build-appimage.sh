#!/usr/bin/env bash

set -Eeuo pipefail

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
VERSION="5.0.0"
CC="${CC:-cc}"
STRIP="${STRIP:-strip}"
BUILD_DIR="${UPPY_BUILD_DIR:-$ROOT_DIR/.build}"
OUTPUT_DIR="${UPPY_OUTPUT_DIR:-$ROOT_DIR/dist-appimage}"
APPDIR="$BUILD_DIR/UPPY.AppDir"
MAX_APPIMAGE_BYTES="${MAX_APPIMAGE_BYTES:-25000000}"

# shellcheck source=scripts/dependencies.sh
source "$ROOT_DIR/scripts/dependencies.sh"

ASSUME_YES=0
DEPENDENCY_MODE="auto"

usage() {
    cat <<'EOF'
Usage: ./build-appimage.sh [OPTION]

Build the UPPY AppImage. Missing build dependencies can be installed
automatically on Arch/CachyOS, Fedora/Nobara, and Debian/Ubuntu systems.

Options:
  --yes              Install missing dependencies without prompting
  --check-deps       Check dependencies and exit
  --install-deps     Install the complete dependency set and exit
  --no-install-deps  Never offer to install missing dependencies
  -h, --help         Show this help
EOF
}

while (($# > 0)); do
    case "$1" in
        --yes) ASSUME_YES=1 ;;
        --check-deps) DEPENDENCY_MODE="check" ;;
        --install-deps) DEPENDENCY_MODE="install"; ASSUME_YES=1 ;;
        --no-install-deps) DEPENDENCY_MODE="never" ;;
        -h|--help) usage; exit 0 ;;
        *) printf '[ERROR] Unknown option: %s\n' "$1" >&2; usage >&2; exit 2 ;;
    esac
    shift
done

case "$(uname -m)" in
    x86_64) APPIMAGE_ARCH="x86_64"; TOOL_ASSET="appimagetool-x86_64.AppImage" ;;
    aarch64|arm64) APPIMAGE_ARCH="aarch64"; TOOL_ASSET="appimagetool-aarch64.AppImage" ;;
    *) printf '[ERROR] Unsupported architecture: %s\n' "$(uname -m)" >&2; exit 1 ;;
esac

case "$DEPENDENCY_MODE" in
    check)
        if uppy_check_dependencies build; then
            printf '[deps] Compiler and build dependencies are ready.\n'
            exit 0
        fi
        uppy_print_dependency_issues
        if family="$(uppy_dependency_family)"; then
            printf '\nInstall with:\n'
            uppy_dependency_command "$family" sudo
        fi
        exit 1
        ;;
    install)
        uppy_ensure_dependencies build 1 1
        exit 0
        ;;
    never)
        if ! uppy_check_dependencies build; then
            uppy_print_dependency_issues
            if family="$(uppy_dependency_family)"; then
                printf '\nInstall with:\n'
                uppy_dependency_command "$family" sudo
            fi
            exit 1
        fi
        ;;
    auto)
        uppy_ensure_dependencies build "$ASSUME_YES" 0
        ;;
esac

"$ROOT_DIR/scripts/check-source.sh"

printf '\n[1/6] Compiling native interface\n'
install -d "$BUILD_DIR/bin" "$OUTPUT_DIR"
"$CC" -std=c11 -O2 -DNDEBUG -fstack-protector-strong \
    -D_FORTIFY_SOURCE=2 -Wall -Wextra -Werror -pedantic \
    -I"$ROOT_DIR/src" \
    "$ROOT_DIR/src/uppy_gui.c" "$ROOT_DIR/src/uppy_core.c" \
    -Wl,--as-needed -Wl,-z,relro,-z,now \
    -Wl,-l:libX11.so.6 -Wl,-l:libcairo.so.2 -lm \
    -o "$BUILD_DIR/bin/uppy-gui"
"$STRIP" --strip-unneeded "$BUILD_DIR/bin/uppy-gui"
"$BUILD_DIR/bin/uppy-gui" --self-test

printf '\n[2/6] Assembling AppDir\n'
rm -rf -- "$APPDIR"
install -d \
    "$APPDIR/usr/bin" \
    "$APPDIR/usr/lib/uppy/lib" \
    "$APPDIR/usr/share/applications" \
    "$APPDIR/usr/share/icons/hicolor/scalable/apps" \
    "$APPDIR/usr/share/doc/uppy"
install -m 0755 "$BUILD_DIR/bin/uppy-gui" "$APPDIR/usr/bin/uppy-gui"
install -m 0755 "$ROOT_DIR/src/uppy-backend.sh" "$APPDIR/usr/lib/uppy/uppy-backend.sh"
install -m 0755 "$ROOT_DIR/scripts/uppy-privileged" "$APPDIR/usr/lib/uppy/uppy-privileged"
install -m 0755 "$ROOT_DIR/packaging/AppRun" "$APPDIR/AppRun"
install -m 0644 "$ROOT_DIR/packaging/io.pmhs.uppy.desktop" \
    "$APPDIR/usr/share/applications/io.pmhs.uppy.desktop"
install -m 0644 "$ROOT_DIR/packaging/io.pmhs.uppy.svg" \
    "$APPDIR/usr/share/icons/hicolor/scalable/apps/io.pmhs.uppy.svg"
install -m 0644 "$ROOT_DIR/LICENSE" "$APPDIR/usr/share/doc/uppy/LICENSE"
install -m 0644 "$ROOT_DIR/README.md" "$APPDIR/usr/share/doc/uppy/README.md"
install -m 0644 "$ROOT_DIR/THIRD_PARTY_NOTICES.md" \
    "$APPDIR/usr/share/doc/uppy/THIRD_PARTY_NOTICES.md"
install -m 0644 "$ROOT_DIR/packaging/io.pmhs.uppy.desktop" \
    "$APPDIR/io.pmhs.uppy.desktop"
install -m 0644 "$ROOT_DIR/packaging/io.pmhs.uppy.svg" \
    "$APPDIR/io.pmhs.uppy.svg"
install -m 0644 "$ROOT_DIR/packaging/io.pmhs.uppy.svg" "$APPDIR/.DirIcon"

printf '\n[3/6] Bundling the small graphics-library closure\n'
while IFS= read -r library; do
    name="$(basename -- "$library")"
    case "$name" in
        libc.so.*|libm.so.*|libdl.so.*|libpthread.so.*|librt.so.*|ld-linux*.so.*) continue ;;
    esac
    cp -L -- "$library" "$APPDIR/usr/lib/uppy/lib/$name"
done < <(ldd "$BUILD_DIR/bin/uppy-gui" | awk '/=> \/[^ ]+/ {print $3}' | sort -u)

APPDIR="$APPDIR" APPIMAGE="UPPY-AppDir-test" "$APPDIR/AppRun" --self-test

printf '\n[4/6] Locating appimagetool\n'
if [[ -n "${APPIMAGETOOL:-}" ]]; then
    TOOL="$APPIMAGETOOL"
elif command -v appimagetool >/dev/null 2>&1; then
    TOOL="$(command -v appimagetool)"
else
    TOOL="$BUILD_DIR/tools/$TOOL_ASSET"
    if [[ ! -x "$TOOL" ]]; then
        [[ "${NO_DOWNLOAD:-0}" != "1" ]] || {
            printf '[ERROR] appimagetool is unavailable and NO_DOWNLOAD=1.\n' >&2
            exit 1
        }
        install -d "$(dirname -- "$TOOL")"
        TOOL_URL="https://github.com/AppImage/AppImageKit/releases/download/continuous/$TOOL_ASSET"
        if command -v curl >/dev/null 2>&1; then
            curl --fail --location --show-error "$TOOL_URL" --output "$TOOL"
        elif command -v wget >/dev/null 2>&1; then
            wget --output-document="$TOOL" "$TOOL_URL"
        else
            printf '[ERROR] curl or wget is required to download appimagetool.\n' >&2
            exit 1
        fi
        chmod 0755 "$TOOL"
    fi
fi
[[ -x "$TOOL" ]] || { printf '[ERROR] appimagetool is not executable: %s\n' "$TOOL" >&2; exit 1; }

printf '\n[5/6] Building AppImage\n'
OUTPUT="$OUTPUT_DIR/UPPY-$VERSION-$APPIMAGE_ARCH.AppImage"
TOOL_ARGS=()
if [[ ! -e /dev/fuse ]] || ! command -v fusermount >/dev/null 2>&1; then
    TOOL_ARGS+=(--appimage-extract-and-run)
fi
ARCH="$APPIMAGE_ARCH" "$TOOL" "${TOOL_ARGS[@]}" "$APPDIR" "$OUTPUT"
chmod 0755 "$OUTPUT"

printf '\n[6/6] Verifying AppImage and size limit\n'
APPIMAGE_EXTRACT_AND_RUN=1 "$OUTPUT" --self-test
actual_size="$(stat -c '%s' "$OUTPUT")"
if (( actual_size >= MAX_APPIMAGE_BYTES )); then
    printf '[ERROR] AppImage is %s bytes; limit is strictly below %s bytes.\n' \
        "$actual_size" "$MAX_APPIMAGE_BYTES" >&2
    exit 1
fi

printf '\nBuild complete:\n  %s\n' "$OUTPUT"
printf 'Size: %s bytes (limit: less than %s bytes)\n' "$actual_size" "$MAX_APPIMAGE_BYTES"
sha256sum "$OUTPUT"

# Changelog

## 5.0.0 source revision 2

- Added automatic build-dependency detection and optional installation.
- Added clear Arch/CachyOS, Fedora/Nobara, and Debian/Ubuntu install plans.
- Added `--check-deps`, `--install-deps`, `--yes`, and `--no-install-deps`
  controls to the AppImage builder.
- Made `run-from-source.sh` repair a missing compiler/dependency set instead of
  stopping at an unexplained `cc` error.
- Added compiler/linker probing and dependency-flow regression tests.

## 5.0.0 — 2026-07-21

- Replaced PySide6, Python and PyInstaller with a native C/Cairo interface.
- Added a strict AppImage limit below 25,000,000 bytes.
- Bundled the small X11/Cairo runtime-library closure for portability.
- Preserved Overview, Setup, Apps, Output and About pages.
- Added headless rendering so every page can be visually checked during builds.
- Added secure root-side cancellation for authenticated operations, including
  protection against orphaning the root process when `pkexec` is cancelled.
- Added clipboard paste to the name-only list editor.
- Added atomic settings writes, malformed-file protection and 1 MB config cap.
- Added 2 MB caps and rotation for GUI output/logs.
- Replaced obsolete Nobara updater invocation with `nobara-sync cli`.
- Rejected immutable Fedora variants that do not support direct host `dnf` use.
- Made dry-runs avoid backend log creation.
- Removed automatic script installation and script self-update code.
- Made Flatpak update/cleanup failures visible instead of silently succeeding.
- Added collision-resistant backup directories.
- Added strict unit, distro, privilege, rendering, AppDir and AppImage tests.
- Locked package removal until a successful preview of the exact current
  selection, with list-change and 10-minute expiry protection.
- Retained complete removal of NFS, CIFS/SMB and iSCSI features.

#define _POSIX_C_SOURCE 200809L

#include "uppy_core.h"
#include "x11_cairo_compat.h"

#include <errno.h>
#include <fcntl.h>
#include <math.h>
#include <poll.h>
#include <signal.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/utsname.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#ifndef PATH_MAX
#define PATH_MAX 4096
#endif

#define PI 3.14159265358979323846
#define MIN_WIDTH 940
#define MIN_HEIGHT 660
#define OUTPUT_LIMIT (2U * 1024U * 1024U)
#define EDITOR_LIMIT (128U * 1024U)
#define MAX_HITS 128

enum {
    HIT_NAV_OVERVIEW = 10, HIT_NAV_SETUP, HIT_NAV_APPS,
    HIT_NAV_OUTPUT, HIT_NAV_ABOUT,
    HIT_UPDATE_MAINTENANCE = 100, HIT_UPDATE_REBOOT,
    HIT_UPDATE_PREVIEW, HIT_UPDATE_RUN, HIT_CHECK, HIT_LIST,
    HIT_BACKUP, HIT_CLEAN_PREVIEW, HIT_CLEAN_RUN,
    HIT_SETUP_CORE = 200, HIT_SETUP_WORKSTATION, HIT_SETUP_GAMING,
    HIT_SETUP_ADDITIONAL, HIT_SETUP_REMOVE, HIT_SETUP_ALL,
    HIT_SETUP_CLEAR, HIT_SETUP_PREVIEW, HIT_SETUP_RUN,
    HIT_APPS_SYSTEM = 300, HIT_APPS_FLATPAK, HIT_APPS_SNAP,
    HIT_APPS_REMOVE, HIT_APPS_EDITOR, HIT_APPS_SAVE, HIT_APPS_DISCARD,
    HIT_APPS_INSTALL_PREVIEW, HIT_APPS_INSTALL_RUN,
    HIT_APPS_REMOVE_PREVIEW, HIT_APPS_REMOVE_RUN,
    HIT_OUTPUT_CANCEL = 400, HIT_OUTPUT_SAVE, HIT_OUTPUT_CLEAR,
    HIT_ABOUT_SETTINGS = 500,
    HIT_MODAL_REVIEW = 900, HIT_MODAL_CANCEL, HIT_MODAL_CONFIRM,
    HIT_MODAL_OK, HIT_MODAL_DISCARD, HIT_MODAL_CANCEL_TASK
};

typedef enum { PAGE_OVERVIEW, PAGE_SETUP, PAGE_APPS, PAGE_OUTPUT, PAGE_ABOUT } Page;
typedef enum {
    MODAL_NONE, MODAL_MESSAGE, MODAL_CONFIRM, MODAL_CLOSE_DIRTY,
    MODAL_CANCEL_RUNNING
} Modal;
typedef enum { STATUS_READY, STATUS_RUNNING, STATUS_DONE, STATUS_FAILED } Status;

typedef struct { double x, y, width, height; } Rect;
typedef struct { int id; Rect rect; bool enabled; } Hit;

typedef struct {
    char *data;
    size_t length;
    size_t capacity;
    size_t cursor;
    int scroll;
} TextBuffer;

typedef struct {
    pid_t pid;
    int output_fd;
    bool running;
    bool privileged;
    bool cancel_requested;
    bool cancel_warning_shown;
    time_t cancel_time;
    uint64_t removal_preview_signature;
    char cancel_path[PATH_MAX];
    char label[96];
} BackendProcess;

typedef struct {
    Display *display;
    int screen;
    Window window;
    Pixmap back_buffer;
    GC copy_gc;
    cairo_surface_t *surface;
    cairo_t *cr;
    int width;
    int height;
    Atom wm_delete;
    Atom clipboard;
    Atom utf8_string;
    Atom paste_property;
    bool redraw;
    bool running;

    Page page;
    Status status;
    char status_text[160];
    Hit hits[MAX_HITS];
    size_t hit_count;

    UppyConfig config;
    TextBuffer editors[4];
    int active_editor;
    bool editor_focused;
    bool dirty;
    char config_path[PATH_MAX];
    char backend_path[PATH_MAX];
    char helper_path[PATH_MAX];

    bool update_maintenance;
    bool update_reboot;
    UppySetupSelection setup;

    char *output;
    size_t output_length;
    size_t output_capacity;
    int output_scroll;
    BackendProcess process;
    uint64_t valid_removal_preview;
    time_t valid_removal_preview_time;

    Modal modal;
    char modal_title[128];
    char modal_message[1024];
    char modal_danger[512];
    bool modal_reviewed;
    UppyArgs pending_args;
    bool pending_privileged;
    uint64_t pending_removal_preview;
    char pending_label[96];
} App;

static void app_show_message(App *app, const char *title, const char *message);
static void app_append_output(App *app, const char *text);
static void app_request_close(App *app);

static void copy_text(char *destination, size_t destination_size,
                      const char *source) {
    size_t length;
    if (destination_size == 0) return;
    length = strlen(source);
    if (length >= destination_size) length = destination_size - 1;
    memcpy(destination, source, length);
    destination[length] = '\0';
}

static void text_init(TextBuffer *buffer) { memset(buffer, 0, sizeof(*buffer)); }

static void text_clear(TextBuffer *buffer) {
    free(buffer->data);
    memset(buffer, 0, sizeof(*buffer));
}

static bool text_reserve(TextBuffer *buffer, size_t needed) {
    char *resized;
    size_t capacity = buffer->capacity == 0 ? 256 : buffer->capacity;
    if (needed > EDITOR_LIMIT) return false;
    while (capacity < needed) capacity *= 2;
    resized = realloc(buffer->data, capacity);
    if (resized == NULL) return false;
    buffer->data = resized;
    buffer->capacity = capacity;
    return true;
}

static bool text_set(TextBuffer *buffer, const char *value) {
    size_t length = strlen(value);
    if (!text_reserve(buffer, length + 1)) return false;
    memcpy(buffer->data, value, length + 1);
    buffer->length = length;
    buffer->cursor = length;
    buffer->scroll = 0;
    return true;
}

static bool text_insert(TextBuffer *buffer, const char *value, size_t length) {
    if (length == 0) return true;
    if (!text_reserve(buffer, buffer->length + length + 1)) return false;
    memmove(buffer->data + buffer->cursor + length,
            buffer->data + buffer->cursor,
            buffer->length - buffer->cursor + 1);
    memcpy(buffer->data + buffer->cursor, value, length);
    buffer->cursor += length;
    buffer->length += length;
    return true;
}

static void text_backspace(TextBuffer *buffer) {
    if (buffer->cursor == 0) return;
    memmove(buffer->data + buffer->cursor - 1, buffer->data + buffer->cursor,
            buffer->length - buffer->cursor + 1);
    --buffer->cursor;
    --buffer->length;
}

static void text_delete(TextBuffer *buffer) {
    if (buffer->cursor >= buffer->length) return;
    memmove(buffer->data + buffer->cursor, buffer->data + buffer->cursor + 1,
            buffer->length - buffer->cursor);
    --buffer->length;
}

static size_t text_line_start(const TextBuffer *buffer, size_t position) {
    while (position > 0 && buffer->data[position - 1] != '\n') --position;
    return position;
}

static size_t text_line_end(const TextBuffer *buffer, size_t position) {
    while (position < buffer->length && buffer->data[position] != '\n') ++position;
    return position;
}

static void text_vertical(TextBuffer *buffer, int direction) {
    size_t start = text_line_start(buffer, buffer->cursor);
    size_t column = buffer->cursor - start;
    size_t target_start;
    size_t target_end;
    if (direction < 0) {
        if (start == 0) return;
        target_end = start - 1;
        target_start = text_line_start(buffer, target_end);
    } else {
        size_t end = text_line_end(buffer, buffer->cursor);
        if (end >= buffer->length) return;
        target_start = end + 1;
        target_end = text_line_end(buffer, target_start);
    }
    buffer->cursor = target_start +
        (column < target_end - target_start ? column : target_end - target_start);
}

static int text_line_for_position(const TextBuffer *buffer, size_t position) {
    int line = 0;
    size_t index;
    for (index = 0; index < position && index < buffer->length; ++index) {
        if (buffer->data[index] == '\n') ++line;
    }
    return line;
}

static int text_line_count(const TextBuffer *buffer) {
    return text_line_for_position(buffer, buffer->length) + 1;
}

static size_t text_position_for_line_column(const TextBuffer *buffer,
                                            int wanted_line, int wanted_column) {
    int line = 0;
    int column = 0;
    size_t index;
    if (wanted_line < 0) return 0;
    for (index = 0; index < buffer->length; ++index) {
        if (line == wanted_line && column >= wanted_column) return index;
        if (buffer->data[index] == '\n') { ++line; column = 0; }
        else if (line == wanted_line) ++column;
        if (line > wanted_line) return index;
    }
    return buffer->length;
}

static void ensure_editor_cursor_visible(TextBuffer *buffer, int visible_lines) {
    int line = text_line_for_position(buffer, buffer->cursor);
    if (line < buffer->scroll) buffer->scroll = line;
    if (line >= buffer->scroll + visible_lines) buffer->scroll = line - visible_lines + 1;
    if (buffer->scroll < 0) buffer->scroll = 0;
}

static void set_color(cairo_t *cr, unsigned int color) {
    cairo_set_source_rgb(cr, ((color >> 16) & 255) / 255.0,
                         ((color >> 8) & 255) / 255.0,
                         (color & 255) / 255.0);
}

static void rounded_path(cairo_t *cr, Rect rect, double radius) {
    double right = rect.x + rect.width;
    double bottom = rect.y + rect.height;
    cairo_move_to(cr, rect.x + radius, rect.y);
    cairo_line_to(cr, right - radius, rect.y);
    cairo_arc(cr, right - radius, rect.y + radius, radius, -PI / 2, 0);
    cairo_line_to(cr, right, bottom - radius);
    cairo_arc(cr, right - radius, bottom - radius, radius, 0, PI / 2);
    cairo_line_to(cr, rect.x + radius, bottom);
    cairo_arc(cr, rect.x + radius, bottom - radius, radius, PI / 2, PI);
    cairo_line_to(cr, rect.x, rect.y + radius);
    cairo_arc(cr, rect.x + radius, rect.y + radius, radius, PI, PI * 1.5);
    cairo_close_path(cr);
}

static void fill_round(cairo_t *cr, Rect rect, double radius, unsigned int color) {
    rounded_path(cr, rect, radius);
    set_color(cr, color);
    cairo_fill(cr);
}

static void stroke_round(cairo_t *cr, Rect rect, double radius,
                         unsigned int color, double width) {
    rounded_path(cr, rect, radius);
    set_color(cr, color);
    cairo_set_line_width(cr, width);
    cairo_stroke(cr);
}

static void font(cairo_t *cr, double size, bool bold, bool mono) {
    cairo_select_font_face(cr, mono ? "DejaVu Sans Mono" : "DejaVu Sans",
                           UPPY_CAIRO_FONT_SLANT_NORMAL,
                           bold ? UPPY_CAIRO_FONT_WEIGHT_BOLD :
                                  UPPY_CAIRO_FONT_WEIGHT_NORMAL);
    cairo_set_font_size(cr, size);
}

static void draw_text(cairo_t *cr, double x, double y, const char *value,
                      double size, bool bold, unsigned int color) {
    font(cr, size, bold, false);
    set_color(cr, color);
    cairo_move_to(cr, x, y);
    cairo_show_text(cr, value);
}

static void draw_mono(cairo_t *cr, double x, double y, const char *value,
                      double size, unsigned int color) {
    font(cr, size, false, true);
    set_color(cr, color);
    cairo_move_to(cr, x, y);
    cairo_show_text(cr, value);
}

static void draw_text_ellipsis(cairo_t *cr, double x, double y, double max_width,
                               const char *value, double size, bool bold,
                               unsigned int color) {
    char original[512];
    char buffer[512];
    cairo_text_extents_t extents;
    size_t cut;
    copy_text(original, sizeof(original), value);
    copy_text(buffer, sizeof(buffer), original);
    font(cr, size, bold, false);
    cairo_text_extents(cr, buffer, &extents);
    cut = strlen(original);
    while (extents.x_advance > max_width && cut > 4) {
        --cut;
        while (cut > 0 && ((unsigned char)original[cut] & 0xc0) == 0x80) {
            --cut;
        }
        if (cut > sizeof(buffer) - 4) cut = sizeof(buffer) - 4;
        memcpy(buffer, original, cut);
        memcpy(buffer + cut, "...", 4);
        cairo_text_extents(cr, buffer, &extents);
    }
    set_color(cr, color);
    cairo_move_to(cr, x, y);
    cairo_show_text(cr, buffer);
}

static int wrap_text(cairo_t *cr, double x, double y, double width,
                     const char *value, double size, unsigned int color,
                     int max_lines) {
    char copy[2048];
    char line[1024] = "";
    char *save = NULL;
    char *word;
    int lines = 0;
    font(cr, size, false, false);
    set_color(cr, color);
    copy_text(copy, sizeof(copy), value);
    word = strtok_r(copy, " \n", &save);
    while (word != NULL && lines < max_lines) {
        char candidate[1024];
        cairo_text_extents_t extents;
        size_t used = strnlen(line, sizeof(candidate) - 1);
        size_t available;
        size_t word_length;
        memcpy(candidate, line, used);
        if (used > 0 && used < sizeof(candidate) - 1) {
            candidate[used++] = ' ';
        }
        available = sizeof(candidate) - used - 1;
        word_length = strnlen(word, available);
        memcpy(candidate + used, word, word_length);
        candidate[used + word_length] = '\0';
        cairo_text_extents(cr, candidate, &extents);
        if (line[0] && extents.x_advance > width) {
            cairo_move_to(cr, x, y + lines * (size + 5));
            cairo_show_text(cr, line);
            ++lines;
            copy_text(line, sizeof(line), word);
        } else {
            copy_text(line, sizeof(line), candidate);
        }
        word = strtok_r(NULL, " \n", &save);
    }
    if (line[0] && lines < max_lines) {
        cairo_move_to(cr, x, y + lines * (size + 5));
        cairo_show_text(cr, line);
        ++lines;
    }
    return lines;
}

static void add_hit(App *app, int id, Rect rect, bool enabled) {
    if (app->hit_count >= MAX_HITS) return;
    app->hits[app->hit_count++] = (Hit){id, rect, enabled};
}

static bool point_in(Rect rect, int x, int y) {
    return x >= rect.x && y >= rect.y &&
           x < rect.x + rect.width && y < rect.y + rect.height;
}

static int hit_at(App *app, int x, int y) {
    size_t index = app->hit_count;
    while (index > 0) {
        --index;
        if (app->hits[index].enabled && point_in(app->hits[index].rect, x, y))
            return app->hits[index].id;
    }
    return 0;
}

typedef enum { BUTTON_NORMAL, BUTTON_PRIMARY, BUTTON_DANGER, BUTTON_GHOST } ButtonStyle;

static void button(App *app, int id, Rect rect, const char *label,
                   ButtonStyle style, bool enabled) {
    unsigned int background = 0x202d40;
    unsigned int border = 0x34465f;
    unsigned int text = 0xeaf0f8;
    cairo_text_extents_t extents;
    if (style == BUTTON_PRIMARY) { background = 0x1e66f5; border = 0x4080ff; }
    if (style == BUTTON_DANGER) { background = 0x772c3d; border = 0xa14358; }
    if (style == BUTTON_GHOST) { background = 0x151f2e; border = 0x27354a; }
    if (!enabled) { background = 0x17202d; border = 0x263244; text = 0x66758a; }
    fill_round(app->cr, rect, 7, background);
    stroke_round(app->cr, rect, 7, border, 1);
    font(app->cr, 13, true, false);
    cairo_text_extents(app->cr, label, &extents);
    set_color(app->cr, text);
    cairo_move_to(app->cr, rect.x + (rect.width - extents.x_advance) / 2,
                  rect.y + (rect.height + 10) / 2);
    cairo_show_text(app->cr, label);
    add_hit(app, id, rect, enabled);
}

static void checkbox(App *app, int id, double x, double y, const char *label,
                     bool checked, bool enabled) {
    Rect box = {x, y, 18, 18};
    fill_round(app->cr, box, 4, checked ? 0x1e66f5 : 0x111a27);
    stroke_round(app->cr, box, 4, checked ? 0x4c85ff : 0x40516a, 1);
    if (checked) {
        set_color(app->cr, 0xffffff);
        cairo_set_line_width(app->cr, 2.2);
        cairo_move_to(app->cr, x + 4, y + 9);
        cairo_line_to(app->cr, x + 8, y + 13);
        cairo_line_to(app->cr, x + 15, y + 5);
        cairo_stroke(app->cr);
    }
    draw_text(app->cr, x + 29, y + 14, label, 13, true,
              enabled ? 0xe7edf7 : 0x66758a);
    add_hit(app, id, (Rect){x, y - 4, 360, 28}, enabled);
}

static void card(App *app, Rect rect, const char *title) {
    fill_round(app->cr, rect, 12, 0x151f2e);
    stroke_round(app->cr, rect, 12, 0x27354a, 1);
    draw_text(app->cr, rect.x + 20, rect.y + 29, title, 16, true, 0xf5f8fc);
}

static void banner(App *app, Rect rect, const char *message, bool warning) {
    fill_round(app->cr, rect, 9, warning ? 0x352b16 : 0x152b43);
    stroke_round(app->cr, rect, 9, warning ? 0x725c20 : 0x24527b, 1);
    wrap_text(app->cr, rect.x + 16, rect.y + 22, rect.width - 32,
              message, 12, warning ? 0xffe29a : 0xc9e5ff, 3);
}

static void page_header(App *app, const char *title, const char *subtitle) {
    draw_text(app->cr, 264, 54, title, 29, true, 0xffffff);
    draw_text_ellipsis(app->cr, 264, 82, app->width - 302, subtitle,
                       14, false, 0x9eafc5);
}

static size_t config_entry_count(const UppyConfig *config) {
    return config->system.length + config->flatpak.length +
           config->snap.length + config->remove.length;
}

static uint64_t signature_text(uint64_t signature, const char *value) {
    const unsigned char *position = (const unsigned char *)value;
    while (*position != '\0') {
        signature ^= *position++;
        signature *= UINT64_C(1099511628211);
    }
    signature ^= 0xffU;
    signature *= UINT64_C(1099511628211);
    return signature;
}

static uint64_t removal_signature(const UppyConfig *config,
                                  const UppySetupSelection *selection,
                                  bool apps_page) {
    const UppyStringList *lists[] = {
        &config->system, &config->flatpak, &config->snap, &config->remove
    };
    uint64_t signature = UINT64_C(1469598103934665603);
    size_t list_index;
    size_t item_index;
    signature = signature_text(signature, apps_page ? "apps-removal" : "setup-removal");
    for (list_index = 0; list_index < 4; ++list_index) {
        for (item_index = 0; item_index < lists[list_index]->length; ++item_index)
            signature = signature_text(signature, lists[list_index]->items[item_index]);
        signature = signature_text(signature, "|");
    }
    if (selection != NULL) {
        char flags[6];
        flags[0] = selection->core ? '1' : '0';
        flags[1] = selection->workstation ? '1' : '0';
        flags[2] = selection->gaming ? '1' : '0';
        flags[3] = selection->additional_apps ? '1' : '0';
        flags[4] = selection->remove_software ? '1' : '0';
        flags[5] = '\0';
        signature = signature_text(signature, flags);
    }
    return signature == 0 ? 1 : signature;
}

static bool removal_preview_current(const App *app, uint64_t signature) {
    time_t now = time(NULL);
    return signature != 0 && signature == app->valid_removal_preview &&
           app->valid_removal_preview_time > 0 &&
           now >= app->valid_removal_preview_time &&
           now - app->valid_removal_preview_time <= 600;
}

static void draw_sidebar(App *app) {
    const char *labels[] = {"Overview", "Setup", "Apps", "Output", "About"};
    int ids[] = {HIT_NAV_OVERVIEW, HIT_NAV_SETUP, HIT_NAV_APPS,
                 HIT_NAV_OUTPUT, HIT_NAV_ABOUT};
    int index;
    Rect sidebar = {0, 0, 224, app->height};
    set_color(app->cr, 0x101b2b);
    cairo_rectangle(app->cr, sidebar.x, sidebar.y, sidebar.width, sidebar.height);
    cairo_fill(app->cr);
    set_color(app->cr, 0x27354a);
    cairo_rectangle(app->cr, 223, 0, 1, app->height);
    cairo_fill(app->cr);

    fill_round(app->cr, (Rect){20, 22, 44, 44}, 12, 0x1e66f5);
    draw_text(app->cr, 34, 55, "U", 25, true, 0xffffff);
    draw_text(app->cr, 78, 43, "UPPY", 23, true, 0xffffff);
    draw_text(app->cr, 78, 62, "Version " UPPY_VERSION, 11, false, 0x8fa1b9);

    for (index = 0; index < 5; ++index) {
        Rect item = {18, 98 + index * 50, 188, 40};
        bool selected = app->page == (Page)index;
        if (selected) fill_round(app->cr, item, 8, 0x1e66f5);
        draw_text(app->cr, item.x + 15, item.y + 26, labels[index], 14, true,
                  selected ? 0xffffff : 0xaebcd0);
        add_hit(app, ids[index], item, true);
    }

    {
        unsigned int bg = 0x1a293a, fg = 0x9fb0c6;
        const char *state = "READY";
        if (app->status == STATUS_RUNNING) { bg = 0x3b2f12; fg = 0xffd166; state = "RUNNING"; }
        if (app->status == STATUS_DONE) { bg = 0x123527; fg = 0x62d99b; state = "DONE"; }
        if (app->status == STATUS_FAILED) { bg = 0x441d26; fg = 0xff8798; state = "FAILED"; }
        fill_round(app->cr, (Rect){18, app->height - 82, 188, 31}, 7, bg);
        draw_text(app->cr, 77, app->height - 61, state, 11, true, fg);
        draw_text_ellipsis(app->cr, 20, app->height - 28, 184,
                           app->status_text, 10, false, 0x8fa1b9);
    }
}

static bool actions_enabled(const App *app) { return !app->process.running; }

static void draw_overview(App *app) {
    char os_name[256];
    char entries[64];
    struct utsname system_name;
    double content_width = app->width - 296;
    page_header(app, "System overview",
                "Update and maintain Linux with a preview-first workflow.");
    card(app, (Rect){264, 110, content_width, 118}, "This system");
    uppy_read_os_name(os_name, sizeof(os_name));
    snprintf(entries, sizeof(entries), "%zu", config_entry_count(&app->config));
    draw_text(app->cr, 284, 166, "Operating system", 12, false, 0x98a9bf);
    draw_text_ellipsis(app->cr, 430, 166, content_width - 180,
                       os_name, 13, true, 0xf5f8fc);
    draw_text(app->cr, 284, 196, "Architecture", 12, false, 0x98a9bf);
    draw_text(app->cr, 430, 196,
              uname(&system_name) == 0 ? system_name.machine : "unknown",
              13, true, 0xf5f8fc);
    draw_text(app->cr, 620, 196, "Saved custom entries", 12, false, 0x98a9bf);
    draw_text(app->cr, 780, 196, entries, 13, true, 0xf5f8fc);

    card(app, (Rect){264, 246, content_width, 181}, "Routine update");
    wrap_text(app->cr, 284, 293, content_width - 40,
              "Updates native packages and system-wide Flatpaks. Optional maintenance removes orphan packages and cleans caches.",
              12, 0x98a9bf, 2);
    checkbox(app, HIT_UPDATE_MAINTENANCE, 284, 326,
             "Include optional package and cache maintenance",
             app->update_maintenance, actions_enabled(app) && !app->update_reboot);
    checkbox(app, HIT_UPDATE_REBOOT, 284, 359,
             "Reboot after the update", app->update_reboot, actions_enabled(app));
    button(app, HIT_UPDATE_PREVIEW,
           (Rect){app->width - 438, 375, 140, 36}, "Preview update",
           BUTTON_NORMAL, actions_enabled(app));
    button(app, HIT_UPDATE_RUN,
           (Rect){app->width - 284, 375, 128, 36}, "Run update",
           BUTTON_PRIMARY, actions_enabled(app));

    card(app, (Rect){264, 445, content_width, 162}, "Maintenance tools");
    draw_text(app->cr, 284, 494,
              "Reports run without administrator access. Cleanup authenticates only when applied.",
              12, false, 0x98a9bf);
    {
        double width = (content_width - 56) / 5;
        int ids[] = {HIT_CHECK, HIT_LIST, HIT_BACKUP, HIT_CLEAN_PREVIEW, HIT_CLEAN_RUN};
        const char *labels[] = {"System check", "Managed apps", "Create backup",
                                "Preview cleanup", "Run cleanup"};
        int index;
        for (index = 0; index < 5; ++index) {
            button(app, ids[index],
                   (Rect){284 + index * (width + 4), 530, width, 42}, labels[index],
                   index == 4 ? BUTTON_DANGER : BUTTON_NORMAL,
                   actions_enabled(app));
        }
    }
}

static bool *setup_flag(App *app, int index) {
    switch (index) {
        case 0: return &app->setup.core;
        case 1: return &app->setup.workstation;
        case 2: return &app->setup.gaming;
        case 3: return &app->setup.additional_apps;
        default: return &app->setup.remove_software;
    }
}

static void choice_card(App *app, int id, Rect rect, const char *title,
                        const char *description, bool checked) {
    fill_round(app->cr, rect, 9, 0x111a27);
    stroke_round(app->cr, rect, 9, checked ? 0x3f74d8 : 0x26364b, 1);
    checkbox(app, id, rect.x + 15, rect.y + 13, title, checked, actions_enabled(app));
    wrap_text(app->cr, rect.x + 44, rect.y + 55, rect.width - 59,
              description, 11, 0x98a9bf, 2);
}

static void draw_setup(App *app) {
    double content_width = app->width - 296;
    double half = (content_width - 14) / 2;
    uint64_t signature = removal_signature(&app->config, &app->setup, false);
    bool removal_ready = app->setup.remove_software && !app->dirty &&
                         removal_preview_current(app, signature);
    const char *safety_message = app->setup.remove_software ?
        (removal_ready ?
         "Removal preview verified. Run setup is unlocked for this exact selection for 10 minutes." :
         "Removal selected: complete Preview selection successfully before Run setup is unlocked.") :
        "Package removals appear in preview output and require a separate reviewed confirmation.";
    page_header(app, "System setup",
                "Choose what to install or remove, preview it, then apply it.");
    banner(app, (Rect){264, 108, content_width, 53},
           "Preview mode is read-only. Administrator access is requested once when changes start.", false);
    card(app, (Rect){264, 178, content_width, 350}, "Setup sections");
    choice_card(app, HIT_SETUP_CORE, (Rect){284, 220, half - 20, 82},
                "Core packages", "Flatpak and configured essential native tools.", app->setup.core);
    choice_card(app, HIT_SETUP_WORKSTATION,
                (Rect){284 + half, 220, half - 20, 82},
                "Workstation apps", "Configured system-wide Flatpak applications.", app->setup.workstation);
    choice_card(app, HIT_SETUP_GAMING, (Rect){284, 312, half - 20, 82},
                "Gaming apps", "Gaming Flatpaks and CachyOS gaming packages.", app->setup.gaming);
    choice_card(app, HIT_SETUP_ADDITIONAL,
                (Rect){284 + half, 312, half - 20, 82},
                "Additional apps", "Names saved on the Apps page.", app->setup.additional_apps);
    choice_card(app, HIT_SETUP_REMOVE, (Rect){284, 404, half - 20, 82},
                "Remove bloat", "Distro preset plus removal names saved in Uppy.", app->setup.remove_software);
    button(app, HIT_SETUP_ALL, (Rect){284 + half, 414, 112, 36}, "Select all",
           BUTTON_GHOST, actions_enabled(app));
    button(app, HIT_SETUP_CLEAR, (Rect){404 + half, 414, 128, 36}, "Clear selection",
           BUTTON_GHOST, actions_enabled(app));
    banner(app, (Rect){264, 546, content_width, 55},
           safety_message, true);
    button(app, HIT_SETUP_PREVIEW,
           (Rect){app->width - 466, 620, 170, 40}, "Preview selection",
           BUTTON_NORMAL, actions_enabled(app));
    button(app, HIT_SETUP_RUN,
           (Rect){app->width - 282, 620, 126, 40}, "Run setup",
           BUTTON_PRIMARY, actions_enabled(app) &&
           (!app->setup.remove_software || removal_ready));
}

static const char *editor_label(int index) {
    static const char *labels[] = {"System packages", "Flatpak IDs", "Snap names", "Remove bloat"};
    return labels[index];
}

static void draw_editor(App *app, Rect rect) {
    TextBuffer *buffer = &app->editors[app->active_editor];
    size_t line_start = 0;
    int line_number = 0;
    int visible = (int)((rect.height - 24) / 20);
    int drawn = 0;
    fill_round(app->cr, rect, 8, 0x0d1623);
    stroke_round(app->cr, rect, 8,
                 app->editor_focused ? 0x4c85ff : 0x304158, 1);
    cairo_save(app->cr);
    rounded_path(app->cr, (Rect){rect.x + 1, rect.y + 1, rect.width - 2, rect.height - 2}, 7);
    cairo_clip(app->cr);
    while (line_start <= buffer->length && drawn < visible) {
        size_t line_end = line_start;
        char line[1024];
        size_t length;
        while (line_end < buffer->length && buffer->data[line_end] != '\n') ++line_end;
        if (line_number >= buffer->scroll) {
            length = line_end - line_start;
            if (length >= sizeof(line)) length = sizeof(line) - 1;
            memcpy(line, buffer->data + line_start, length);
            line[length] = '\0';
            draw_mono(app->cr, rect.x + 14, rect.y + 23 + drawn * 20,
                      line, 13, 0xc9d7e8);
            if (app->editor_focused && buffer->cursor >= line_start &&
                buffer->cursor <= line_end) {
                char before[1024];
                cairo_text_extents_t extents;
                size_t before_length = buffer->cursor - line_start;
                if (before_length >= sizeof(before)) before_length = sizeof(before) - 1;
                memcpy(before, buffer->data + line_start, before_length);
                before[before_length] = '\0';
                font(app->cr, 13, false, true);
                cairo_text_extents(app->cr, before, &extents);
                set_color(app->cr, 0x70a3ff);
                cairo_rectangle(app->cr, rect.x + 14 + extents.x_advance,
                                rect.y + 8 + drawn * 20, 1.5, 18);
                cairo_fill(app->cr);
            }
            ++drawn;
        }
        if (line_end >= buffer->length) break;
        line_start = line_end + 1;
        ++line_number;
    }
    if (buffer->length == 0) {
        draw_mono(app->cr, rect.x + 14, rect.y + 23,
                  "one exact name per line", 13, 0x607089);
    }
    cairo_restore(app->cr);
    add_hit(app, HIT_APPS_EDITOR, rect, actions_enabled(app));
}

static void draw_apps(App *app) {
    const char *tabs[] = {"System", "Flatpak", "Snap", "Remove"};
    int ids[] = {HIT_APPS_SYSTEM, HIT_APPS_FLATPAK, HIT_APPS_SNAP, HIT_APPS_REMOVE};
    double content_width = app->width - 296;
    double tab_width = (content_width - 6) / 4;
    char status[160];
    uint64_t signature = removal_signature(&app->config, NULL, true);
    bool removal_ready = !app->dirty && removal_preview_current(app, signature);
    int index;
    page_header(app, "Apps and bloat removal",
                "Keep simple, name-only lists for extra installations and removals.");
    banner(app, (Rect){264, 108, content_width, 57},
           removal_ready ?
           "Removal preview verified. Remove bloat is unlocked for these exact saved lists for 10 minutes." :
           "Saving changes nothing by itself. Remove bloat unlocks only after Preview removals succeeds for the current lists.",
           false);
    for (index = 0; index < 4; ++index) {
        Rect tab = {264 + index * (tab_width + 2), 184, tab_width, 39};
        button(app, ids[index], tab, tabs[index],
               app->active_editor == index ? BUTTON_PRIMARY : BUTTON_GHOST,
               actions_enabled(app));
    }
    card(app, (Rect){264, 241, content_width, 292}, editor_label(app->active_editor));
    draw_text(app->cr, 284, 286,
              "One exact package name or application ID per line. No descriptions.",
              12, false, 0x98a9bf);
    draw_editor(app, (Rect){284, 303, content_width - 40, 208});
    snprintf(status, sizeof(status), "%zu saved custom entries%s",
             config_entry_count(&app->config), app->dirty ? " • unsaved edits" : "");
    draw_text(app->cr, 264, 558, status, 12, true,
              app->dirty ? 0xffd166 : 0x70d6a3);
    button(app, HIT_APPS_SAVE, (Rect){app->width - 426, 540, 118, 37}, "Save lists",
           BUTTON_PRIMARY, actions_enabled(app) && app->dirty);
    button(app, HIT_APPS_DISCARD, (Rect){app->width - 296, 540, 140, 37}, "Discard edits",
           BUTTON_NORMAL, actions_enabled(app) && app->dirty);
    button(app, HIT_APPS_INSTALL_PREVIEW, (Rect){264, 603, 146, 40}, "Preview installs",
           BUTTON_NORMAL, actions_enabled(app));
    button(app, HIT_APPS_INSTALL_RUN, (Rect){422, 603, 126, 40}, "Install apps",
           BUTTON_PRIMARY, actions_enabled(app));
    button(app, HIT_APPS_REMOVE_PREVIEW,
           (Rect){app->width - 454, 603, 154, 40}, "Preview removals",
           BUTTON_NORMAL, actions_enabled(app));
    button(app, HIT_APPS_REMOVE_RUN, (Rect){app->width - 288, 603, 132, 40}, "Remove bloat",
           BUTTON_DANGER, actions_enabled(app) && removal_ready);
}

static int output_total_lines(const App *app) {
    int lines = 1;
    size_t index;
    for (index = 0; index < app->output_length; ++index)
        if (app->output[index] == '\n') ++lines;
    return lines;
}

static void draw_output_log(App *app, Rect rect) {
    int visible = (int)((rect.height - 24) / 18);
    int total = output_total_lines(app);
    int start_line = total - visible - app->output_scroll;
    int current = 0;
    int drawn = 0;
    size_t start = 0;
    if (start_line < 0) start_line = 0;
    fill_round(app->cr, rect, 8, 0x080d14);
    stroke_round(app->cr, rect, 8, 0x27354a, 1);
    cairo_save(app->cr);
    cairo_rectangle(app->cr, rect.x + 8, rect.y + 6, rect.width - 16, rect.height - 12);
    cairo_clip(app->cr);
    if (app->output_length == 0) {
        draw_mono(app->cr, rect.x + 12, rect.y + 21,
                  "No output yet. Start a preview, report or update.",
                  12, 0x607089);
        cairo_restore(app->cr);
        return;
    }
    while (start <= app->output_length && drawn < visible) {
        size_t end = start;
        char line[2048];
        size_t length;
        while (end < app->output_length && app->output[end] != '\n') ++end;
        if (current >= start_line) {
            length = end - start;
            if (length >= sizeof(line)) length = sizeof(line) - 1;
            memcpy(line, app->output + start, length);
            line[length] = '\0';
            draw_mono(app->cr, rect.x + 12, rect.y + 21 + drawn * 18,
                      line, 12, 0xc9d7e8);
            ++drawn;
        }
        if (end >= app->output_length) break;
        start = end + 1;
        ++current;
    }
    cairo_restore(app->cr);
}

static void draw_output(App *app) {
    double content_width = app->width - 296;
    page_header(app, "Output", "Live package-manager output and Uppy status messages.");
    fill_round(app->cr, (Rect){264, 107, content_width, 48}, 9,
               app->process.running ? 0x3b2f12 : 0x151f2e);
    draw_text_ellipsis(app->cr, 282, 137, content_width - 36,
                       app->status_text, 13, true,
                       app->process.running ? 0xffd166 : 0xaebcd0);
    draw_output_log(app, (Rect){264, 173, content_width, app->height - 252});
    button(app, HIT_OUTPUT_CANCEL, (Rect){264, app->height - 61, 126, 39},
           "Cancel task", BUTTON_DANGER, app->process.running);
    button(app, HIT_OUTPUT_SAVE, (Rect){app->width - 402, app->height - 61, 116, 39},
           "Save output", BUTTON_NORMAL, app->output_length > 0);
    button(app, HIT_OUTPUT_CLEAR, (Rect){app->width - 274, app->height - 61, 118, 39},
           "Clear output", BUTTON_NORMAL, !app->process.running && app->output_length > 0);
}

static void draw_about(App *app) {
    double content_width = app->width - 296;
    page_header(app, "About Uppy", "A compact, careful Linux system-management tool.");
    card(app, (Rect){264, 112, content_width, 180}, "UPPY " UPPY_VERSION);
    wrap_text(app->cr, 284, 161, content_width - 40,
              "Uppy updates native packages and system-wide Flatpaks, installs selected application profiles, and removes reviewed bloat targets on Arch, Fedora and Debian-based systems.",
              13, 0xc3cfdf, 4);
    draw_text(app->cr, 284, 241,
              "Native C/Cairo interface • Bash backend • MIT licence",
              12, true, 0x70a3ff);
    card(app, (Rect){264, 312, content_width, 184}, "Safety model");
    wrap_text(app->cr, 284, 360, content_width - 40,
              "Previews run without elevation. Changes use PolicyKit only after an explicit review. Package names are validated in both the interface and backend, passed as separate arguments, and never evaluated as shell code.",
              13, 0xc3cfdf, 5);
    button(app, HIT_ABOUT_SETTINGS, (Rect){284, 438, 174, 38}, "Open settings folder",
           BUTTON_NORMAL, true);
    banner(app, (Rect){264, 520, content_width, 63},
           "Uppy manages the host operating system. Read every preview before applying package removals or a reboot.", true);
}

static void draw_modal(App *app) {
    Rect panel;
    set_color(app->cr, 0x080c12);
    cairo_set_source_rgba(app->cr, 0.03, 0.05, 0.08, 0.82);
    cairo_rectangle(app->cr, 0, 0, app->width, app->height);
    cairo_fill(app->cr);
    app->hit_count = 0;
    panel.width = app->width < 760 ? app->width - 60 : 660;
    panel.height = app->modal == MODAL_CONFIRM ? 400 : 260;
    panel.x = (app->width - panel.width) / 2;
    panel.y = (app->height - panel.height) / 2;
    fill_round(app->cr, panel, 14, 0x151f2e);
    stroke_round(app->cr, panel, 14, 0x3a4c66, 1);
    draw_text(app->cr, panel.x + 25, panel.y + 42, app->modal_title,
              20, true, 0xffffff);
    wrap_text(app->cr, panel.x + 25, panel.y + 78, panel.width - 50,
              app->modal_message, 13, 0xc5d1e1,
              app->modal == MODAL_CONFIRM ? 5 : 6);

    if (app->modal == MODAL_CONFIRM) {
        if (app->modal_danger[0]) {
            banner(app, (Rect){panel.x + 25, panel.y + 156, panel.width - 50, 64},
                   app->modal_danger, true);
        }
        fill_round(app->cr, (Rect){panel.x + 25, panel.y + 234,
                   panel.width - 50, 62}, 7, 0x080d14);
        {
            char *command = uppy_display_command(&app->pending_args);
            draw_text_ellipsis(app->cr, panel.x + 38, panel.y + 271,
                               panel.width - 76,
                               command != NULL ? command : "uppy", 12, false, 0xc9d7e8);
            free(command);
        }
        checkbox(app, HIT_MODAL_REVIEW, panel.x + 27, panel.y + 316,
                 "I reviewed this operation and want to continue.",
                 app->modal_reviewed, true);
        button(app, HIT_MODAL_CANCEL,
               (Rect){panel.x + panel.width - 282, panel.y + panel.height - 59,
                      108, 38}, "Cancel", BUTTON_NORMAL, true);
        button(app, HIT_MODAL_CONFIRM,
               (Rect){panel.x + panel.width - 160, panel.y + panel.height - 59,
                      135, 38}, "Run changes", BUTTON_PRIMARY,
               app->modal_reviewed);
    } else if (app->modal == MODAL_CLOSE_DIRTY ||
               app->modal == MODAL_CANCEL_RUNNING) {
        button(app, HIT_MODAL_CANCEL,
               (Rect){panel.x + panel.width - 280, panel.y + panel.height - 58,
                      110, 38}, app->modal == MODAL_CLOSE_DIRTY ?
                      "Keep editing" : "Keep running", BUTTON_NORMAL, true);
        button(app, app->modal == MODAL_CLOSE_DIRTY ?
                    HIT_MODAL_DISCARD : HIT_MODAL_CANCEL_TASK,
               (Rect){panel.x + panel.width - 156, panel.y + panel.height - 58,
                      131, 38}, app->modal == MODAL_CLOSE_DIRTY ?
                      "Discard & close" : "Cancel task", BUTTON_DANGER, true);
    } else {
        button(app, HIT_MODAL_OK,
               (Rect){panel.x + panel.width - 126, panel.y + panel.height - 58,
                      101, 38}, "OK", BUTTON_PRIMARY, true);
    }
}

static void draw_frame(App *app) {
    app->hit_count = 0;
    set_color(app->cr, 0x0d1420);
    cairo_paint(app->cr);
    draw_sidebar(app);
    switch (app->page) {
        case PAGE_OVERVIEW: draw_overview(app); break;
        case PAGE_SETUP: draw_setup(app); break;
        case PAGE_APPS: draw_apps(app); break;
        case PAGE_OUTPUT: draw_output(app); break;
        case PAGE_ABOUT: draw_about(app); break;
    }
    if (app->modal != MODAL_NONE) draw_modal(app);
}

static void app_draw(App *app) {
    draw_frame(app);
    cairo_surface_flush(app->surface);
    XCopyArea(app->display, app->back_buffer, app->window, app->copy_gc,
              0, 0, (unsigned int)app->width, (unsigned int)app->height, 0, 0);
    XFlush(app->display);
    app->redraw = false;
}

static bool create_back_buffer(App *app, int width, int height) {
    if (app->cr != NULL) cairo_destroy(app->cr);
    if (app->surface != NULL) cairo_surface_destroy(app->surface);
    if (app->back_buffer != 0) XFreePixmap(app->display, app->back_buffer);
    app->back_buffer = XCreatePixmap(app->display, app->window,
                                     (unsigned int)width, (unsigned int)height,
                                     (unsigned int)XDefaultDepth(app->display, app->screen));
    if (app->back_buffer == 0) return false;
    app->surface = cairo_xlib_surface_create(app->display, app->back_buffer,
                                             XDefaultVisual(app->display, app->screen),
                                             width, height);
    if (app->surface == NULL) return false;
    app->cr = cairo_create(app->surface);
    if (app->cr == NULL) return false;
    app->width = width;
    app->height = height;
    return true;
}

static bool load_editors(App *app) {
    const UppyStringList *lists[] = {&app->config.system, &app->config.flatpak,
                                     &app->config.snap, &app->config.remove};
    int index;
    for (index = 0; index < 4; ++index) {
        char *joined = uppy_join_lines(lists[index]);
        bool okay = joined != NULL && text_set(&app->editors[index], joined);
        free(joined);
        if (!okay) return false;
    }
    app->dirty = false;
    return true;
}

static bool save_editors(App *app, bool announce) {
    UppyConfig temporary;
    UppyStringList *lists[4];
    char error[512] = "";
    int index;
    uppy_config_init(&temporary);
    lists[0] = &temporary.system; lists[1] = &temporary.flatpak;
    lists[2] = &temporary.snap; lists[3] = &temporary.remove;
    for (index = 0; index < 4; ++index) {
        if (!uppy_parse_lines(lists[index], app->editors[index].data != NULL ?
                              app->editors[index].data : "", editor_label(index),
                              error, sizeof(error))) {
            uppy_config_clear(&temporary);
            app_show_message(app, "Invalid app list", error);
            return false;
        }
    }
    if (!uppy_config_save(&temporary, app->config_path, error, sizeof(error))) {
        uppy_config_clear(&temporary);
        app_show_message(app, "Could not save settings", error);
        return false;
    }
    uppy_config_clear(&app->config);
    app->config = temporary;
    if (!load_editors(app)) {
        app_show_message(app, "Memory error", "The saved settings could not be reloaded into the editor.");
        return false;
    }
    snprintf(app->status_text, sizeof(app->status_text), "%zu custom entries saved",
             config_entry_count(&app->config));
    if (announce) app_show_message(app, "Lists saved", app->status_text);
    return true;
}

static bool resolve_runtime_paths(App *app) {
    const char *appdir = getenv("APPDIR");
    const char *backend = getenv("UPPY_BACKEND");
    const char *helper = getenv("UPPY_PRIVILEGED_RUNNER");
    if (backend != NULL && backend[0] == '/') {
        snprintf(app->backend_path, sizeof(app->backend_path), "%s", backend);
    } else if (appdir != NULL && appdir[0] == '/') {
        snprintf(app->backend_path, sizeof(app->backend_path),
                 "%s/usr/lib/uppy/uppy-backend.sh", appdir);
    } else return false;
    if (helper != NULL && helper[0] == '/') {
        snprintf(app->helper_path, sizeof(app->helper_path), "%s", helper);
    } else if (appdir != NULL && appdir[0] == '/') {
        snprintf(app->helper_path, sizeof(app->helper_path),
                 "%s/usr/lib/uppy/uppy-privileged", appdir);
    } else return false;
    return true;
}

static void rotate_gui_log(const char *path) {
    struct stat details;
    char old_path[PATH_MAX];
    if (stat(path, &details) != 0 || details.st_size <= (off_t)OUTPUT_LIMIT) return;
    if (snprintf(old_path, sizeof(old_path), "%s.old", path) >= (int)sizeof(old_path)) return;
    unlink(old_path);
    (void)rename(path, old_path);
}

static void append_gui_log(const char *text) {
    char path[PATH_MAX];
    char parent[PATH_MAX];
    char error[256] = "";
    char *slash;
    FILE *file;
    if (uppy_state_log_path(path, sizeof(path)) == NULL) return;
    snprintf(parent, sizeof(parent), "%s", path);
    slash = strrchr(parent, '/');
    if (slash == NULL) return;
    *slash = '\0';
    if (!uppy_mkdirs(parent, 0700, error, sizeof(error))) return;
    rotate_gui_log(path);
    file = fopen(path, "a");
    if (file == NULL) return;
    (void)fputs(text, file);
    fclose(file);
}

static void app_append_output(App *app, const char *text) {
    size_t incoming = strlen(text);
    size_t needed;
    if (incoming >= OUTPUT_LIMIT) {
        text += incoming - OUTPUT_LIMIT + 1;
        incoming = strlen(text);
    }
    needed = app->output_length + incoming + 1;
    if (needed > OUTPUT_LIMIT) {
        size_t remove = needed - OUTPUT_LIMIT;
        char *newline = memchr(app->output + remove, '\n', app->output_length - remove);
        if (newline != NULL) remove = (size_t)(newline - app->output) + 1;
        memmove(app->output, app->output + remove, app->output_length - remove);
        app->output_length -= remove;
        needed = app->output_length + incoming + 1;
    }
    if (needed > app->output_capacity) {
        size_t capacity = app->output_capacity == 0 ? 4096 : app->output_capacity;
        char *resized;
        while (capacity < needed) capacity *= 2;
        if (capacity > OUTPUT_LIMIT) capacity = OUTPUT_LIMIT;
        resized = realloc(app->output, capacity);
        if (resized == NULL) return;
        app->output = resized;
        app->output_capacity = capacity;
    }
    memcpy(app->output + app->output_length, text, incoming + 1);
    app->output_length += incoming;
    app->output_scroll = 0;
    append_gui_log(text);
    app->redraw = true;
}

static bool make_cancel_path(BackendProcess *process, char *error, size_t error_size) {
    char directory[PATH_MAX];
    const char *runtime = getenv("XDG_RUNTIME_DIR");
    struct stat details;
    unsigned int random_value = 0;
    int random_fd;
    int directory_status;
    ssize_t random_bytes;
    uid_t uid = getuid();
    if (runtime != NULL && runtime[0] == '/' && stat(runtime, &details) == 0 &&
        details.st_uid == uid) {
        snprintf(directory, sizeof(directory), "%s/uppy", runtime);
    } else {
        snprintf(directory, sizeof(directory), "/tmp/uppy-%lu", (unsigned long)uid);
    }
    directory_status = lstat(directory, &details);
    if (directory_status == 0 &&
        (!S_ISDIR(details.st_mode) || S_ISLNK(details.st_mode))) {
        snprintf(error, error_size,
                 "The cancellation path already exists but is not a real directory.");
        return false;
    }
    if (directory_status != 0 && errno != ENOENT) {
        snprintf(error, error_size, "Could not inspect the cancellation directory: %s",
                 strerror(errno));
        return false;
    }
    if (!uppy_mkdirs(directory, 0700, error, error_size) ||
        chmod(directory, 0700) != 0) {
        snprintf(error, error_size, "Could not prepare cancellation directory: %s", strerror(errno));
        return false;
    }
    if (lstat(directory, &details) != 0 || !S_ISDIR(details.st_mode) ||
        details.st_uid != uid || (details.st_mode & 0777) != 0700) {
        snprintf(error, error_size, "The cancellation directory is not private and secure.");
        return false;
    }
    random_fd = open("/dev/urandom", O_RDONLY | O_CLOEXEC);
    if (random_fd >= 0) {
        random_bytes = read(random_fd, &random_value, sizeof(random_value));
        close(random_fd);
        if (random_bytes != (ssize_t)sizeof(random_value))
            random_value = (unsigned int)time(NULL) ^ (unsigned int)getpid();
    } else random_value = (unsigned int)time(NULL) ^ (unsigned int)getpid();
    if (snprintf(process->cancel_path, sizeof(process->cancel_path),
                 "%s/cancel-%lu-%08x", directory,
                 (unsigned long)getpid(), random_value) >=
        (int)sizeof(process->cancel_path)) {
        snprintf(error, error_size, "The cancellation path is too long.");
        return false;
    }
    unlink(process->cancel_path);
    return true;
}

static bool start_backend(App *app, const UppyArgs *arguments,
                          bool privileged, const char *label,
                          uint64_t removal_preview) {
    int pipes[2] = {-1, -1};
    pid_t child;
    char pkexec[PATH_MAX];
    char error[512] = "";
    char **argv;
    size_t prefix = privileged ? 5 : 1;
    size_t index;

    if (app->process.running) {
        app_show_message(app, "Uppy is busy", "Wait for the current task to finish or cancel it first.");
        return false;
    }
    if (access(app->backend_path, X_OK) != 0) {
        snprintf(error, sizeof(error),
                 "The Uppy backend is missing or not executable:\n%.400s",
                 app->backend_path);
        app_show_message(app, "Could not start Uppy", error);
        return false;
    }
    if (privileged && (access(app->helper_path, X_OK) != 0 ||
                       !uppy_find_executable("pkexec", pkexec, sizeof(pkexec)))) {
        app_show_message(app, "Administrator access unavailable",
                         "PolicyKit's pkexec command or the Uppy privileged runner is missing. Install polkit for your distribution.");
        return false;
    }
    if (privileged && !make_cancel_path(&app->process, error, sizeof(error))) {
        app_show_message(app, "Could not prepare task", error);
        return false;
    }
    argv = calloc(prefix + arguments->length + 1, sizeof(*argv));
    if (argv == NULL || pipe(pipes) != 0) {
        free(argv);
        app_show_message(app, "Could not start Uppy", "The process pipe could not be created.");
        return false;
    }
    if (privileged) {
        argv[0] = pkexec;
        argv[1] = app->helper_path;
        argv[2] = "--cancel-file";
        argv[3] = app->process.cancel_path;
        argv[4] = "--";
    } else argv[0] = app->backend_path;
    for (index = 0; index < arguments->length; ++index)
        argv[prefix + index] = arguments->values[index];

    child = fork();
    if (child == 0) {
        (void)setpgid(0, 0);
        close(pipes[0]);
        dup2(pipes[1], STDOUT_FILENO);
        dup2(pipes[1], STDERR_FILENO);
        if (pipes[1] > STDERR_FILENO) close(pipes[1]);
        setenv("APPIMAGE", getenv("APPIMAGE") != NULL ? getenv("APPIMAGE") : "UPPY-AppImage", 1);
        setenv("LC_ALL", "C", 1);
        setenv("NO_COLOR", "1", 1);
        unsetenv("UPPY_TESTING");
        unsetenv("UPPY_OS_RELEASE_FILE");
        if (privileged) execv(pkexec, argv);
        else execv(app->backend_path, argv);
        dprintf(STDERR_FILENO, "[GUI ERROR] Could not execute Uppy: %s\n", strerror(errno));
        _exit(127);
    }
    free(argv);
    close(pipes[1]);
    if (child < 0) {
        close(pipes[0]);
        app_show_message(app, "Could not start Uppy", strerror(errno));
        return false;
    }
    (void)setpgid(child, child);
    fcntl(pipes[0], F_SETFL, fcntl(pipes[0], F_GETFL) | O_NONBLOCK);
    fcntl(pipes[0], F_SETFD, FD_CLOEXEC);
    app->process.pid = child;
    app->process.output_fd = pipes[0];
    app->process.running = true;
    app->process.privileged = privileged;
    app->process.cancel_requested = false;
    app->process.cancel_warning_shown = false;
    app->process.removal_preview_signature = removal_preview;
    snprintf(app->process.label, sizeof(app->process.label), "%s", label);
    app->status = STATUS_RUNNING;
    snprintf(app->status_text, sizeof(app->status_text), "Running: %s", label);
    app->page = PAGE_OUTPUT;
    app->editor_focused = false;
    app->redraw = true;
    if (privileged) {
        app->valid_removal_preview = 0;
        app->valid_removal_preview_time = 0;
    }
    return true;
}

static void finish_process(App *app, int status) {
    char message[256];
    int code = WIFEXITED(status) ? WEXITSTATUS(status) : 128 + WTERMSIG(status);
    if (app->process.output_fd >= 0) close(app->process.output_fd);
    app->process.output_fd = -1;
    app->process.running = false;
    unlink(app->process.cancel_path);
    app->process.cancel_path[0] = '\0';
    if (app->process.cancel_requested || code == 130 || code == 143) {
        app->status = STATUS_FAILED;
        snprintf(app->status_text, sizeof(app->status_text), "Cancelled: %s", app->process.label);
        snprintf(message, sizeof(message), "\n[GUI] Task cancelled (exit %d).\n", code);
    } else if (code == 0) {
        app->status = STATUS_DONE;
        snprintf(app->status_text, sizeof(app->status_text), "Completed: %s", app->process.label);
        snprintf(message, sizeof(message), "\n[GUI] Task completed successfully.\n");
        if (app->process.removal_preview_signature != 0) {
            app->valid_removal_preview = app->process.removal_preview_signature;
            app->valid_removal_preview_time = time(NULL);
        }
    } else {
        app->status = STATUS_FAILED;
        snprintf(app->status_text, sizeof(app->status_text), "Failed (exit %d): %s", code, app->process.label);
        snprintf(message, sizeof(message), "\n[GUI] Task failed with exit code %d.\n", code);
    }
    app_append_output(app, message);
}

static void poll_process(App *app) {
    char buffer[8192];
    ssize_t received;
    int status;
    pid_t result;
    if (!app->process.running) return;
    do {
        received = read(app->process.output_fd, buffer, sizeof(buffer) - 1);
        if (received > 0) {
            buffer[received] = '\0';
            app_append_output(app, buffer);
        }
    } while (received > 0);
    result = waitpid(app->process.pid, &status, WNOHANG);
    if (result == app->process.pid) {
        do {
            received = read(app->process.output_fd, buffer, sizeof(buffer) - 1);
            if (received > 0) { buffer[received] = '\0'; app_append_output(app, buffer); }
        } while (received > 0);
        finish_process(app, status);
    } else if (result < 0 && errno == ECHILD) {
        finish_process(app, 127 << 8);
    }
    if (app->process.running && app->process.cancel_requested) {
        time_t elapsed = time(NULL) - app->process.cancel_time;
        if (!app->process.privileged && elapsed >= 5) {
            (void)kill(-app->process.pid, SIGKILL);
        } else if (app->process.privileged && elapsed >= 10 &&
                   !app->process.cancel_warning_shown) {
            app->process.cancel_warning_shown = true;
            app_append_output(app,
                "[GUI WARN] The privileged helper has not stopped yet. Uppy will keep the cancellation token in place rather than orphan a root process.\n");
        }
    }
}

static void request_cancel(App *app) {
    int file;
    char message[512];
    if (!app->process.running || app->process.cancel_requested) return;
    if (app->process.privileged) {
        file = open(app->process.cancel_path,
                    O_CREAT | O_EXCL | O_WRONLY | O_CLOEXEC, 0600);
        if (file < 0) {
            snprintf(message, sizeof(message),
                     "The secure cancellation token could not be created:\n%s",
                     strerror(errno));
            app_show_message(app, "Could not request cancellation", message);
            return;
        }
        close(file);
    } else {
        (void)kill(-app->process.pid, SIGTERM);
    }
    app->process.cancel_requested = true;
    app->process.cancel_warning_shown = false;
    app->process.cancel_time = time(NULL);
    snprintf(app->status_text, sizeof(app->status_text), "Cancelling: %s", app->process.label);
    app_append_output(app, "\n[GUI] Cancellation requested. Waiting for the backend to stop safely.\n");
}

static void timestamp_header(App *app, const char *label, const UppyArgs *args) {
    char time_text[64];
    char header[1024];
    char *command = uppy_display_command(args);
    time_t now = time(NULL);
    struct tm local;
    localtime_r(&now, &local);
    strftime(time_text, sizeof(time_text), "%Y-%m-%d %H:%M:%S", &local);
    snprintf(header, sizeof(header),
             "\n==============================================================================\n%s — %s\n$ %s\n==============================================================================\n\n",
             time_text, label, command != NULL ? command : "uppy");
    free(command);
    app_append_output(app, header);
}

static void launch_or_confirm(App *app, UppyArgs *args, bool privileged,
                              const char *label, const char *danger,
                              uint64_t removal_preview) {
    if (!privileged) {
        timestamp_header(app, label, args);
        (void)start_backend(app, args, false, label, removal_preview);
        uppy_args_clear(args);
        return;
    }
    uppy_args_clear(&app->pending_args);
    app->pending_args = *args;
    memset(args, 0, sizeof(*args));
    app->pending_privileged = true;
    app->pending_removal_preview = removal_preview;
    snprintf(app->pending_label, sizeof(app->pending_label), "%s", label);
    snprintf(app->modal_title, sizeof(app->modal_title), "%s", label);
    snprintf(app->modal_message, sizeof(app->modal_message),
             "Uppy will request administrator authentication and run the selected operation.");
    snprintf(app->modal_danger, sizeof(app->modal_danger), "%s", danger != NULL ? danger : "");
    app->modal_reviewed = false;
    app->modal = MODAL_CONFIRM;
    app->redraw = true;
}

static void app_show_message(App *app, const char *title, const char *message) {
    copy_text(app->modal_title, sizeof(app->modal_title), title);
    copy_text(app->modal_message, sizeof(app->modal_message), message);
    app->modal_danger[0] = '\0';
    app->modal = MODAL_MESSAGE;
    app->redraw = true;
}

static void run_update(App *app, bool preview) {
    UppyArgs args;
    char error[256] = "";
    uppy_args_init(&args);
    if (!uppy_build_update_args(&args, app->update_maintenance,
                                app->update_reboot, preview, error, sizeof(error))) {
        app_show_message(app, "Could not prepare update", error);
        return;
    }
    launch_or_confirm(app, &args, !preview, preview ? "Update preview" : "System update",
                      app->update_reboot ? "The computer will reboot when the update finishes." : "", 0);
}

static void run_simple(App *app, const char *mode, const char *label,
                       bool preview, bool privileged, const char *danger) {
    UppyArgs args;
    char error[256] = "";
    uppy_args_init(&args);
    if (!uppy_build_simple_args(&args, mode, preview, error, sizeof(error))) {
        app_show_message(app, "Could not prepare task", error);
        return;
    }
    launch_or_confirm(app, &args, privileged, label, danger, 0);
}

static void run_setup(App *app, bool preview) {
    UppyArgs args;
    char error[512] = "";
    uint64_t signature = 0;
    if ((app->setup.additional_apps || app->setup.remove_software) &&
        !save_editors(app, false)) return;
    if (app->setup.remove_software) {
        signature = removal_signature(&app->config, &app->setup, false);
        if (!preview && !removal_preview_current(app, signature)) {
            app_show_message(app, "Preview required",
                "Run Preview selection successfully for this exact setup selection before applying package removals.");
            return;
        }
    }
    uppy_args_init(&args);
    if (!uppy_build_setup_args(&args, &app->config, app->setup, preview,
                               error, sizeof(error))) {
        app_show_message(app, "Setup selection", error);
        return;
    }
    launch_or_confirm(app, &args, !preview,
                      preview ? "Setup preview" : "System setup",
                      app->setup.remove_software ?
                      "This selection includes package removal. Its successful preview is still current." : "",
                      preview ? signature : 0);
}

static void run_apps(App *app, bool install, bool remove, bool preview) {
    UppyArgs args;
    char error[512] = "";
    uint64_t signature = 0;
    if (!save_editors(app, false)) return;
    if (remove) {
        signature = removal_signature(&app->config, NULL, true);
        if (!preview && !removal_preview_current(app, signature)) {
            app_show_message(app, "Preview required",
                "Run Preview removals successfully for these exact saved lists before removing packages.");
            return;
        }
    }
    uppy_args_init(&args);
    if (!uppy_build_apps_args(&args, &app->config, install, remove, preview,
                              error, sizeof(error))) {
        app_show_message(app, "Application lists", error);
        return;
    }
    launch_or_confirm(app, &args, !preview,
                      install ? (preview ? "Install preview" : "Install applications") :
                                (preview ? "Removal preview" : "Remove bloat"),
                      remove ? "Installed removal targets shown by the successful preview will be uninstalled." : "",
                      preview ? signature : 0);
}

static void open_settings_folder(App *app) {
    char folder[PATH_MAX];
    char executable[PATH_MAX];
    char error[256] = "";
    char *slash;
    pid_t child;
    snprintf(folder, sizeof(folder), "%s", app->config_path);
    slash = strrchr(folder, '/');
    if (slash != NULL) *slash = '\0';
    if (!uppy_mkdirs(folder, 0700, error, sizeof(error)) ||
        !uppy_find_executable("xdg-open", executable, sizeof(executable))) {
        app_show_message(app, "Settings folder", folder);
        return;
    }
    child = fork();
    if (child == 0) {
        pid_t grandchild = fork();
        if (grandchild == 0) {
            int null_fd = open("/dev/null", O_RDWR);
            (void)setsid();
            if (null_fd >= 0) {
                dup2(null_fd, STDOUT_FILENO);
                dup2(null_fd, STDERR_FILENO);
                if (null_fd > STDERR_FILENO) close(null_fd);
            }
            execl(executable, executable, folder, (char *)NULL);
            _exit(127);
        }
        _exit(grandchild < 0 ? 1 : 0);
    }
    if (child > 0) (void)waitpid(child, NULL, 0);
}

static void save_output(App *app) {
    const char *home = getenv("HOME");
    char directory[PATH_MAX];
    char path[PATH_MAX];
    char filename[64];
    char message[PATH_MAX + 64];
    char error[256] = "";
    time_t now = time(NULL);
    struct tm local;
    FILE *file;
    int suffix = 0;
    if (home == NULL || home[0] != '/') {
        app_show_message(app, "Could not save output", "HOME is not set to an absolute path.");
        return;
    }
    snprintf(directory, sizeof(directory), "%s/Downloads", home);
    if (access(directory, W_OK) != 0) snprintf(directory, sizeof(directory), "%s", home);
    if (!uppy_mkdirs(directory, 0700, error, sizeof(error))) {
        app_show_message(app, "Could not save output", error);
        return;
    }
    localtime_r(&now, &local);
    strftime(filename, sizeof(filename), "uppy-output-%Y%m%d-%H%M%S", &local);
    file = NULL;
    while (suffix < 100 && file == NULL) {
        int written = suffix == 0 ?
            snprintf(path, sizeof(path), "%s/%s.txt", directory, filename) :
            snprintf(path, sizeof(path), "%s/%s-%d.txt", directory, filename, suffix);
        if (written < 0 || written >= (int)sizeof(path)) {
            app_show_message(app, "Could not save output", "The output path is too long.");
            return;
        }
        file = fopen(path, "wx");
        if (file == NULL && errno != EEXIST) break;
        ++suffix;
    }
    if (file == NULL) {
        app_show_message(app, "Could not save output", strerror(errno));
        return;
    }
    if (fwrite(app->output, 1, app->output_length, file) != app->output_length ||
        fflush(file) != 0 || fsync(fileno(file)) != 0) {
        int saved_errno = errno;
        fclose(file);
        unlink(path);
        app_show_message(app, "Could not save output", strerror(saved_errno));
        return;
    }
    if (fclose(file) != 0) {
        int saved_errno = errno;
        unlink(path);
        app_show_message(app, "Could not save output", strerror(saved_errno));
        return;
    }
    snprintf(message, sizeof(message), "Output saved to:\n%s", path);
    app_show_message(app, "Output saved", message);
}

static void dispatch_hit(App *app, int id, int mouse_x, int mouse_y) {
    int index;
    if (app->modal != MODAL_NONE) {
        if (id == HIT_MODAL_REVIEW) app->modal_reviewed = !app->modal_reviewed;
        else if (id == HIT_MODAL_CANCEL || id == HIT_MODAL_OK) {
            app->modal = MODAL_NONE;
            uppy_args_clear(&app->pending_args);
            app->pending_removal_preview = 0;
        } else if (id == HIT_MODAL_CONFIRM && app->modal_reviewed) {
            UppyArgs args = app->pending_args;
            memset(&app->pending_args, 0, sizeof(app->pending_args));
            app->modal = MODAL_NONE;
            timestamp_header(app, app->pending_label, &args);
            (void)start_backend(app, &args, app->pending_privileged,
                                app->pending_label,
                                app->pending_removal_preview);
            app->pending_removal_preview = 0;
            uppy_args_clear(&args);
        } else if (id == HIT_MODAL_DISCARD) {
            app->running = false;
        } else if (id == HIT_MODAL_CANCEL_TASK) {
            app->modal = MODAL_NONE;
            request_cancel(app);
        }
        app->redraw = true;
        return;
    }
    if (id >= HIT_NAV_OVERVIEW && id <= HIT_NAV_ABOUT) {
        app->page = (Page)(id - HIT_NAV_OVERVIEW);
        app->editor_focused = false;
    } else switch (id) {
        case HIT_UPDATE_MAINTENANCE: app->update_maintenance = !app->update_maintenance; break;
        case HIT_UPDATE_REBOOT:
            app->update_reboot = !app->update_reboot;
            if (app->update_reboot) app->update_maintenance = false;
            break;
        case HIT_UPDATE_PREVIEW: run_update(app, true); break;
        case HIT_UPDATE_RUN: run_update(app, false); break;
        case HIT_CHECK: run_simple(app, "--check", "System check", false, false, ""); break;
        case HIT_LIST: run_simple(app, "--list-software", "Managed software", false, false, ""); break;
        case HIT_BACKUP: run_simple(app, "--backup", "Configuration backup", false, false, ""); break;
        case HIT_CLEAN_PREVIEW: run_simple(app, "--clean", "Cleanup preview", true, false, ""); break;
        case HIT_CLEAN_RUN: run_simple(app, "--clean", "System cleanup", false, true,
                                       "Unused packages, cached packages and Flatpak runtimes may be removed."); break;
        case HIT_SETUP_CORE: case HIT_SETUP_WORKSTATION: case HIT_SETUP_GAMING:
        case HIT_SETUP_ADDITIONAL: case HIT_SETUP_REMOVE:
            *setup_flag(app, id - HIT_SETUP_CORE) = !*setup_flag(app, id - HIT_SETUP_CORE); break;
        case HIT_SETUP_ALL:
            for (index = 0; index < 5; ++index) *setup_flag(app, index) = true;
            break;
        case HIT_SETUP_CLEAR: memset(&app->setup, 0, sizeof(app->setup)); break;
        case HIT_SETUP_PREVIEW: run_setup(app, true); break;
        case HIT_SETUP_RUN: run_setup(app, false); break;
        case HIT_APPS_SYSTEM: case HIT_APPS_FLATPAK: case HIT_APPS_SNAP: case HIT_APPS_REMOVE:
            app->active_editor = id - HIT_APPS_SYSTEM; app->editor_focused = false; break;
        case HIT_APPS_EDITOR: {
            Rect rect = {284, 303, app->width - 336, 208};
            TextBuffer *buffer = &app->editors[app->active_editor];
            int line = buffer->scroll + (int)((mouse_y - rect.y - 7) / 20);
            int column = (int)((mouse_x - rect.x - 14) / 8);
            if (column < 0) column = 0;
            buffer->cursor = text_position_for_line_column(buffer, line, column);
            app->editor_focused = true;
            break;
        }
        case HIT_APPS_SAVE: (void)save_editors(app, true); break;
        case HIT_APPS_DISCARD:
            if (!load_editors(app)) app_show_message(app, "Memory error", "Could not reload the saved app lists.");
            break;
        case HIT_APPS_INSTALL_PREVIEW: run_apps(app, true, false, true); break;
        case HIT_APPS_INSTALL_RUN: run_apps(app, true, false, false); break;
        case HIT_APPS_REMOVE_PREVIEW: run_apps(app, false, true, true); break;
        case HIT_APPS_REMOVE_RUN: run_apps(app, false, true, false); break;
        case HIT_OUTPUT_CANCEL:
            app->modal = MODAL_CANCEL_RUNNING;
            snprintf(app->modal_title, sizeof(app->modal_title), "Cancel running task?");
            snprintf(app->modal_message, sizeof(app->modal_message),
                     "Stopping a package manager can leave an operation unfinished. Cancel only if the task is genuinely stuck.");
            break;
        case HIT_OUTPUT_SAVE: save_output(app); break;
        case HIT_OUTPUT_CLEAR:
            app->output_length = 0;
            if (app->output != NULL) app->output[0] = '\0';
            app->output_scroll = 0;
            break;
        case HIT_ABOUT_SETTINGS: open_settings_folder(app); break;
        default: app->editor_focused = false; break;
    }
    app->redraw = true;
}

static void request_paste(App *app) {
    XConvertSelection(app->display, app->clipboard, app->utf8_string,
                      app->paste_property, app->window, UPPY_CurrentTime);
    XFlush(app->display);
}

static void handle_paste(App *app, XSelectionEvent *selection) {
    Atom actual_type;
    int actual_format;
    unsigned long count = 0, remaining = 0;
    unsigned char *data = NULL;
    if (selection->property == 0 || app->page != PAGE_APPS || !app->editor_focused) return;
    if (XGetWindowProperty(app->display, app->window, app->paste_property,
                           0, EDITOR_LIMIT / 4, 1, UPPY_AnyPropertyType,
                           &actual_type, &actual_format, &count, &remaining, &data) != 0 ||
        data == NULL || actual_format != 8) {
        if (data != NULL) XFree(data);
        return;
    }
    if (count > 0) {
        char *clean = malloc(count + 1);
        size_t source, target = 0;
        if (clean != NULL) {
            for (source = 0; source < count; ++source) {
                unsigned char character = data[source];
                if (character == '\r') {
                    if (source + 1 < count && data[source + 1] == '\n') continue;
                    character = '\n';
                }
                if (character == '\n' || character == '\t' || character >= 0x20)
                    clean[target++] = (char)character;
            }
            clean[target] = '\0';
            if (text_insert(&app->editors[app->active_editor], clean, target)) app->dirty = true;
            free(clean);
        }
    }
    XFree(data);
    app->redraw = true;
}

static void handle_key(App *app, XKeyEvent *event) {
    char text[64];
    KeySym symbol = 0;
    int count = XLookupString(event, text, sizeof(text), &symbol, NULL);
    TextBuffer *buffer;
    if (app->modal != MODAL_NONE) {
        if (symbol == UPPY_XK_Escape) {
            app->modal = MODAL_NONE;
            uppy_args_clear(&app->pending_args);
            app->pending_removal_preview = 0;
            app->redraw = true;
        }
        return;
    }
    if (app->process.running && (event->state & UPPY_ControlMask) &&
        count == 1 && (text[0] == 'c' || text[0] == 'C')) {
        request_cancel(app);
        return;
    }
    if (app->page != PAGE_APPS || !app->editor_focused || app->process.running) return;
    buffer = &app->editors[app->active_editor];
    if ((event->state & UPPY_ControlMask) && count == 1 &&
        (text[0] == 'v' || text[0] == 'V')) {
        request_paste(app);
        return;
    }
    switch (symbol) {
        case UPPY_XK_BackSpace: text_backspace(buffer); app->dirty = true; break;
        case UPPY_XK_Delete: text_delete(buffer); app->dirty = true; break;
        case UPPY_XK_Left: if (buffer->cursor > 0) --buffer->cursor; break;
        case UPPY_XK_Right: if (buffer->cursor < buffer->length) ++buffer->cursor; break;
        case UPPY_XK_Up: text_vertical(buffer, -1); break;
        case UPPY_XK_Down: text_vertical(buffer, 1); break;
        case UPPY_XK_Home: buffer->cursor = text_line_start(buffer, buffer->cursor); break;
        case UPPY_XK_End: buffer->cursor = text_line_end(buffer, buffer->cursor); break;
        case UPPY_XK_Return: if (text_insert(buffer, "\n", 1)) app->dirty = true; break;
        case UPPY_XK_Escape: app->editor_focused = false; break;
        default:
            if (count > 0 && !(event->state & UPPY_ControlMask)) {
                int index;
                for (index = 0; index < count; ++index)
                    if ((unsigned char)text[index] < 0x20) text[index] = ' ';
                if (text_insert(buffer, text, (size_t)count)) app->dirty = true;
            }
            break;
    }
    ensure_editor_cursor_visible(buffer, 9);
    app->redraw = true;
}

static void handle_wheel(App *app, int button_number, int x, int y) {
    int delta = button_number == 4 ? -3 : 3;
    if (app->page == PAGE_APPS && point_in((Rect){284, 303, app->width - 336, 208}, x, y)) {
        TextBuffer *buffer = &app->editors[app->active_editor];
        int maximum = text_line_count(buffer) - 9;
        buffer->scroll += delta;
        if (buffer->scroll < 0) buffer->scroll = 0;
        if (maximum < 0) maximum = 0;
        if (buffer->scroll > maximum) buffer->scroll = maximum;
        app->redraw = true;
    } else if (app->page == PAGE_OUTPUT) {
        int maximum = output_total_lines(app) - (app->height - 276) / 18;
        app->output_scroll -= delta;
        if (app->output_scroll < 0) app->output_scroll = 0;
        if (maximum < 0) maximum = 0;
        if (app->output_scroll > maximum) app->output_scroll = maximum;
        app->redraw = true;
    }
}

static void app_request_close(App *app) {
    if (app->process.running) {
        app_show_message(app, "A task is still running",
                         "Wait for it to finish or cancel it before closing Uppy.");
    } else if (app->dirty) {
        app->modal = MODAL_CLOSE_DIRTY;
        snprintf(app->modal_title, sizeof(app->modal_title), "Discard unsaved changes?");
        snprintf(app->modal_message, sizeof(app->modal_message),
                 "The Apps page contains edits that have not been saved.");
        app->redraw = true;
    } else app->running = false;
}

static void handle_event(App *app, XEvent *event) {
    switch (event->type) {
        case UPPY_Expose: app->redraw = true; break;
        case UPPY_ConfigureNotify:
            if (event->xconfigure.width != app->width || event->xconfigure.height != app->height) {
                int width = event->xconfigure.width < MIN_WIDTH ? MIN_WIDTH : event->xconfigure.width;
                int height = event->xconfigure.height < MIN_HEIGHT ? MIN_HEIGHT : event->xconfigure.height;
                if (width != event->xconfigure.width || height != event->xconfigure.height)
                    XResizeWindow(app->display, app->window, width, height);
                if (create_back_buffer(app, width, height)) app->redraw = true;
            }
            break;
        case UPPY_ButtonPress:
            if (event->xbutton.button == 4 || event->xbutton.button == 5) {
                handle_wheel(app, (int)event->xbutton.button, event->xbutton.x, event->xbutton.y);
            } else if (event->xbutton.button == 1) {
                int hit = hit_at(app, event->xbutton.x, event->xbutton.y);
                if (hit == HIT_OUTPUT_CANCEL && (event->xbutton.state & UPPY_ControlMask))
                    request_cancel(app);
                else dispatch_hit(app, hit, event->xbutton.x, event->xbutton.y);
            }
            break;
        case UPPY_KeyPress: handle_key(app, &event->xkey); break;
        case UPPY_SelectionNotify: handle_paste(app, &event->xselection); break;
        case UPPY_ClientMessage:
            if ((Atom)event->xclient.data.l[0] == app->wm_delete) app_request_close(app);
            break;
    }
}

static bool app_init(App *app) {
    char error[512] = "";
    int index;
    XClassHint class_hint;
    XSizeHints size_hints;
    memset(app, 0, sizeof(*app));
    app->width = 1120;
    app->height = 760;
    app->running = true;
    app->redraw = true;
    app->status = STATUS_READY;
    snprintf(app->status_text, sizeof(app->status_text), "Ready");
    app->process.output_fd = -1;
    uppy_config_init(&app->config);
    uppy_args_init(&app->pending_args);
    for (index = 0; index < 4; ++index) text_init(&app->editors[index]);
    if (uppy_config_path(app->config_path, sizeof(app->config_path)) == NULL) {
        fprintf(stderr, "UPPY: HOME or the settings path is invalid.\n");
        return false;
    }
    if (!resolve_runtime_paths(app)) {
        fprintf(stderr, "UPPY: APPDIR or explicit backend paths are required.\n");
        return false;
    }
    if (!uppy_config_load(&app->config, app->config_path, error, sizeof(error))) {
        snprintf(app->status_text, sizeof(app->status_text), "Safe defaults loaded");
        snprintf(app->modal_title, sizeof(app->modal_title), "Settings could not be loaded");
        snprintf(app->modal_message, sizeof(app->modal_message), "%s\n\nSafe empty lists are active. The existing file has not been changed.", error);
        app->modal = MODAL_MESSAGE;
    }
    if (!load_editors(app)) {
        fprintf(stderr, "UPPY: not enough memory to load the app lists.\n");
        return false;
    }
    app->display = XOpenDisplay(NULL);
    if (app->display == NULL) {
        fprintf(stderr, "UPPY: could not open the X display. Ensure X11 or XWayland is available.\n");
        return false;
    }
    app->screen = XDefaultScreen(app->display);
    app->window = XCreateSimpleWindow(app->display,
                                      XRootWindow(app->display, app->screen),
                                      0, 0, app->width, app->height, 0,
                                      XBlackPixel(app->display, app->screen),
                                      XBlackPixel(app->display, app->screen));
    if (app->window == 0) return false;
    XStoreName(app->display, app->window, "UPPY " UPPY_VERSION);
    class_hint.res_name = "uppy-gui";
    class_hint.res_class = "uppy-gui";
    XSetClassHint(app->display, app->window, &class_hint);
    memset(&size_hints, 0, sizeof(size_hints));
    size_hints.flags = UPPY_PMinSize;
    size_hints.min_width = MIN_WIDTH;
    size_hints.min_height = MIN_HEIGHT;
    XSetWMNormalHints(app->display, app->window, &size_hints);
    XSelectInput(app->display, app->window,
                 UPPY_ExposureMask | UPPY_KeyPressMask |
                 UPPY_ButtonPressMask | UPPY_StructureNotifyMask);
    app->wm_delete = XInternAtom(app->display, "WM_DELETE_WINDOW", 0);
    XSetWMProtocols(app->display, app->window, &app->wm_delete, 1);
    app->clipboard = XInternAtom(app->display, "CLIPBOARD", 0);
    app->utf8_string = XInternAtom(app->display, "UTF8_STRING", 0);
    app->paste_property = XInternAtom(app->display, "UPPY_CLIPBOARD", 0);
    app->copy_gc = XCreateGC(app->display, app->window, 0, NULL);
    if (app->copy_gc == NULL || !create_back_buffer(app, app->width, app->height)) return false;
    XMapWindow(app->display, app->window);
    return true;
}

static void app_destroy(App *app) {
    int index;
    if (app->process.running) {
        request_cancel(app);
        (void)waitpid(app->process.pid, NULL, 0);
    }
    if (app->cr != NULL) cairo_destroy(app->cr);
    if (app->surface != NULL) cairo_surface_destroy(app->surface);
    if (app->back_buffer != 0) XFreePixmap(app->display, app->back_buffer);
    if (app->copy_gc != NULL) XFreeGC(app->display, app->copy_gc);
    if (app->window != 0) XDestroyWindow(app->display, app->window);
    if (app->display != NULL) XCloseDisplay(app->display);
    for (index = 0; index < 4; ++index) text_clear(&app->editors[index]);
    uppy_config_clear(&app->config);
    uppy_args_clear(&app->pending_args);
    free(app->output);
}

static int app_loop(App *app) {
    int display_fd = XConnectionNumber(app->display);
    while (app->running) {
        struct pollfd descriptors[2];
        int count = 1;
        while (XPending(app->display) > 0) {
            XEvent event;
            XNextEvent(app->display, &event);
            handle_event(app, &event);
        }
        poll_process(app);
        if (app->redraw) app_draw(app);
        descriptors[0].fd = display_fd;
        descriptors[0].events = POLLIN;
        descriptors[0].revents = 0;
        if (app->process.running) {
            descriptors[1].fd = app->process.output_fd;
            descriptors[1].events = POLLIN | POLLHUP;
            descriptors[1].revents = 0;
            count = 2;
        }
        (void)poll(descriptors, (nfds_t)count, app->process.running ? 60 : 250);
    }
    return 0;
}

static int self_test(void) {
    UppyConfig config;
    UppyArgs args;
    App paths;
    UppySetupSelection selected = {0};
    char error[256] = "";
    int result = 1;
    uint64_t signature;
    memset(&paths, 0, sizeof(paths));
    uppy_config_init(&config);
    uppy_args_init(&args);
    if (!uppy_list_add(&config.system, "htop", error, sizeof(error)) ||
        !uppy_list_add(&config.flatpak, "org.example.App", error, sizeof(error))) goto done;
    selected.core = true;
    selected.additional_apps = true;
    if (!uppy_build_setup_args(&args, &config, selected, true, error, sizeof(error)) ||
        args.length < 6 || strcmp(args.values[0], "--core") != 0 ||
        strcmp(args.values[args.length - 1], "--dry-run") != 0) goto done;
    signature = removal_signature(&config, NULL, true);
    paths.valid_removal_preview = signature;
    paths.valid_removal_preview_time = time(NULL);
    if (!removal_preview_current(&paths, signature) ||
        !uppy_list_add(&config.remove, "example-bloat", error, sizeof(error)) ||
        removal_preview_current(&paths,
                                removal_signature(&config, NULL, true))) goto done;
    if (getenv("APPDIR") != NULL || getenv("UPPY_BACKEND") != NULL) {
        memset(&paths, 0, sizeof(paths));
        if (!resolve_runtime_paths(&paths) ||
            access(paths.backend_path, X_OK) != 0 ||
            access(paths.helper_path, X_OK) != 0) {
            fputs("UPPY self-test: backend or privileged helper is missing.\n", stderr);
            goto done;
        }
    }
    puts("UPPY " UPPY_VERSION " self-test passed");
    result = 0;
done:
    uppy_args_clear(&args);
    uppy_config_clear(&config);
    return result;
}

static int render_preview(const char *path, Page page) {
    App app;
    int index;
    int result;
    memset(&app, 0, sizeof(app));
    app.width = 1120;
    app.height = 760;
    app.page = page;
    app.status = STATUS_READY;
    snprintf(app.status_text, sizeof(app.status_text), "Ready");
    uppy_config_init(&app.config);
    uppy_args_init(&app.pending_args);
    for (index = 0; index < 4; ++index) text_init(&app.editors[index]);
    (void)text_set(&app.editors[0], "htop\nfastfetch");
    (void)text_set(&app.editors[1], "org.example.Application");
    (void)text_set(&app.editors[2], "example-snap");
    (void)text_set(&app.editors[3], "example-bloat");
    app.setup.core = true;
    app.setup.workstation = true;
    app.surface = cairo_image_surface_create(UPPY_CAIRO_FORMAT_ARGB32,
                                             app.width, app.height);
    if (app.surface == NULL) return 1;
    app.cr = cairo_create(app.surface);
    if (app.cr == NULL) {
        cairo_surface_destroy(app.surface);
        return 1;
    }
    draw_frame(&app);
    result = cairo_surface_write_to_png(app.surface, path);
    cairo_destroy(app.cr);
    cairo_surface_destroy(app.surface);
    for (index = 0; index < 4; ++index) text_clear(&app.editors[index]);
    uppy_config_clear(&app.config);
    uppy_args_clear(&app.pending_args);
    return result == 0 ? 0 : 1;
}

int main(int argc, char **argv) {
    App app;
    if (argc == 2 && strcmp(argv[1], "--version") == 0) {
        puts(UPPY_VERSION);
        return 0;
    }
    if (argc == 2 && strcmp(argv[1], "--self-test") == 0) return self_test();
    if (argc == 4 && strcmp(argv[1], "--render-preview") == 0) {
        const char *names[] = {"overview", "setup", "apps", "output", "about"};
        int index;
        for (index = 0; index < 5; ++index)
            if (strcmp(argv[3], names[index]) == 0)
                return render_preview(argv[2], (Page)index);
        fprintf(stderr, "Unknown preview page: %s\n", argv[3]);
        return 2;
    }
    if (argc != 1) {
        fprintf(stderr,
                "Usage: %s [--version|--self-test|--render-preview FILE PAGE]\n",
                argv[0]);
        return 2;
    }
    if (!app_init(&app)) {
        app_destroy(&app);
        return 1;
    }
    app_loop(&app);
    app_destroy(&app);
    return 0;
}

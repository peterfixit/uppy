#define _POSIX_C_SOURCE 200809L

#include "uppy_core.h"

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#ifndef PATH_MAX
#define PATH_MAX 4096
#endif

#define UPPY_MAX_CONFIG_BYTES (1024U * 1024U)

static void set_error(char *error, size_t error_size, const char *format, ...) {
    va_list arguments;
    if (error == NULL || error_size == 0) {
        return;
    }
    va_start(arguments, format);
    (void)vsnprintf(error, error_size, format, arguments);
    va_end(arguments);
}

static char *duplicate_string(const char *value) {
    size_t length;
    char *copy;
    if (value == NULL) {
        return NULL;
    }
    length = strlen(value);
    copy = malloc(length + 1);
    if (copy != NULL) {
        memcpy(copy, value, length + 1);
    }
    return copy;
}

void uppy_list_init(UppyStringList *list) {
    memset(list, 0, sizeof(*list));
}

void uppy_list_clear(UppyStringList *list) {
    size_t index;
    if (list == NULL) {
        return;
    }
    for (index = 0; index < list->length; ++index) {
        free(list->items[index]);
    }
    free(list->items);
    memset(list, 0, sizeof(*list));
}

bool uppy_software_name_valid(const char *value) {
    size_t index;
    unsigned char character;
    if (value == NULL || value[0] == '\0' ||
        strlen(value) > UPPY_MAX_ITEM_LENGTH ||
        !isalnum((unsigned char)value[0])) {
        return false;
    }
    for (index = 1; value[index] != '\0'; ++index) {
        character = (unsigned char)value[index];
        if (!isalnum(character) && character != '@' && character != '.' &&
            character != '_' && character != '+' && character != ':' &&
            character != '-') {
            return false;
        }
    }
    return true;
}

bool uppy_list_add(UppyStringList *list, const char *value,
                   char *error, size_t error_size) {
    size_t index;
    char **resized;
    char *copy;

    if (!uppy_software_name_valid(value)) {
        set_error(error, error_size,
                  "Invalid package or application name: %s",
                  value != NULL ? value : "(null)");
        return false;
    }
    for (index = 0; index < list->length; ++index) {
        if (strcmp(list->items[index], value) == 0) {
            return true;
        }
    }
    if (list->length >= UPPY_MAX_ITEMS) {
        set_error(error, error_size,
                  "A software list cannot contain more than %d entries.",
                  UPPY_MAX_ITEMS);
        return false;
    }
    if (list->length == list->capacity) {
        size_t next_capacity = list->capacity == 0 ? 16 : list->capacity * 2;
        resized = realloc(list->items, next_capacity * sizeof(*resized));
        if (resized == NULL) {
            set_error(error, error_size, "Out of memory while adding an entry.");
            return false;
        }
        list->items = resized;
        list->capacity = next_capacity;
    }
    copy = duplicate_string(value);
    if (copy == NULL) {
        set_error(error, error_size, "Out of memory while adding an entry.");
        return false;
    }
    list->items[list->length++] = copy;
    return true;
}

bool uppy_list_copy(UppyStringList *destination,
                    const UppyStringList *source,
                    char *error, size_t error_size) {
    size_t index;
    UppyStringList temporary;
    uppy_list_init(&temporary);
    for (index = 0; index < source->length; ++index) {
        if (!uppy_list_add(&temporary, source->items[index], error, error_size)) {
            uppy_list_clear(&temporary);
            return false;
        }
    }
    uppy_list_clear(destination);
    *destination = temporary;
    return true;
}

void uppy_config_init(UppyConfig *config) {
    memset(config, 0, sizeof(*config));
}

void uppy_config_clear(UppyConfig *config) {
    if (config == NULL) {
        return;
    }
    uppy_list_clear(&config->system);
    uppy_list_clear(&config->flatpak);
    uppy_list_clear(&config->snap);
    uppy_list_clear(&config->remove);
}

bool uppy_config_validate(const UppyConfig *config,
                          char *error, size_t error_size) {
    const UppyStringList *lists[] = {
        &config->system, &config->flatpak, &config->snap, &config->remove
    };
    const char *labels[] = {
        "system packages", "Flatpak IDs", "Snap names", "removal targets"
    };
    size_t list_index;
    size_t item_index;
    for (list_index = 0; list_index < 4; ++list_index) {
        if (lists[list_index]->length > UPPY_MAX_ITEMS) {
            set_error(error, error_size, "Too many entries in %s.", labels[list_index]);
            return false;
        }
        for (item_index = 0; item_index < lists[list_index]->length; ++item_index) {
            if (!uppy_software_name_valid(lists[list_index]->items[item_index])) {
                set_error(error, error_size, "Invalid entry in %s: %s",
                          labels[list_index], lists[list_index]->items[item_index]);
                return false;
            }
        }
    }
    return true;
}

typedef struct {
    const char *position;
    const char *end;
    char message[256];
    unsigned int depth;
} JsonParser;

static void json_error(JsonParser *parser, const char *format, ...) {
    va_list arguments;
    if (parser->message[0] != '\0') {
        return;
    }
    va_start(arguments, format);
    (void)vsnprintf(parser->message, sizeof(parser->message), format, arguments);
    va_end(arguments);
}

static void json_space(JsonParser *parser) {
    while (parser->position < parser->end &&
           isspace((unsigned char)*parser->position)) {
        ++parser->position;
    }
}

static bool json_take(JsonParser *parser, char expected) {
    json_space(parser);
    if (parser->position >= parser->end || *parser->position != expected) {
        json_error(parser, "Expected '%c' in the settings file.", expected);
        return false;
    }
    ++parser->position;
    return true;
}

static int hex_value(char character) {
    if (character >= '0' && character <= '9') return character - '0';
    if (character >= 'a' && character <= 'f') return character - 'a' + 10;
    if (character >= 'A' && character <= 'F') return character - 'A' + 10;
    return -1;
}

static char *json_string(JsonParser *parser) {
    size_t capacity = 32;
    size_t length = 0;
    char *output;

    json_space(parser);
    if (parser->position >= parser->end || *parser->position != '"') {
        json_error(parser, "Expected text in the settings file.");
        return NULL;
    }
    ++parser->position;
    output = malloc(capacity);
    if (output == NULL) {
        json_error(parser, "Out of memory while reading settings.");
        return NULL;
    }

    while (parser->position < parser->end) {
        unsigned char character = (unsigned char)*parser->position++;
        if (character == '"') {
            output[length] = '\0';
            return output;
        }
        if (character < 0x20) {
            json_error(parser, "An unescaped control character was found in settings.");
            free(output);
            return NULL;
        }
        if (character == '\\') {
            int value = 0;
            int index;
            if (parser->position >= parser->end) {
                json_error(parser, "An incomplete escape was found in settings.");
                free(output);
                return NULL;
            }
            character = (unsigned char)*parser->position++;
            switch (character) {
                case '"': case '\\': case '/': break;
                case 'b': character = '\b'; break;
                case 'f': character = '\f'; break;
                case 'n': character = '\n'; break;
                case 'r': character = '\r'; break;
                case 't': character = '\t'; break;
                case 'u':
                    if ((size_t)(parser->end - parser->position) < 4) {
                        json_error(parser, "An incomplete Unicode escape was found.");
                        free(output);
                        return NULL;
                    }
                    for (index = 0; index < 4; ++index) {
                        int digit = hex_value(parser->position[index]);
                        if (digit < 0) {
                            json_error(parser, "An invalid Unicode escape was found.");
                            free(output);
                            return NULL;
                        }
                        value = value * 16 + digit;
                    }
                    parser->position += 4;
                    character = (value >= 0x20 && value <= 0x7e) ?
                                (unsigned char)value : (unsigned char)'?';
                    break;
                default:
                    json_error(parser, "An invalid escape was found in settings.");
                    free(output);
                    return NULL;
            }
        }
        if (length + 2 > capacity) {
            char *resized;
            capacity *= 2;
            if (capacity > UPPY_MAX_CONFIG_BYTES) {
                json_error(parser, "A settings value is too large.");
                free(output);
                return NULL;
            }
            resized = realloc(output, capacity);
            if (resized == NULL) {
                json_error(parser, "Out of memory while reading settings.");
                free(output);
                return NULL;
            }
            output = resized;
        }
        output[length++] = (char)character;
    }
    json_error(parser, "An unterminated string was found in settings.");
    free(output);
    return NULL;
}

static bool json_skip_value(JsonParser *parser);

static bool json_number_valid(const char *value, size_t length) {
    size_t index = 0;
    if (index < length && value[index] == '-') ++index;
    if (index >= length) return false;
    if (value[index] == '0') {
        ++index;
        if (index < length && isdigit((unsigned char)value[index])) return false;
    } else if (value[index] >= '1' && value[index] <= '9') {
        while (index < length && isdigit((unsigned char)value[index])) ++index;
    } else return false;
    if (index < length && value[index] == '.') {
        ++index;
        if (index >= length || !isdigit((unsigned char)value[index])) return false;
        while (index < length && isdigit((unsigned char)value[index])) ++index;
    }
    if (index < length && (value[index] == 'e' || value[index] == 'E')) {
        ++index;
        if (index < length && (value[index] == '+' || value[index] == '-')) ++index;
        if (index >= length || !isdigit((unsigned char)value[index])) return false;
        while (index < length && isdigit((unsigned char)value[index])) ++index;
    }
    return index == length;
}

static bool json_skip_object(JsonParser *parser) {
    bool first = true;
    if (++parser->depth > 64) {
        json_error(parser, "Settings are nested too deeply.");
        return false;
    }
    if (!json_take(parser, '{')) return false;
    json_space(parser);
    while (parser->position < parser->end && *parser->position != '}') {
        char *key;
        if (!first && !json_take(parser, ',')) return false;
        key = json_string(parser);
        free(key);
        if (parser->message[0] != '\0' || !json_take(parser, ':') ||
            !json_skip_value(parser)) return false;
        first = false;
        json_space(parser);
    }
    if (!json_take(parser, '}')) return false;
    --parser->depth;
    return true;
}

static bool json_skip_array(JsonParser *parser) {
    bool first = true;
    if (++parser->depth > 64) {
        json_error(parser, "Settings are nested too deeply.");
        return false;
    }
    if (!json_take(parser, '[')) return false;
    json_space(parser);
    while (parser->position < parser->end && *parser->position != ']') {
        if (!first && !json_take(parser, ',')) return false;
        if (!json_skip_value(parser)) return false;
        first = false;
        json_space(parser);
    }
    if (!json_take(parser, ']')) return false;
    --parser->depth;
    return true;
}

static bool json_skip_value(JsonParser *parser) {
    const char *start;
    char *text;
    json_space(parser);
    if (parser->position >= parser->end) {
        json_error(parser, "A settings value is missing.");
        return false;
    }
    if (*parser->position == '{') return json_skip_object(parser);
    if (*parser->position == '[') return json_skip_array(parser);
    if (*parser->position == '"') {
        text = json_string(parser);
        free(text);
        return parser->message[0] == '\0';
    }
    start = parser->position;
    while (parser->position < parser->end &&
           !strchr(" \t\r\n,]}", *parser->position)) {
        ++parser->position;
    }
    if (parser->position == start) {
        json_error(parser, "An invalid settings value was found.");
        return false;
    }
    if (!((size_t)(parser->position - start) == 4 &&
          strncmp(start, "true", 4) == 0) &&
        !((size_t)(parser->position - start) == 5 &&
          strncmp(start, "false", 5) == 0) &&
        !((size_t)(parser->position - start) == 4 &&
          strncmp(start, "null", 4) == 0)) {
        size_t length = (size_t)(parser->position - start);
        if (!json_number_valid(start, length)) {
            json_error(parser, "An invalid settings token was found.");
            return false;
        }
    }
    return true;
}

static bool json_parse_list(JsonParser *parser, UppyStringList *list,
                            const char *label) {
    UppyStringList temporary;
    bool first = true;
    char item_error[256] = "";
    uppy_list_init(&temporary);
    if (!json_take(parser, '[')) return false;
    json_space(parser);
    while (parser->position < parser->end && *parser->position != ']') {
        char *value;
        if (!first && !json_take(parser, ',')) goto failure;
        value = json_string(parser);
        if (value == NULL) goto failure;
        if (!uppy_list_add(&temporary, value, item_error, sizeof(item_error))) {
            json_error(parser, "Invalid entry in %s: %s", label, value);
            free(value);
            goto failure;
        }
        free(value);
        first = false;
        json_space(parser);
    }
    if (!json_take(parser, ']')) goto failure;
    uppy_list_clear(list);
    *list = temporary;
    return true;

failure:
    uppy_list_clear(&temporary);
    return false;
}

static bool json_parse_apps(JsonParser *parser, UppyConfig *config) {
    bool first = true;
    unsigned int seen = 0;
    if (!json_take(parser, '{')) return false;
    json_space(parser);
    while (parser->position < parser->end && *parser->position != '}') {
        char *key;
        UppyStringList *target = NULL;
        const char *label = NULL;
        unsigned int bit = 0;
        if (!first && !json_take(parser, ',')) return false;
        key = json_string(parser);
        if (key == NULL || !json_take(parser, ':')) {
            free(key);
            return false;
        }
        if (strcmp(key, "system") == 0) {
            target = &config->system; label = "system packages"; bit = 1;
        } else if (strcmp(key, "flatpak") == 0) {
            target = &config->flatpak; label = "Flatpak IDs"; bit = 2;
        } else if (strcmp(key, "snap") == 0) {
            target = &config->snap; label = "Snap names"; bit = 4;
        } else if (strcmp(key, "remove") == 0) {
            target = &config->remove; label = "removal targets"; bit = 8;
        }
        if (target != NULL) {
            if ((seen & bit) != 0) {
                json_error(parser, "The settings key '%s' appears more than once.", key);
                free(key);
                return false;
            }
            seen |= bit;
            if (!json_parse_list(parser, target, label)) {
                free(key);
                return false;
            }
        } else if (!json_skip_value(parser)) {
            free(key);
            return false;
        }
        free(key);
        first = false;
        json_space(parser);
    }
    return json_take(parser, '}');
}

static bool json_parse_root(JsonParser *parser, UppyConfig *config) {
    bool first = true;
    bool apps_seen = false;
    if (!json_take(parser, '{')) return false;
    json_space(parser);
    while (parser->position < parser->end && *parser->position != '}') {
        char *key;
        if (!first && !json_take(parser, ',')) return false;
        key = json_string(parser);
        if (key == NULL || !json_take(parser, ':')) {
            free(key);
            return false;
        }
        if (strcmp(key, "apps") == 0) {
            if (apps_seen) {
                json_error(parser, "The settings key 'apps' appears more than once.");
                free(key);
                return false;
            }
            apps_seen = true;
            if (!json_parse_apps(parser, config)) {
                free(key);
                return false;
            }
        } else if (!json_skip_value(parser)) {
            free(key);
            return false;
        }
        free(key);
        first = false;
        json_space(parser);
    }
    if (!json_take(parser, '}')) return false;
    json_space(parser);
    if (parser->position != parser->end) {
        json_error(parser, "Unexpected data follows the settings object.");
        return false;
    }
    return true;
}

bool uppy_config_load(UppyConfig *config, const char *path,
                      char *error, size_t error_size) {
    FILE *file;
    long size;
    char *data;
    size_t received;
    JsonParser parser;
    UppyConfig temporary;

    file = fopen(path, "rb");
    if (file == NULL) {
        if (errno == ENOENT) {
            return true;
        }
        set_error(error, error_size, "Could not open settings: %s", strerror(errno));
        return false;
    }
    if (fseek(file, 0, SEEK_END) != 0 || (size = ftell(file)) < 0 ||
        fseek(file, 0, SEEK_SET) != 0) {
        set_error(error, error_size, "Could not measure settings: %s", strerror(errno));
        fclose(file);
        return false;
    }
    if ((unsigned long)size > UPPY_MAX_CONFIG_BYTES) {
        set_error(error, error_size, "Settings exceed the 1 MB safety limit.");
        fclose(file);
        return false;
    }
    data = malloc((size_t)size + 1);
    if (data == NULL) {
        set_error(error, error_size, "Out of memory while reading settings.");
        fclose(file);
        return false;
    }
    received = fread(data, 1, (size_t)size, file);
    if (received != (size_t)size || ferror(file)) {
        set_error(error, error_size, "Could not read settings: %s", strerror(errno));
        free(data);
        fclose(file);
        return false;
    }
    fclose(file);
    data[received] = '\0';

    uppy_config_init(&temporary);
    memset(&parser, 0, sizeof(parser));
    parser.position = data;
    parser.end = data + received;
    if (!json_parse_root(&parser, &temporary) ||
        !uppy_config_validate(&temporary, error, error_size)) {
        if (parser.message[0] != '\0') {
            set_error(error, error_size, "%s", parser.message);
        }
        uppy_config_clear(&temporary);
        free(data);
        return false;
    }
    free(data);
    uppy_config_clear(config);
    *config = temporary;
    return true;
}

bool uppy_mkdirs(const char *path, unsigned int mode,
                 char *error, size_t error_size) {
    char buffer[PATH_MAX];
    char *position;
    size_t length = strlen(path);
    if (length == 0 || length >= sizeof(buffer)) {
        set_error(error, error_size, "A directory path is invalid or too long.");
        return false;
    }
    memcpy(buffer, path, length + 1);
    for (position = buffer + 1; *position != '\0'; ++position) {
        if (*position != '/') continue;
        *position = '\0';
        if (mkdir(buffer, (mode_t)mode) != 0 && errno != EEXIST) {
            set_error(error, error_size, "Could not create %s: %s",
                      buffer, strerror(errno));
            return false;
        }
        *position = '/';
    }
    if (mkdir(buffer, (mode_t)mode) != 0 && errno != EEXIST) {
        set_error(error, error_size, "Could not create %s: %s",
                  buffer, strerror(errno));
        return false;
    }
    return true;
}

static bool parent_directory(const char *path, char *buffer, size_t buffer_size) {
    char *slash;
    if (strlen(path) >= buffer_size) return false;
    strcpy(buffer, path);
    slash = strrchr(buffer, '/');
    if (slash == NULL) {
        strcpy(buffer, ".");
    } else if (slash == buffer) {
        slash[1] = '\0';
    } else {
        *slash = '\0';
    }
    return true;
}

static bool write_json_list(FILE *file, const char *key,
                            const UppyStringList *list, bool final) {
    size_t index;
    if (fprintf(file, "    \"%s\": [", key) < 0) return false;
    if (list->length != 0 && fputc('\n', file) == EOF) return false;
    for (index = 0; index < list->length; ++index) {
        if (fprintf(file, "      \"%s\"%s\n", list->items[index],
                    index + 1 == list->length ? "" : ",") < 0) return false;
    }
    if (list->length != 0 && fputs("    ", file) == EOF) return false;
    return fprintf(file, "]%s\n", final ? "" : ",") >= 0;
}

bool uppy_config_save(const UppyConfig *config, const char *path,
                      char *error, size_t error_size) {
    char parent[PATH_MAX];
    char temporary[PATH_MAX];
    int descriptor = -1;
    FILE *file = NULL;
    bool okay = false;

    if (!uppy_config_validate(config, error, error_size)) return false;
    if (!parent_directory(path, parent, sizeof(parent)) ||
        snprintf(temporary, sizeof(temporary), "%s/.uppy-config-XXXXXX", parent) >=
            (int)sizeof(temporary)) {
        set_error(error, error_size, "The settings path is too long.");
        return false;
    }
    if (!uppy_mkdirs(parent, 0700, error, error_size)) return false;
    descriptor = mkstemp(temporary);
    if (descriptor < 0) {
        set_error(error, error_size, "Could not create temporary settings: %s",
                  strerror(errno));
        return false;
    }
    if (fchmod(descriptor, 0600) != 0 || (file = fdopen(descriptor, "w")) == NULL) {
        set_error(error, error_size, "Could not secure temporary settings: %s",
                  strerror(errno));
        goto cleanup;
    }
    descriptor = -1;
    if (fprintf(file, "{\n  \"schema_version\": %d,\n  \"apps\": {\n",
                UPPY_CONFIG_SCHEMA) < 0 ||
        !write_json_list(file, "system", &config->system, false) ||
        !write_json_list(file, "flatpak", &config->flatpak, false) ||
        !write_json_list(file, "snap", &config->snap, false) ||
        !write_json_list(file, "remove", &config->remove, true) ||
        fputs("  }\n}\n", file) == EOF || fflush(file) != 0 ||
        fsync(fileno(file)) != 0) {
        set_error(error, error_size, "Could not write settings: %s", strerror(errno));
        goto cleanup;
    }
    if (fclose(file) != 0) {
        file = NULL;
        set_error(error, error_size, "Could not close settings: %s", strerror(errno));
        goto cleanup;
    }
    file = NULL;
    if (rename(temporary, path) != 0) {
        set_error(error, error_size, "Could not replace settings: %s", strerror(errno));
        goto cleanup;
    }
    okay = true;

cleanup:
    if (file != NULL) fclose(file);
    if (descriptor >= 0) close(descriptor);
    if (!okay) unlink(temporary);
    return okay;
}

static const char *xdg_path(char *buffer, size_t buffer_size,
                            const char *variable, const char *fallback,
                            const char *suffix) {
    const char *base = getenv(variable);
    const char *home;
    if (base != NULL && base[0] == '/') {
        if (snprintf(buffer, buffer_size, "%s/%s", base, suffix) <
            (int)buffer_size) return buffer;
        return NULL;
    }
    home = getenv("HOME");
    if (home == NULL || home[0] != '/') return NULL;
    if (snprintf(buffer, buffer_size, "%s/%s/%s", home, fallback, suffix) >=
        (int)buffer_size) return NULL;
    return buffer;
}

const char *uppy_config_path(char *buffer, size_t buffer_size) {
    return xdg_path(buffer, buffer_size, "XDG_CONFIG_HOME", ".config",
                    "uppy/config.json");
}

const char *uppy_state_log_path(char *buffer, size_t buffer_size) {
    return xdg_path(buffer, buffer_size, "XDG_STATE_HOME", ".local/state",
                    "uppy/gui.log");
}

bool uppy_parse_lines(UppyStringList *list, const char *text,
                      const char *label, char *error, size_t error_size) {
    UppyStringList temporary;
    const char *line = text;
    unsigned int line_number = 1;
    uppy_list_init(&temporary);
    while (*line != '\0') {
        const char *end = strchr(line, '\n');
        const char *start = line;
        size_t length;
        char item[UPPY_MAX_ITEM_LENGTH + 2];
        if (end == NULL) end = line + strlen(line);
        while (start < end && isspace((unsigned char)*start)) ++start;
        while (end > start && isspace((unsigned char)end[-1])) --end;
        length = (size_t)(end - start);
        if (length > 0) {
            if (length > UPPY_MAX_ITEM_LENGTH) {
                set_error(error, error_size, "%s line %u is too long.",
                          label, line_number);
                goto failure;
            }
            memcpy(item, start, length);
            item[length] = '\0';
            if (!uppy_list_add(&temporary, item, error, error_size)) {
                char detail[256];
                snprintf(detail, sizeof(detail), "%s", error != NULL ? error : "Invalid entry");
                set_error(error, error_size, "%s line %u: %s",
                          label, line_number, detail);
                goto failure;
            }
        }
        if (*end == '\0') break;
        line = end + 1;
        ++line_number;
    }
    uppy_list_clear(list);
    *list = temporary;
    return true;

failure:
    uppy_list_clear(&temporary);
    return false;
}

char *uppy_join_lines(const UppyStringList *list) {
    size_t length = 1;
    size_t index;
    char *output;
    char *position;
    for (index = 0; index < list->length; ++index) {
        length += strlen(list->items[index]) + 1;
    }
    output = malloc(length);
    if (output == NULL) return NULL;
    position = output;
    for (index = 0; index < list->length; ++index) {
        size_t item_length = strlen(list->items[index]);
        memcpy(position, list->items[index], item_length);
        position += item_length;
        if (index + 1 < list->length) *position++ = '\n';
    }
    *position = '\0';
    return output;
}

void uppy_args_init(UppyArgs *args) {
    memset(args, 0, sizeof(*args));
}

void uppy_args_clear(UppyArgs *args) {
    size_t index;
    for (index = 0; index < args->length; ++index) free(args->values[index]);
    free(args->values);
    memset(args, 0, sizeof(*args));
}

bool uppy_args_add(UppyArgs *args, const char *value,
                   char *error, size_t error_size) {
    char **resized;
    char *copy;
    if (args->length == args->capacity) {
        size_t next = args->capacity == 0 ? 16 : args->capacity * 2;
        resized = realloc(args->values, next * sizeof(*resized));
        if (resized == NULL) {
            set_error(error, error_size, "Out of memory while building a command.");
            uppy_args_clear(args);
            return false;
        }
        args->values = resized;
        args->capacity = next;
    }
    copy = duplicate_string(value);
    if (copy == NULL) {
        set_error(error, error_size, "Out of memory while building a command.");
        uppy_args_clear(args);
        return false;
    }
    args->values[args->length++] = copy;
    return true;
}

static bool finish_arguments(UppyArgs *args, bool preview,
                             char *error, size_t error_size) {
    if (!uppy_args_add(args, "--yes", error, error_size)) return false;
    if (preview && !uppy_args_add(args, "--dry-run", error, error_size)) return false;
    return true;
}

bool uppy_build_update_args(UppyArgs *args, bool maintenance, bool reboot,
                            bool preview, char *error, size_t error_size) {
    const char *mode = reboot ? "--reboot" :
                       (maintenance ? "--update" : "--no-maintenance");
    if (uppy_args_add(args, mode, error, error_size) &&
        finish_arguments(args, preview, error, error_size)) return true;
    uppy_args_clear(args);
    return false;
}

static bool add_config_arguments(UppyArgs *args, const UppyConfig *config,
                                 bool install, bool remove, bool allow_empty_install,
                                 char *error, size_t error_size) {
    size_t index;
    size_t install_count = config->system.length + config->flatpak.length +
                           config->snap.length;
    if (install && install_count == 0 && !allow_empty_install) {
        set_error(error, error_size,
                  "No custom applications are saved. Add entries on the Apps page first.");
        return false;
    }
    if (install) {
        for (index = 0; index < config->system.length; ++index) {
            if (!uppy_args_add(args, "--add-system", error, error_size) ||
                !uppy_args_add(args, config->system.items[index], error, error_size)) return false;
        }
        for (index = 0; index < config->flatpak.length; ++index) {
            if (!uppy_args_add(args, "--add-flatpak", error, error_size) ||
                !uppy_args_add(args, config->flatpak.items[index], error, error_size)) return false;
        }
        for (index = 0; index < config->snap.length; ++index) {
            if (!uppy_args_add(args, "--add-snap", error, error_size) ||
                !uppy_args_add(args, config->snap.items[index], error, error_size)) return false;
        }
        if (install_count == 0 &&
            !uppy_args_add(args, "--additional-apps", error, error_size)) return false;
    }
    if (remove) {
        if (config->remove.length == 0) {
            if (!uppy_args_add(args, "--remove-software", error, error_size)) return false;
        } else {
            for (index = 0; index < config->remove.length; ++index) {
                if (!uppy_args_add(args, "--add-bloat", error, error_size) ||
                    !uppy_args_add(args, config->remove.items[index], error, error_size)) return false;
            }
        }
    }
    return true;
}

bool uppy_build_setup_args(UppyArgs *args, const UppyConfig *config,
                           UppySetupSelection selected, bool preview,
                           char *error, size_t error_size) {
    if (!selected.core && !selected.workstation && !selected.gaming &&
        !selected.additional_apps && !selected.remove_software) {
        set_error(error, error_size, "Select at least one setup task.");
        uppy_args_clear(args);
        return false;
    }
    if (!uppy_config_validate(config, error, error_size)) goto failure;
    if (selected.core && !uppy_args_add(args, "--core", error, error_size)) goto failure;
    if (selected.workstation && !uppy_args_add(args, "--workstation", error, error_size)) goto failure;
    if (selected.gaming && !uppy_args_add(args, "--gaming", error, error_size)) goto failure;
    if (!add_config_arguments(args, config, selected.additional_apps,
                              selected.remove_software, true,
                              error, error_size)) goto failure;
    if (finish_arguments(args, preview, error, error_size)) return true;
failure:
    uppy_args_clear(args);
    return false;
}

bool uppy_build_apps_args(UppyArgs *args, const UppyConfig *config,
                          bool install, bool remove, bool preview,
                          char *error, size_t error_size) {
    if (!install && !remove) {
        set_error(error, error_size, "Choose an application action.");
        uppy_args_clear(args);
        return false;
    }
    if (!uppy_config_validate(config, error, error_size) ||
        !add_config_arguments(args, config, install, remove, false,
                              error, error_size)) goto failure;
    if (finish_arguments(args, preview, error, error_size)) return true;
failure:
    uppy_args_clear(args);
    return false;
}

bool uppy_build_simple_args(UppyArgs *args, const char *mode, bool preview,
                            char *error, size_t error_size) {
    const char *allowed[] = {
        "--check", "--list-software", "--backup", "--clean"
    };
    size_t index;
    bool found = false;
    for (index = 0; index < sizeof(allowed) / sizeof(allowed[0]); ++index) {
        if (strcmp(mode, allowed[index]) == 0) found = true;
    }
    if (!found) {
        set_error(error, error_size, "Unsupported command mode: %s", mode);
        uppy_args_clear(args);
        return false;
    }
    if (uppy_args_add(args, mode, error, error_size) &&
        finish_arguments(args, preview, error, error_size)) return true;
    uppy_args_clear(args);
    return false;
}

static size_t shell_quoted_length(const char *value) {
    size_t length = 2;
    while (*value != '\0') {
        length += *value == '\'' ? 4 : 1;
        ++value;
    }
    return length;
}

static char *shell_quote(char *output, const char *value) {
    *output++ = '\'';
    while (*value != '\0') {
        if (*value == '\'') {
            memcpy(output, "'\\''", 4);
            output += 4;
        } else {
            *output++ = *value;
        }
        ++value;
    }
    *output++ = '\'';
    return output;
}

char *uppy_display_command(const UppyArgs *args) {
    size_t length = strlen("uppy") + 1;
    size_t index;
    char *output;
    char *position;
    for (index = 0; index < args->length; ++index) {
        length += shell_quoted_length(args->values[index]) + 1;
    }
    output = malloc(length);
    if (output == NULL) return NULL;
    position = output;
    memcpy(position, "uppy", 4);
    position += 4;
    for (index = 0; index < args->length; ++index) {
        *position++ = ' ';
        position = shell_quote(position, args->values[index]);
    }
    *position = '\0';
    return output;
}

bool uppy_read_os_name(char *buffer, size_t buffer_size) {
    FILE *file = fopen("/etc/os-release", "r");
    char line[1024];
    if (file == NULL) {
        snprintf(buffer, buffer_size, "Linux");
        return false;
    }
    while (fgets(line, sizeof(line), file) != NULL) {
        if (strncmp(line, "PRETTY_NAME=", 12) == 0) {
            char *value = line + 12;
            size_t length;
            value[strcspn(value, "\r\n")] = '\0';
            length = strlen(value);
            if (length >= 2 && value[0] == '"' && value[length - 1] == '"') {
                value[length - 1] = '\0';
                ++value;
            }
            snprintf(buffer, buffer_size, "%s", value);
            fclose(file);
            return true;
        }
    }
    fclose(file);
    snprintf(buffer, buffer_size, "Linux");
    return false;
}

bool uppy_find_executable(const char *name, char *buffer, size_t buffer_size) {
    const char *path = getenv("PATH");
    const char *start;
    if (name == NULL || strchr(name, '/') != NULL || path == NULL) return false;
    start = path;
    while (true) {
        const char *end = strchr(start, ':');
        size_t directory_length = end != NULL ? (size_t)(end - start) : strlen(start);
        const char *directory = directory_length == 0 ? "." : start;
        int written;
        if (directory_length == 0) directory_length = 1;
        written = snprintf(buffer, buffer_size, "%.*s/%s",
                           (int)directory_length, directory, name);
        if (written > 0 && written < (int)buffer_size && access(buffer, X_OK) == 0) {
            return true;
        }
        if (end == NULL) break;
        start = end + 1;
    }
    return false;
}

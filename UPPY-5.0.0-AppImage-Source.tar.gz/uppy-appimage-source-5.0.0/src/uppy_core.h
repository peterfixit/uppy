#ifndef UPPY_CORE_H
#define UPPY_CORE_H

#include <stdbool.h>
#include <stddef.h>

#define UPPY_VERSION "5.0.0"
#define UPPY_CONFIG_SCHEMA 3
#define UPPY_MAX_ITEMS 512
#define UPPY_MAX_ITEM_LENGTH 255

typedef struct {
    char **items;
    size_t length;
    size_t capacity;
} UppyStringList;

typedef struct {
    UppyStringList system;
    UppyStringList flatpak;
    UppyStringList snap;
    UppyStringList remove;
} UppyConfig;

typedef struct {
    char **values;
    size_t length;
    size_t capacity;
} UppyArgs;

typedef struct {
    bool core;
    bool workstation;
    bool gaming;
    bool additional_apps;
    bool remove_software;
} UppySetupSelection;

void uppy_list_init(UppyStringList *list);
void uppy_list_clear(UppyStringList *list);
bool uppy_list_add(UppyStringList *list, const char *value,
                   char *error, size_t error_size);
bool uppy_list_copy(UppyStringList *destination,
                    const UppyStringList *source,
                    char *error, size_t error_size);

void uppy_config_init(UppyConfig *config);
void uppy_config_clear(UppyConfig *config);
bool uppy_config_load(UppyConfig *config, const char *path,
                      char *error, size_t error_size);
bool uppy_config_save(const UppyConfig *config, const char *path,
                      char *error, size_t error_size);
bool uppy_config_validate(const UppyConfig *config,
                          char *error, size_t error_size);
const char *uppy_config_path(char *buffer, size_t buffer_size);
const char *uppy_state_log_path(char *buffer, size_t buffer_size);

bool uppy_software_name_valid(const char *value);
bool uppy_parse_lines(UppyStringList *list, const char *text,
                      const char *label, char *error, size_t error_size);
char *uppy_join_lines(const UppyStringList *list);

void uppy_args_init(UppyArgs *args);
void uppy_args_clear(UppyArgs *args);
bool uppy_args_add(UppyArgs *args, const char *value,
                   char *error, size_t error_size);
bool uppy_build_update_args(UppyArgs *args, bool maintenance, bool reboot,
                            bool preview, char *error, size_t error_size);
bool uppy_build_setup_args(UppyArgs *args, const UppyConfig *config,
                           UppySetupSelection selected, bool preview,
                           char *error, size_t error_size);
bool uppy_build_apps_args(UppyArgs *args, const UppyConfig *config,
                          bool install, bool remove, bool preview,
                          char *error, size_t error_size);
bool uppy_build_simple_args(UppyArgs *args, const char *mode, bool preview,
                            char *error, size_t error_size);
char *uppy_display_command(const UppyArgs *args);

bool uppy_read_os_name(char *buffer, size_t buffer_size);
bool uppy_find_executable(const char *name, char *buffer, size_t buffer_size);
bool uppy_mkdirs(const char *path, unsigned int mode,
                 char *error, size_t error_size);

#endif

#ifndef UPPY_X11_CAIRO_COMPAT_H
#define UPPY_X11_CAIRO_COMPAT_H

/*
 * UPPY uses a deliberately small subset of the stable Xlib and Cairo ABIs.
 * Declaring that subset here keeps the build independent of distribution
 * development-header packages. The runtime libraries are bundled into the
 * AppImage by build-appimage.sh.
 */

#include <stddef.h>

typedef struct _XDisplay Display;
typedef struct Visual Visual;
typedef struct _XGC *GC;
typedef unsigned long XID;
typedef XID Window;
typedef XID Drawable;
typedef XID Pixmap;
typedef XID Atom;
typedef unsigned long Time;
typedef unsigned long KeySym;
typedef int Bool;

typedef struct {
    int type;
    unsigned long serial;
    Bool send_event;
    Display *display;
    Window window;
    Window root;
    Window subwindow;
    Time time;
    int x;
    int y;
    int x_root;
    int y_root;
    unsigned int state;
    unsigned int keycode;
    Bool same_screen;
} XKeyEvent;

typedef struct {
    int type;
    unsigned long serial;
    Bool send_event;
    Display *display;
    Window window;
    Window root;
    Window subwindow;
    Time time;
    int x;
    int y;
    int x_root;
    int y_root;
    unsigned int state;
    unsigned int button;
    Bool same_screen;
} XButtonEvent;

typedef struct {
    int type;
    unsigned long serial;
    Bool send_event;
    Display *display;
    Window event;
    Window window;
    int x;
    int y;
    int width;
    int height;
    int border_width;
    Window above;
    Bool override_redirect;
} XConfigureEvent;

typedef struct {
    int type;
    unsigned long serial;
    Bool send_event;
    Display *display;
    Window window;
    int x;
    int y;
    int width;
    int height;
    int count;
} XExposeEvent;

typedef union {
    char b[20];
    short s[10];
    long l[5];
} XClientMessageData;

typedef struct {
    int type;
    unsigned long serial;
    Bool send_event;
    Display *display;
    Window window;
    Atom message_type;
    int format;
    XClientMessageData data;
} XClientMessageEvent;

typedef struct {
    int type;
    unsigned long serial;
    Bool send_event;
    Display *display;
    Window requestor;
    Atom selection;
    Atom target;
    Atom property;
    Time time;
} XSelectionEvent;

typedef union _XEvent {
    int type;
    XKeyEvent xkey;
    XButtonEvent xbutton;
    XConfigureEvent xconfigure;
    XExposeEvent xexpose;
    XClientMessageEvent xclient;
    XSelectionEvent xselection;
    long pad[24];
} XEvent;

typedef struct {
    char *res_name;
    char *res_class;
} XClassHint;

typedef struct {
    long flags;
    int x;
    int y;
    int width;
    int height;
    int min_width;
    int min_height;
    int max_width;
    int max_height;
    int width_inc;
    int height_inc;
    struct { int x; int y; } min_aspect;
    struct { int x; int y; } max_aspect;
    int base_width;
    int base_height;
    int win_gravity;
} XSizeHints;

enum {
    UPPY_KeyPress = 2,
    UPPY_ButtonPress = 4,
    UPPY_Expose = 12,
    UPPY_ConfigureNotify = 22,
    UPPY_SelectionNotify = 31,
    UPPY_ClientMessage = 33
};

#define UPPY_KeyPressMask       (1L << 0)
#define UPPY_ButtonPressMask    (1L << 2)
#define UPPY_ExposureMask       (1L << 15)
#define UPPY_StructureNotifyMask (1L << 17)
#define UPPY_ControlMask        (1U << 2)
#define UPPY_CurrentTime        0UL
#define UPPY_AnyPropertyType    0UL
#define UPPY_PropModeReplace    0
#define UPPY_PMinSize           (1L << 4)

#define UPPY_XK_BackSpace 0xff08UL
#define UPPY_XK_Tab       0xff09UL
#define UPPY_XK_Return    0xff0dUL
#define UPPY_XK_Escape    0xff1bUL
#define UPPY_XK_Home      0xff50UL
#define UPPY_XK_Left      0xff51UL
#define UPPY_XK_Up        0xff52UL
#define UPPY_XK_Right     0xff53UL
#define UPPY_XK_Down      0xff54UL
#define UPPY_XK_End       0xff57UL
#define UPPY_XK_Delete    0xffffUL

extern Display *XOpenDisplay(const char *display_name);
extern int XCloseDisplay(Display *display);
extern int XDefaultScreen(Display *display);
extern Window XRootWindow(Display *display, int screen_number);
extern Visual *XDefaultVisual(Display *display, int screen_number);
extern int XDefaultDepth(Display *display, int screen_number);
extern unsigned long XBlackPixel(Display *display, int screen_number);
extern unsigned long XWhitePixel(Display *display, int screen_number);
extern int XDisplayWidth(Display *display, int screen_number);
extern int XDisplayHeight(Display *display, int screen_number);
extern Window XCreateSimpleWindow(Display *display, Window parent, int x, int y,
                                  unsigned int width, unsigned int height,
                                  unsigned int border_width,
                                  unsigned long border,
                                  unsigned long background);
extern int XDestroyWindow(Display *display, Window window);
extern int XMapWindow(Display *display, Window window);
extern int XStoreName(Display *display, Window window, const char *name);
extern int XSelectInput(Display *display, Window window, long event_mask);
extern Atom XInternAtom(Display *display, const char *atom_name,
                       Bool only_if_exists);
extern int XSetWMProtocols(Display *display, Window window, Atom *protocols,
                           int count);
extern int XSetClassHint(Display *display, Window window,
                         XClassHint *class_hints);
extern int XSetWMNormalHints(Display *display, Window window,
                             XSizeHints *hints);
extern int XPending(Display *display);
extern int XNextEvent(Display *display, XEvent *event_return);
extern int XConnectionNumber(Display *display);
extern int XLookupString(XKeyEvent *event_struct, char *buffer_return,
                         int bytes_buffer, KeySym *keysym_return,
                         void *status_in_out);
extern int XFlush(Display *display);
extern int XResizeWindow(Display *display, Window window, unsigned int width,
                         unsigned int height);
extern Pixmap XCreatePixmap(Display *display, Drawable drawable,
                            unsigned int width, unsigned int height,
                            unsigned int depth);
extern int XFreePixmap(Display *display, Pixmap pixmap);
extern GC XCreateGC(Display *display, Drawable drawable,
                    unsigned long valuemask, void *values);
extern int XFreeGC(Display *display, GC gc);
extern int XCopyArea(Display *display, Drawable src, Drawable dst, GC gc,
                     int src_x, int src_y, unsigned int width,
                     unsigned int height, int dst_x, int dst_y);
extern int XConvertSelection(Display *display, Atom selection, Atom target,
                             Atom property, Window requestor, Time time);
extern int XGetWindowProperty(Display *display, Window window, Atom property,
                              long long_offset, long long_length, Bool delete,
                              Atom requested_type, Atom *actual_type_return,
                              int *actual_format_return,
                              unsigned long *nitems_return,
                              unsigned long *bytes_after_return,
                              unsigned char **prop_return);
extern int XFree(void *data);

typedef struct _cairo cairo_t;
typedef struct _cairo_surface cairo_surface_t;

typedef struct {
    double x_bearing;
    double y_bearing;
    double width;
    double height;
    double x_advance;
    double y_advance;
} cairo_text_extents_t;

#define UPPY_CAIRO_FONT_SLANT_NORMAL 0
#define UPPY_CAIRO_FONT_WEIGHT_NORMAL 0
#define UPPY_CAIRO_FONT_WEIGHT_BOLD 1
#define UPPY_CAIRO_FORMAT_ARGB32 0

extern cairo_surface_t *cairo_xlib_surface_create(Display *display,
                                                   Drawable drawable,
                                                   Visual *visual,
                                                   int width, int height);
extern cairo_surface_t *cairo_image_surface_create(int format, int width,
                                                    int height);
extern int cairo_surface_write_to_png(cairo_surface_t *surface,
                                      const char *filename);
extern void cairo_xlib_surface_set_size(cairo_surface_t *surface,
                                        int width, int height);
extern cairo_t *cairo_create(cairo_surface_t *target);
extern void cairo_destroy(cairo_t *cr);
extern void cairo_surface_destroy(cairo_surface_t *surface);
extern void cairo_surface_flush(cairo_surface_t *surface);
extern void cairo_surface_mark_dirty(cairo_surface_t *surface);
extern void cairo_save(cairo_t *cr);
extern void cairo_restore(cairo_t *cr);
extern void cairo_set_source_rgb(cairo_t *cr, double red, double green,
                                  double blue);
extern void cairo_set_source_rgba(cairo_t *cr, double red, double green,
                                   double blue, double alpha);
extern void cairo_set_line_width(cairo_t *cr, double width);
extern void cairo_rectangle(cairo_t *cr, double x, double y, double width,
                             double height);
extern void cairo_move_to(cairo_t *cr, double x, double y);
extern void cairo_line_to(cairo_t *cr, double x, double y);
extern void cairo_arc(cairo_t *cr, double xc, double yc, double radius,
                       double angle1, double angle2);
extern void cairo_close_path(cairo_t *cr);
extern void cairo_fill(cairo_t *cr);
extern void cairo_fill_preserve(cairo_t *cr);
extern void cairo_stroke(cairo_t *cr);
extern void cairo_clip(cairo_t *cr);
extern void cairo_paint(cairo_t *cr);
extern void cairo_select_font_face(cairo_t *cr, const char *family,
                                    int slant, int weight);
extern void cairo_set_font_size(cairo_t *cr, double size);
extern void cairo_show_text(cairo_t *cr, const char *utf8);
extern void cairo_text_extents(cairo_t *cr, const char *utf8,
                                cairo_text_extents_t *extents);

#endif
